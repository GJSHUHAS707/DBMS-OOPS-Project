package com.cinebook.servlet;
import com.cinebook.util.DBConnection;
import com.google.gson.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/api/seats")
public class SeatsServlet extends HttpServlet {
  private final Gson gson=new Gson();
  protected void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException {
    res.setContentType("application/json;charset=UTF-8");
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
    res.setHeader("Pragma", "no-cache");
    int id;
    try { id=Integer.parseInt(req.getParameter("showtimeId")); }
    catch(Exception e) { res.setStatus(400); res.getWriter().write("{\"error\":\"Valid showtimeId required\"}"); return; }
    JsonArray seats=new JsonArray();
    try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement("SELECT seat_list FROM bookings WHERE showtime_id=? AND booking_status='CONFIRMED'")) {
      p.setInt(1,id);
      try(ResultSet r=p.executeQuery()) { while(r.next()) for(String s:r.getString(1).split(",")) seats.add(s); }
      JsonObject o=new JsonObject(); o.add("occupiedSeats",seats); res.getWriter().write(gson.toJson(o));
    } catch(SQLException e) { res.setStatus(500); res.getWriter().write("{\"error\":\"Database error loading seats\"}"); getServletContext().log("Seats failed",e); }
  }
}
