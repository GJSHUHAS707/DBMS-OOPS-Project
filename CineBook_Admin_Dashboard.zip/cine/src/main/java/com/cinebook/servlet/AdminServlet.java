package com.cinebook.servlet;

import com.cinebook.util.DBConnection;
import com.google.gson.Gson;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

@WebServlet("/api/admin/*")
public class AdminServlet extends HttpServlet {
    private final Gson gson = new Gson();

    // Change this before demonstrating the project. This is a learning-project login, not production security.
    private static final String ADMIN_PASSWORD = "ChangeThisAdmin123!";

    private boolean authorized(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        return s != null && Boolean.TRUE.equals(s.getAttribute("cinebookAdmin"));
    }

    private void json(HttpServletResponse resp, int status, Object data) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(gson.toJson(data));
    }

    private Map<String,Object> body(HttpServletRequest req) throws IOException {
        return gson.fromJson(req.getReader(), Map.class);
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        String path = req.getPathInfo() == null ? "" : req.getPathInfo();
        if ("/login".equals(path)) {
            Map<String,Object> b = body(req);
            String password = b == null ? "" : String.valueOf(b.getOrDefault("password", ""));
            if (ADMIN_PASSWORD.equals(password)) {
                req.getSession(true).setAttribute("cinebookAdmin", true);
                json(resp, 200, Map.of("ok", true, "message", "Signed in"));
            } else {
                json(resp, 401, Map.of("ok", false, "message", "Incorrect admin password"));
            }
            return;
        }
        if ("/logout".equals(path)) {
            HttpSession s = req.getSession(false);
            if (s != null) s.invalidate();
            json(resp, 200, Map.of("ok", true));
            return;
        }
        if (!authorized(req)) { json(resp, 401, Map.of("error", "Please sign in as admin")); return; }

        Map<String,Object> b = body(req);
        try (Connection c = DBConnection.getConnection()) {
            if ("/movies".equals(path)) {
                String title = str(b, "title"), genre = str(b, "genre");
                int duration = integer(b, "durationMinutes");
                if (title.isBlank() || genre.isBlank() || duration < 1) {
                    json(resp, 400, Map.of("error", "Title, genre and a positive duration are required")); return;
                }
                String sql = "INSERT INTO movies(title,genre,duration_minutes,rating,description,poster_url,featured) VALUES(?,?,?,?,?,?,?)";
                try (PreparedStatement p = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                    p.setString(1, title); p.setString(2, genre); p.setInt(3, duration);
                    p.setString(4, strOr(b,"rating","U/A")); p.setString(5, str(b,"description"));
                    p.setString(6, str(b,"posterUrl")); p.setBoolean(7, Boolean.parseBoolean(str(b,"featured")));
                    p.executeUpdate();
                    try (ResultSet rs = p.getGeneratedKeys()) {
                        long id = rs.next() ? rs.getLong(1) : -1;
                        json(resp, 201, Map.of("ok", true, "id", id, "message", "Movie added"));
                    }
                }
                return;
            }
            if ("/showtimes".equals(path)) {
                int movieId = integer(b, "movieId");
                String cinema = strOr(b,"cinemaName","CineBook Central");
                String date = str(b,"showDate"), time = str(b,"showTime");
                BigDecimal price = decimal(b,"ticketPrice");
                if (movieId < 1 || date.isBlank() || time.isBlank() || price == null || price.signum() < 0) {
                    json(resp, 400, Map.of("error", "Choose a movie, date, time and valid ticket price")); return;
                }
                String sql = "INSERT INTO showtimes(movie_id,cinema_name,show_date,show_time,ticket_price) VALUES(?,?,?,?,?)";
                try (PreparedStatement p = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                    p.setInt(1, movieId); p.setString(2, cinema); p.setDate(3, Date.valueOf(date));
                    p.setTime(4, Time.valueOf(time.length()==5 ? time + ":00" : time)); p.setBigDecimal(5, price);
                    p.executeUpdate();
                    try (ResultSet rs = p.getGeneratedKeys()) {
                        long id = rs.next() ? rs.getLong(1) : -1;
                        json(resp, 201, Map.of("ok", true, "id", id, "message", "Showtime added"));
                    }
                }
                return;
            }
            json(resp, 404, Map.of("error", "Unknown endpoint"));
        } catch (IllegalArgumentException ex) {
            json(resp, 400, Map.of("error", "Invalid date, time or field value"));
        } catch (SQLException ex) {
            json(resp, 500, Map.of("error", "Database error: " + ex.getMessage()));
        }
    }

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String path = req.getPathInfo() == null ? "" : req.getPathInfo();
        if ("/session".equals(path)) { json(resp, 200, Map.of("authenticated", authorized(req))); return; }
        if (!authorized(req)) { json(resp, 401, Map.of("error", "Please sign in as admin")); return; }
        try (Connection c = DBConnection.getConnection()) {
            if ("/movies".equals(path)) {
                List<Map<String,Object>> rows = new ArrayList<>();
                try (PreparedStatement p = c.prepareStatement("SELECT id,title,genre,duration_minutes,rating,description,poster_url,featured FROM movies ORDER BY id DESC");
                     ResultSet rs = p.executeQuery()) {
                    while (rs.next()) {
                        Map<String,Object> m = new LinkedHashMap<>();
                        m.put("id", rs.getInt("id")); m.put("title", rs.getString("title"));
                        m.put("genre", rs.getString("genre")); m.put("durationMinutes", rs.getInt("duration_minutes"));
                        m.put("rating", rs.getString("rating")); m.put("description", rs.getString("description"));
                        m.put("posterUrl", rs.getString("poster_url")); m.put("featured", rs.getBoolean("featured"));
                        rows.add(m);
                    }
                }
                json(resp, 200, rows); return;
            }
            if ("/showtimes".equals(path)) {
                List<Map<String,Object>> rows = new ArrayList<>();
                String sql = "SELECT s.id,s.movie_id,m.title,s.cinema_name,s.show_date,s.show_time,s.ticket_price " +
                             "FROM showtimes s JOIN movies m ON m.id=s.movie_id ORDER BY s.show_date,s.show_time";
                try (PreparedStatement p = c.prepareStatement(sql); ResultSet rs = p.executeQuery()) {
                    while (rs.next()) {
                        Map<String,Object> m = new LinkedHashMap<>();
                        m.put("id",rs.getInt("id")); m.put("movieId",rs.getInt("movie_id")); m.put("movieTitle",rs.getString("title"));
                        m.put("cinemaName",rs.getString("cinema_name")); m.put("showDate",rs.getDate("show_date").toString());
                        m.put("showTime",rs.getTime("show_time").toString()); m.put("ticketPrice",rs.getBigDecimal("ticket_price"));
                        rows.add(m);
                    }
                }
                json(resp, 200, rows); return;
            }
            json(resp, 404, Map.of("error", "Unknown endpoint"));
        } catch (SQLException ex) {
            json(resp, 500, Map.of("error", "Database error: " + ex.getMessage()));
        }
    }

    @Override protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (!authorized(req)) { json(resp, 401, Map.of("error", "Please sign in as admin")); return; }
        String path = req.getPathInfo() == null ? "" : req.getPathInfo();
        Map<String,Object> b = body(req);
        try (Connection c = DBConnection.getConnection()) {
            if ("/showtimes".equals(path)) {
                int id = integer(b,"id"); BigDecimal price = decimal(b,"ticketPrice");
                if (id < 1 || price == null || price.signum() < 0) {
                    json(resp,400,Map.of("error","Valid showtime ID and non-negative price required")); return;
                }
                try (PreparedStatement p = c.prepareStatement("UPDATE showtimes SET ticket_price=? WHERE id=?")) {
                    p.setBigDecimal(1,price); p.setInt(2,id);
                    if (p.executeUpdate() == 0) { json(resp,404,Map.of("error","Showtime not found")); return; }
                }
                json(resp,200,Map.of("ok",true,"message","Ticket price updated")); return;
            }
            json(resp,404,Map.of("error","Unknown endpoint"));
        } catch (SQLException ex) { json(resp,500,Map.of("error","Database error: "+ex.getMessage())); }
    }

    @Override protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (!authorized(req)) { json(resp,401,Map.of("error","Please sign in as admin")); return; }
        String path = req.getPathInfo() == null ? "" : req.getPathInfo();
        int id;
        try { id = Integer.parseInt(req.getParameter("id")); }
        catch (Exception e) { json(resp,400,Map.of("error","A valid id is required")); return; }
        String table = "/showtimes".equals(path) ? "showtimes" : "/movies".equals(path) ? "movies" : null;
        if (table == null) { json(resp,404,Map.of("error","Unknown endpoint")); return; }
        try (Connection c = DBConnection.getConnection()) {
            // Keep historical bookings safe: a showtime/movie linked to bookings cannot be deleted.
            String sql = "DELETE FROM " + table + " WHERE id=?";
            try (PreparedStatement p = c.prepareStatement(sql)) {
                p.setInt(1,id);
                if (p.executeUpdate() == 0) { json(resp,404,Map.of("error","Record not found (it may have bookings)")); return; }
            }
            json(resp,200,Map.of("ok",true,"message","Deleted"));
        } catch (SQLException ex) {
            json(resp,409,Map.of("error","Cannot delete this record because it may be linked to bookings or showtimes"));
        }
    }

    private String str(Map<String,Object> b, String key) { Object v=b==null?null:b.get(key); return v==null?"":String.valueOf(v).trim(); }
    private String strOr(Map<String,Object> b,String key,String fallback) { String s=str(b,key); return s.isBlank()?fallback:s; }
    private int integer(Map<String,Object> b,String key) { try { return (int)Double.parseDouble(str(b,key)); } catch(Exception e) { return 0; } }
    private BigDecimal decimal(Map<String,Object> b,String key) { try { return new BigDecimal(str(b,key)); } catch(Exception e) { return null; } }
}
