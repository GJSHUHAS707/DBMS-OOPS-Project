const context=window.location.pathname.replace(/\/index\.html$/,'').replace(/\/$/,'');
const api=`${context}/api`;
const demoMovies=[
{id:1,title:'Interstellar',genre:'Sci-Fi • Adventure',durationMinutes:169,rating:'U/A',description:'A team travels beyond this galaxy in a mission that could decide humanity’s future.',posterUrl:'https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg'},
{id:2,title:'The Dark Knight',genre:'Action • Crime',durationMinutes:152,rating:'U/A',description:'A city faces its greatest test as a masked hero confronts a chaotic criminal.',posterUrl:'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg'},
{id:3,title:'Your Name',genre:'Animation • Fantasy',durationMinutes:106,rating:'U/A',description:'Two teenagers discover an extraordinary connection across time and distance.',posterUrl:'https://image.tmdb.org/t/p/w500/q719jXXEzOoYaps6babg.knONONX.jpg'}];
let movies=[],activeMovie=null,selectedSeats=new Set(),ticketPrice=0;
const grid=document.getElementById('movieGrid');
function esc(v=''){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function renderMovies(){grid.innerHTML=movies.map(m=>`<article class="movie-card"><div class="poster"><img src="${esc(m.posterUrl||'')}" alt="${esc(m.title)} poster" loading="lazy" onerror="this.style.opacity='.15'"><span class="rating">✦ ${esc(m.rating||'U/A')}</span></div><div class="movie-info"><h3>${esc(m.title)}</h3><p>${esc(m.description||m.genre)}</p><div class="movie-meta"><span>${esc(m.genre)}</span><span>${Number(m.durationMinutes)} min</span></div><button class="book-btn" data-id="${Number(m.id)}">Choose showtime ↗</button></div></article>`).join('');grid.querySelectorAll('.book-btn').forEach(b=>b.addEventListener('click',()=>openBooking(Number(b.dataset.id))));}
async function loadMovies(){try{const r=await fetch(`${api}/movies`);if(!r.ok)throw Error();const d=await r.json();movies=d.length?d:demoMovies;}catch{movies=demoMovies;}renderMovies();}
async function openBooking(id){
 activeMovie=movies.find(m=>Number(m.id)===id)||demoMovies[0];selectedSeats.clear();
 document.getElementById('movieId').value=activeMovie.id;document.getElementById('movieSummary').textContent=`${activeMovie.title} · Choose a showtime and seats`;
 const sel=document.getElementById('showtimeId');sel.innerHTML='<option>Loading showtimes…</option>';
 document.getElementById('modal').classList.remove('hidden');
 try{
  const r=await fetch(`${api}/showtimes?movieId=${encodeURIComponent(activeMovie.id)}`);if(!r.ok)throw Error();
  const shows=await r.json();if(!shows.length){sel.innerHTML='<option value="">No future showtimes</option>';ticketPrice=0;buildSeats([]);updateTotal();message('No future showtimes. Add one in MySQL.',true);return;}
  sel.innerHTML=shows.map(s=>`<option value="${Number(s.id)}" data-price="${Number(s.ticketPrice)}">${esc(s.showDate)} · ${esc(s.showTime.slice(0,5))} · ${esc(s.cinemaName)} · ₹${Number(s.ticketPrice)}</option>`).join('');
  sel.onchange=loadSeats;await loadSeats();
 }catch{sel.innerHTML='<option value="">Showtimes unavailable</option>';ticketPrice=0;buildSeats([]);updateTotal();message('Could not load live showtimes. Check Tomcat and MySQL.',true);}
}
async function loadSeats(){
 selectedSeats.clear();const sel=document.getElementById('showtimeId').selectedOptions[0];if(!sel||!sel.value)return;
 ticketPrice=Number(sel.dataset.price||0);
 try{const r=await fetch(`${api}/seats?showtimeId=${encodeURIComponent(sel.value)}`,{cache:'no-store'});if(!r.ok)throw Error();const d=await r.json();buildSeats(d.occupiedSeats||[]);message('Select your available seats.');}
 catch{buildSeats([]);message('Could not check seat availability. Refresh and try again.',true);}updateTotal();
}
function buildSeats(occupied=[]){const wrap=document.getElementById('seatGrid');wrap.innerHTML='';const booked=new Set(occupied.map(s=>String(s).trim().toUpperCase()));
 for(let row=0;row<4;row++)for(let col=1;col<=6;col++){const s=String.fromCharCode(65+row)+col,b=document.createElement('button');b.type='button';b.className=booked.has(s)?'seat booked':'seat';b.textContent=s;b.disabled=booked.has(s);
 if(b.disabled){b.title='Already booked';b.setAttribute('aria-label',`${s}, booked and unavailable`);}
 else{b.setAttribute('aria-pressed','false');b.addEventListener('click',()=>{if(selectedSeats.has(s))selectedSeats.delete(s);else if(selectedSeats.size<4)selectedSeats.add(s);else{message('Choose up to four seats.',true);return;}b.classList.toggle('selected',selectedSeats.has(s));b.setAttribute('aria-pressed',String(selectedSeats.has(s)));updateTotal();});}wrap.appendChild(b);}}
function updateTotal(){document.getElementById('total').textContent=`₹${ticketPrice*selectedSeats.size}`;}
function message(t,err=false){const e=document.getElementById('formMessage');e.textContent=t;e.className=err?'form-message error':'form-message';}
document.getElementById('closeModal').addEventListener('click',()=>document.getElementById('modal').classList.add('hidden'));
document.getElementById('modal').addEventListener('click',e=>{if(e.target.id==='modal')e.currentTarget.classList.add('hidden')});
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.getElementById('modal').classList.add('hidden')});
document.getElementById('bookingForm').addEventListener('submit',async e=>{
 e.preventDefault();if(!selectedSeats.size){message('Please choose at least one available seat.',true);return;}
 const payload={customerName:document.getElementById('customerName').value.trim(),email:document.getElementById('email').value.trim(),movieId:Number(document.getElementById('movieId').value),showtimeId:Number(document.getElementById('showtimeId').value),seats:[...selectedSeats]};
 const b=e.currentTarget.querySelector('button[type=submit]');b.disabled=true;b.textContent='Saving booking…';
 try{const r=await fetch(`${api}/bookings`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});const d=await r.json();if(!r.ok)throw Error(d.error||'Booking failed');message(`Booking confirmed! Reference: ${d.reference}. Total: ₹${d.totalAmount}. Demo payment only.`);await loadSeats();}
 catch(err){message(err.message||'Booking failed. Check server.',true);}
 finally{b.disabled=false;b.innerHTML='Confirm booking <span>↗</span>';}
});
loadMovies();
