# CineBook — Movie Ticket Booking Website
Java OOP + Servlets + JDBC + MySQL + HTML/CSS/JavaScript.

## Setup
1. Run `database/schema.sql` in MySQL Workbench.
2. Update credentials in `src/main/java/com/cinebook/util/DBConnection.java`.
3. Run `mvn clean package`.
4. Deploy `target/cinebook.war` to Tomcat 10.1+.
5. Open `http://localhost:8080/cinebook/`.

## Endpoints
- `GET /api/movies`
- `GET /api/showtimes?movieId=1`
- `GET /api/seats?showtimeId=1`
- `POST /api/bookings`

The payment implementation is a demo only. For production, use normalized seat records with a unique constraint on `(showtime_id, seat_code)`, transactions/locking, authentication, CSRF protection and a real payment provider's test mode.


### Booked-seat visibility fix
The seat picker now shows a legend (Available / Selected / Booked), colors booked seats red with a strike-through, normalizes seat codes, and requests fresh seat data without browser caching. Rebuild and redeploy the WAR after extracting this project. Existing confirmed bookings in MySQL are what mark seats as booked.


## Admin dashboard (added)
1. Open `http://localhost:8080/cinebook/admin.html`.
2. Demo admin password: `ChangeThisAdmin123!`.
3. Before sharing or presenting, change `ADMIN_PASSWORD` in `src/main/java/com/cinebook/servlet/AdminServlet.java`.
4. Rebuild with `mvn clean package`, then redeploy `target/cinebook.war`.
5. Use the dashboard to add movies, create showtimes, edit ticket prices, and delete records that are not referenced by bookings.

Security note: this is a student/demo implementation. For public deployment, use proper password hashing, CSRF protection, role management, HTTPS, environment-based secrets, and server-side validation. Do not expose the demo admin password on a public website.
