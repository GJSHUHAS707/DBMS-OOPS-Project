package com.cinema.booking.dto.show;

import com.cinema.booking.entity.ShowStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ShowResponse {
    private Long id;
    private Long movieId;
    private String movieTitle;
    private String moviePosterUrl;
    private Integer movieDurationMinutes;
    private String movieLanguage;
    private String movieGenre;

    private Long theaterId;
    private String theaterName;
    private String theaterCity;

    private Long screenId;
    private String screenName;
    private String format;
    private Integer totalRows;
    private Integer totalCols;

    private LocalDate showDate;
    private LocalTime showTime;
    private ShowStatus status;

    private BigDecimal startingPrice;
    private Integer availableSeatsCount;
    private Integer totalSeatsCount;
}
