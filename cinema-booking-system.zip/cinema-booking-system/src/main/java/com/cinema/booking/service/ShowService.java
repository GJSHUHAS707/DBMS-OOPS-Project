package com.cinema.booking.service;

import com.cinema.booking.dto.show.ShowRequest;
import com.cinema.booking.dto.show.ShowResponse;
import com.cinema.booking.dto.show.ShowSeatResponse;
import com.cinema.booking.entity.Movie;
import com.cinema.booking.entity.Screen;
import com.cinema.booking.entity.Seat;
import com.cinema.booking.entity.Show;
import com.cinema.booking.exception.ResourceNotFoundException;
import com.cinema.booking.repository.BookingSeatRepository;
import com.cinema.booking.repository.MovieRepository;
import com.cinema.booking.repository.ScreenRepository;
import com.cinema.booking.repository.SeatRepository;
import com.cinema.booking.repository.ShowRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ShowService {

    private final ShowRepository showRepository;
    private final MovieRepository movieRepository;
    private final ScreenRepository screenRepository;
    private final SeatRepository seatRepository;
    private final BookingSeatRepository bookingSeatRepository;

    @Transactional(readOnly = true)
    public List<ShowResponse> getShowsByMovie(Long movieId, LocalDate date) {
        return showRepository.findByMovieIdAndOptionalDate(movieId, date)
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ShowResponse> getAllShows() {
        return showRepository.findAllByOrderByShowDateAscShowTimeAsc()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ShowResponse getShowById(Long id) {
        Show show = showRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Show not found with id: " + id));
        return toResponse(show);
    }

    @Transactional(readOnly = true)
    public List<ShowSeatResponse> getShowSeatMap(Long showId) {
        Show show = showRepository.findById(showId)
                .orElseThrow(() -> new ResourceNotFoundException("Show not found with id: " + showId));

        List<Seat> seats = seatRepository.findByScreenIdOrderByRowNumberAscColNumberAsc(show.getScreen().getId());
        List<Long> bookedSeatIdsList = bookingSeatRepository.findBookedSeatIdsByShowId(showId);
        Set<Long> bookedSeatIds = new HashSet<>(bookedSeatIdsList);

        return seats.stream().map(seat -> ShowSeatResponse.builder()
                .id(seat.getId())
                .rowNumber(seat.getRowNumber())
                .colNumber(seat.getColNumber())
                .type(seat.getType())
                .price(seat.getPrice())
                .booked(bookedSeatIds.contains(seat.getId()))   
                .build()
        ).collect(Collectors.toList());
    }

    @Transactional
    public ShowResponse createShow(ShowRequest request) {
        Movie movie = movieRepository.findById(request.getMovieId())
                .orElseThrow(() -> new ResourceNotFoundException("Movie not found with id: " + request.getMovieId()));

        Screen screen = screenRepository.findById(request.getScreenId())
                .orElseThrow(() -> new ResourceNotFoundException("Screen not found with id: " + request.getScreenId()));

        Show show = Show.builder()
                .movie(movie)
                .screen(screen)
                .showDate(request.getShowDate())
                .showTime(request.getShowTime())
                .status(request.getStatus())
                .build();

        return toResponse(showRepository.save(show));
    }

    @Transactional
    public ShowResponse updateShow(Long id, ShowRequest request) {
        Show show = showRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Show not found with id: " + id));

        Movie movie = movieRepository.findById(request.getMovieId())
                .orElseThrow(() -> new ResourceNotFoundException("Movie not found with id: " + request.getMovieId()));

        Screen screen = screenRepository.findById(request.getScreenId())
                .orElseThrow(() -> new ResourceNotFoundException("Screen not found with id: " + request.getScreenId()));

        show.setMovie(movie);
        show.setScreen(screen);
        show.setShowDate(request.getShowDate());
        show.setShowTime(request.getShowTime());
        show.setStatus(request.getStatus());

        return toResponse(showRepository.save(show));
    }

    @Transactional
    public void deleteShow(Long id) {
        if (!showRepository.existsById(id)) {
            throw new ResourceNotFoundException("Show not found with id: " + id);
        }
        showRepository.deleteById(id);
    }

    public ShowResponse toResponse(Show show) {
        List<Seat> seats = seatRepository.findByScreenIdOrderByRowNumberAscColNumberAsc(show.getScreen().getId());
        List<Long> bookedSeatIds = bookingSeatRepository.findBookedSeatIdsByShowId(show.getId());

        int totalSeats = seats.size();
        int bookedCount = bookedSeatIds.size();
        int availableSeats = Math.max(0, totalSeats - bookedCount);

        BigDecimal minPrice = seats.stream()
                .map(Seat::getPrice)
                .min(BigDecimal::compareTo)
                .orElse(BigDecimal.ZERO);

        String screenName = show.getScreen().getName();
        String format = "2D";
        if (screenName != null) {
            String upper = screenName.toUpperCase();
            if (upper.contains("IMAX")) {
                format = "IMAX";
            } else if (upper.contains("3D") || upper.contains("DOLBY")) {
                format = "3D";
            }
        }

        return ShowResponse.builder()
                .id(show.getId())
                .movieId(show.getMovie().getId())
                .movieTitle(show.getMovie().getTitle())
                .moviePosterUrl(show.getMovie().getPosterUrl())
                .movieDurationMinutes(show.getMovie().getDurationMinutes())
                .movieLanguage(show.getMovie().getLanguage())
                .movieGenre(show.getMovie().getGenre())
                .theaterId(show.getScreen().getTheater() != null ? show.getScreen().getTheater().getId() : null)
                .theaterName(show.getScreen().getTheater() != null ? show.getScreen().getTheater().getName() : "")
                .theaterCity(show.getScreen().getTheater() != null ? show.getScreen().getTheater().getCity() : "")
                .screenId(show.getScreen().getId())
                .screenName(show.getScreen().getName())
                .format(format)
                .totalRows(show.getScreen().getTotalRows())
                .totalCols(show.getScreen().getTotalCols())
                .showDate(show.getShowDate())
                .showTime(show.getShowTime())
                .status(show.getStatus())
                .startingPrice(minPrice)
                .availableSeatsCount(availableSeats)
                .totalSeatsCount(totalSeats)
                .build();
    }
}
