package com.cinema.booking.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "`seats`", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"screen_id", "`row_number`", "`col_number`"})
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Seat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "screen_id", nullable = false)
    @JsonIgnore
    private Screen screen;

    @Column(name = "`row_number`", nullable = false)
    private Integer rowNumber;

    @Column(name = "`col_number`", nullable = false)
    private Integer colNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "`type`", nullable = false, length = 20)
    private SeatType type;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal price;
}
