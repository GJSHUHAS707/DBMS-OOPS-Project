package com.cinema.booking.controller;

import com.cinema.booking.dto.common.ApiResponse;
import com.cinema.booking.dto.movie.MovieResponse;
import com.cinema.booking.service.MovieService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/movies")
@RequiredArgsConstructor
public class MovieController {

    private final MovieService movieService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<MovieResponse>>> getMovies(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String genre,
            @RequestParam(required = false) String language,
            @RequestParam(required = false) String status) {
        List<MovieResponse> movies = movieService.getAllMovies(search, genre, language, status);
        return ResponseEntity.ok(ApiResponse.ok(movies));
    }

    @GetMapping("/upcoming")
    public ResponseEntity<ApiResponse<List<MovieResponse>>> getUpcomingMovies() {
        List<MovieResponse> movies = movieService.getUpcomingMovies();
        return ResponseEntity.ok(ApiResponse.ok(movies));
    }

    @GetMapping("/now-showing")
    public ResponseEntity<ApiResponse<List<MovieResponse>>> getNowShowingMovies() {
        List<MovieResponse> movies = movieService.getNowShowingMovies();
        return ResponseEntity.ok(ApiResponse.ok(movies));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<MovieResponse>> getMovieById(@PathVariable Long id) {
        MovieResponse movie = movieService.getMovieById(id);
        return ResponseEntity.ok(ApiResponse.ok(movie));
    }

    @PostMapping("/{id}/interest")
    public ResponseEntity<ApiResponse<Integer>> expressInterest(@PathVariable Long id) {
        Integer newCount = movieService.incrementInterestedCount(id);
        return ResponseEntity.ok(ApiResponse.ok("Interest recorded", newCount));
    }
}
