package com.cinema.booking.repository;

import com.cinema.booking.entity.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Long> {

    @Query("SELECT m FROM Movie m WHERE " +
           "(:search IS NULL OR LOWER(m.title) LIKE LOWER(CONCAT('%', :search, '%'))) AND " +
           "(:genre IS NULL OR LOWER(m.genre) = LOWER(:genre)) AND " +
           "(:language IS NULL OR LOWER(m.language) = LOWER(:language)) AND " +
           "(:status IS NULL OR (:status = 'upcoming' AND m.releaseDate > CURRENT_DATE) OR (:status = 'now_showing' AND m.releaseDate <= CURRENT_DATE)) " +
           "ORDER BY CASE WHEN :status = 'upcoming' THEN m.releaseDate END ASC, m.releaseDate DESC")
    List<Movie> searchMoviesWithStatus(@Param("search") String search,
                                       @Param("genre") String genre,
                                       @Param("language") String language,
                                       @Param("status") String status);

    default List<Movie> searchMovies(String search, String genre, String language) {
        return searchMoviesWithStatus(search, genre, language, null);
    }

    List<Movie> findByReleaseDateAfterOrderByReleaseDateAsc(LocalDate date);

    List<Movie> findByReleaseDateLessThanEqualOrderByReleaseDateDesc(LocalDate date);
}
