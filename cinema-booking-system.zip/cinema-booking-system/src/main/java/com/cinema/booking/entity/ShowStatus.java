package com.cinema.booking.entity;

public enum ShowStatus {
    UPCOMING,
    COMPLETED
}
