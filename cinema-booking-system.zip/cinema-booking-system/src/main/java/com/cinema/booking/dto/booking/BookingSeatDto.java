package com.cinema.booking.dto.booking;

import com.cinema.booking.entity.SeatType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookingSeatDto {
    private Long seatId;
    private Integer rowNumber;
    private Integer colNumber;
    private SeatType type;
    private BigDecimal price;
    private String seatLabel; // e.g. "Row 3, Seat 5"
}
