package com.cinema.booking.service;

import com.cinema.booking.dto.booking.BookingRequest;
import com.cinema.booking.dto.booking.BookingResponse;
import com.cinema.booking.dto.booking.BookingSeatDto;
import com.cinema.booking.entity.*;
import com.cinema.booking.exception.BadRequestException;
import com.cinema.booking.exception.ResourceNotFoundException;
import com.cinema.booking.exception.SeatAlreadyBookedException;
import com.cinema.booking.exception.UnauthorizedException;
import com.cinema.booking.repository.BookingRepository;
import com.cinema.booking.repository.BookingSeatRepository;
import com.cinema.booking.repository.SeatRepository;
import com.cinema.booking.repository.ShowRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepository;
    private final BookingSeatRepository bookingSeatRepository;
    private final ShowRepository showRepository;
    private final SeatRepository seatRepository;

    @Transactional(isolation = Isolation.SERIALIZABLE)
    public synchronized BookingResponse createBooking(BookingRequest request, User user) {
        if (user == null) {
            throw new UnauthorizedException("Authentication required to create a booking");
        }

        if (request.getSeatIds() == null || request.getSeatIds().isEmpty()) {
            throw new BadRequestException("At least one seat must be selected");
        }

        // Remove any duplicates in requested seatIds
        List<Long> requestedSeatIds = request.getSeatIds().stream().distinct().collect(Collectors.toList());

        Show show = showRepository.findById(request.getShowId())
                .orElseThrow(() -> new ResourceNotFoundException("Show not found with id: " + request.getShowId()));

        if (show.getStatus() == ShowStatus.COMPLETED) {
            throw new BadRequestException("Cannot book tickets for a completed show");
        }

        // Fetch seat entities
        List<Seat> seats = seatRepository.findByIdIn(requestedSeatIds);
        if (seats.size() != requestedSeatIds.size()) {
            throw new BadRequestException("One or more selected seats do not exist");
        }

        // Verify seats belong to this show's screen
        Long screenId = show.getScreen().getId();
        for (Seat seat : seats) {
            if (!seat.getScreen().getId().equals(screenId)) {
                throw new BadRequestException("Seat " + seat.getId() + " does not belong to the show's screen");
            }
        }

        // Concurrency check: check if any seat is already booked for this show in a CONFIRMED booking
        List<Long> alreadyBookedIds = bookingSeatRepository.findAlreadyBookedSeatIds(show.getId(), requestedSeatIds);
        if (!alreadyBookedIds.isEmpty()) {
            List<String> bookedSeatLabels = seats.stream()
                    .filter(s -> alreadyBookedIds.contains(s.getId()))
                    .map(s -> "Row " + s.getRowNumber() + "-Seat " + s.getColNumber())
                    .collect(Collectors.toList());

            throw new SeatAlreadyBookedException("The following seat(s) are already booked: " +
                    String.join(", ", bookedSeatLabels) + ". Please select different seats.");
        }

        // Calculate total price
        BigDecimal totalAmount = seats.stream()
                .map(Seat::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // Add snacks amount if selected
        if (request.getSnacksAmount() != null && request.getSnacksAmount().compareTo(BigDecimal.ZERO) > 0) {
            totalAmount = totalAmount.add(request.getSnacksAmount());
        }

        // Build Booking entity
        Booking booking = Booking.builder()
                .user(user)
                .show(show)
                .totalAmount(totalAmount)
                .snacks(request.getSnacks())
                .status(BookingStatus.CONFIRMED)
                .build();

        List<BookingSeat> bookingSeats = new ArrayList<>();
        for (Seat seat : seats) {
            BookingSeat bs = BookingSeat.builder()
                    .booking(booking)
                    .seat(seat)
                    .build();
            bookingSeats.add(bs);
        }
        booking.setBookingSeats(bookingSeats);

        Booking savedBooking = bookingRepository.save(booking);
        return toResponse(savedBooking);
    }

    @Transactional(readOnly = true)
    public List<BookingResponse> getMyBookings(Long userId) {
        return bookingRepository.findByUserIdOrderByCreatedAtDesc(userId)
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<BookingResponse> getAllBookings() {
        return bookingRepository.findAllByOrderByCreatedAtDesc()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public BookingResponse getBookingById(Long id, User currentUser) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + id));

        boolean isAdmin = currentUser != null && currentUser.getRole() == Role.ADMIN;
        boolean isOwner = currentUser != null && booking.getUser() != null &&
                booking.getUser().getId().longValue() == currentUser.getId().longValue();

        if (!isAdmin && !isOwner) {
            throw new UnauthorizedException("You are not authorized to view this booking");
        }

        return toResponse(booking);
    }

    @Transactional
    public BookingResponse cancelBooking(Long id, User currentUser) {
        if (currentUser == null) {
            throw new UnauthorizedException("Authentication required to cancel a booking");
        }

        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + id));

        boolean isAdmin = currentUser.getRole() == Role.ADMIN;
        boolean isOwner = booking.getUser() != null &&
                booking.getUser().getId().longValue() == currentUser.getId().longValue();

        // Authorization check: only owner or ADMIN can cancel
        if (!isAdmin && !isOwner) {
            throw new UnauthorizedException("You are not authorized to cancel this booking");
        }

        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new BadRequestException("This booking is already cancelled");
        }

        // Business rule: Cancelled bookings release seats immediately!
        booking.setStatus(BookingStatus.CANCELLED);
        Booking updated = bookingRepository.saveAndFlush(booking);

        return toResponse(updated);
    }

    public BookingResponse toResponse(Booking booking) {
        List<BookingSeatDto> seatDtos = (booking.getBookingSeats() != null)
                ? booking.getBookingSeats().stream()
                    .map(bs -> BookingSeatDto.builder()
                            .seatId(bs.getSeat().getId())
                            .rowNumber(bs.getSeat().getRowNumber())
                            .colNumber(bs.getSeat().getColNumber())
                            .type(bs.getSeat().getType())
                            .price(bs.getSeat().getPrice())
                            .seatLabel("Row " + bs.getSeat().getRowNumber() + " - Seat " + bs.getSeat().getColNumber())
                            .build())
                    .collect(Collectors.toList())
                : Collections.emptyList();

        Show show = booking.getShow();
        Screen screen = show != null ? show.getScreen() : null;
        Theater theater = screen != null ? screen.getTheater() : null;
        Movie movie = show != null ? show.getMovie() : null;

        return BookingResponse.builder()
                .id(booking.getId())
                .userId(booking.getUser() != null ? booking.getUser().getId() : null)
                .userName(booking.getUser() != null ? booking.getUser().getName() : "")
                .userEmail(booking.getUser() != null ? booking.getUser().getEmail() : "")
                .showId(show != null ? show.getId() : null)
                .movieId(movie != null ? movie.getId() : null)
                .movieTitle(movie != null ? movie.getTitle() : "")
                .moviePosterUrl(movie != null ? movie.getPosterUrl() : null)
                .theaterName(theater != null ? theater.getName() : "")
                .theaterCity(theater != null ? theater.getCity() : "")
                .theaterAddress(theater != null ? theater.getAddress() : "")
                .screenName(screen != null ? screen.getName() : "")
                .showDate(show != null ? show.getShowDate() : null)
                .showTime(show != null ? show.getShowTime() : null)
                .seats(seatDtos)
                .snacks(booking.getSnacks())
                .totalAmount(booking.getTotalAmount())
                .status(booking.getStatus())
                .createdAt(booking.getCreatedAt())
                .build();
    }
}
