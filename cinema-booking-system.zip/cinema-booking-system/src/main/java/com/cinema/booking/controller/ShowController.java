package com.cinema.booking.controller;

import com.cinema.booking.dto.common.ApiResponse;
import com.cinema.booking.dto.show.ShowResponse;
import com.cinema.booking.dto.show.ShowSeatResponse;
import com.cinema.booking.service.ShowService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/shows")
@RequiredArgsConstructor
public class ShowController {

    private final ShowService showService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<ShowResponse>>> getShows(
            @RequestParam(required = false) Long movieId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<ShowResponse> shows;
        if (movieId != null) {
            shows = showService.getShowsByMovie(movieId, date);
        } else {
            shows = showService.getAllShows();
        }
        return ResponseEntity.ok(ApiResponse.ok(shows));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ShowResponse>> getShowById(@PathVariable Long id) {
        ShowResponse show = showService.getShowById(id);
        return ResponseEntity.ok(ApiResponse.ok(show));
    }

    @GetMapping("/{id}/seats")
    public ResponseEntity<ApiResponse<List<ShowSeatResponse>>> getShowSeats(@PathVariable Long id) {
        List<ShowSeatResponse> seatMap = showService.getShowSeatMap(id);
        return ResponseEntity.ok(ApiResponse.ok(seatMap));
    }
}
