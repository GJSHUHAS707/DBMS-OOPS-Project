package com.cinema.booking.dto.movie;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MovieResponse {
    private Long id;
    private String title;
    private String description;
    private String genre;
    private String language;
    private Integer durationMinutes;
    private String posterUrl;
    private LocalDate releaseDate;
    private Boolean isUpcoming;
    private Integer interestedCount;
    private Integer bookedLastHour;
    private java.util.List<String> availableFormats;
    private String director;
    private java.util.List<CastMemberDto> cast;
    private java.util.List<CrewMemberDto> crew;
}
