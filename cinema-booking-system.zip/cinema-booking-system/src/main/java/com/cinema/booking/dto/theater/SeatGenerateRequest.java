package com.cinema.booking.dto.theater;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SeatGenerateRequest {

    @NotNull(message = "Regular seat price is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Price must be greater than 0")
    @Builder.Default
    private BigDecimal regularPrice = new BigDecimal("10.00");

    @NotNull(message = "Premium seat price is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Price must be greater than 0")
    @Builder.Default
    private BigDecimal premiumPrice = new BigDecimal("15.00");

    @NotNull(message = "VIP seat price is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Price must be greater than 0")
    @Builder.Default
    private BigDecimal vipPrice = new BigDecimal("20.00");

    // Optional tier splitting configuration:
    // If not provided, rows are divided proportionally (e.g. 50% regular, 30% premium, 20% VIP)
    private Integer premiumStartRow;
    private Integer vipStartRow;
}
