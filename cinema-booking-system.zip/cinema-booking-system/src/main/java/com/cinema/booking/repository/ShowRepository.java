package com.cinema.booking.repository;

import com.cinema.booking.entity.Show;
import com.cinema.booking.entity.ShowStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ShowRepository extends JpaRepository<Show, Long> {

    List<Show> findByMovieId(Long movieId);

    @Query("SELECT s FROM Show s WHERE s.movie.id = :movieId " +
           "AND (:showDate IS NULL OR s.showDate = :showDate) " +
           "ORDER BY s.showDate ASC, s.showTime ASC")
    List<Show> findByMovieIdAndOptionalDate(@Param("movieId") Long movieId,
                                            @Param("showDate") LocalDate showDate);

    List<Show> findByMovieIdAndStatusOrderByShowDateAscShowTimeAsc(Long movieId, ShowStatus status);

    List<Show> findByScreenId(Long screenId);

    List<Show> findAllByOrderByShowDateAscShowTimeAsc();
}
