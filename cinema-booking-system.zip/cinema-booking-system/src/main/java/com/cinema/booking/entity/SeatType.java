package com.cinema.booking.entity;

public enum SeatType {
    REGULAR,
    PREMIUM,
    VIP
}
