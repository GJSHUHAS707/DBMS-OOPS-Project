package com.cinema.booking.controller;

import com.cinema.booking.dto.booking.BookingRequest;
import com.cinema.booking.dto.booking.BookingResponse;
import com.cinema.booking.dto.common.ApiResponse;
import com.cinema.booking.entity.User;
import com.cinema.booking.exception.UnauthorizedException;
import com.cinema.booking.repository.UserRepository;
import com.cinema.booking.service.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;
    private final UserRepository userRepository;

    @PostMapping
    public ResponseEntity<ApiResponse<BookingResponse>> createBooking(
            @Valid @RequestBody BookingRequest request,
            @AuthenticationPrincipal User user,
            Principal principal) {
        User currentUser = resolveUser(user, principal);
        BookingResponse booking = bookingService.createBooking(request, currentUser);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Booking confirmed successfully", booking));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<List<BookingResponse>>> getMyBookings(
            @AuthenticationPrincipal User user,
            Principal principal) {
        User currentUser = resolveUser(user, principal);
        List<BookingResponse> bookings = bookingService.getMyBookings(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.ok(bookings));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<BookingResponse>> getBookingById(
            @PathVariable Long id,
            @AuthenticationPrincipal User user,
            Principal principal) {
        User currentUser = resolveUser(user, principal);
        BookingResponse booking = bookingService.getBookingById(id, currentUser);
        return ResponseEntity.ok(ApiResponse.ok(booking));
    }

    @RequestMapping(value = "/{id}/cancel", method = {RequestMethod.PUT, RequestMethod.POST})
    public ResponseEntity<ApiResponse<BookingResponse>> cancelBooking(
            @PathVariable Long id,
            @AuthenticationPrincipal User user,
            Principal principal) {
        User currentUser = resolveUser(user, principal);
        BookingResponse cancelled = bookingService.cancelBooking(id, currentUser);
        return ResponseEntity.ok(ApiResponse.ok("Booking cancelled successfully. Seats have been released.", cancelled));
    }

    private User resolveUser(User user, Principal principal) {
        if (user != null) {
            return user;
        }
        if (principal != null && principal.getName() != null) {
            return userRepository.findByEmail(principal.getName())
                    .orElseThrow(() -> new UnauthorizedException("User session not found. Please log in again."));
        }
        throw new UnauthorizedException("Authentication required. Please log in.");
    }
}
