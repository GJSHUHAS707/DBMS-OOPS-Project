package com.cinema.booking.controller;

import com.cinema.booking.dto.admin.AdminStatsResponse;
import com.cinema.booking.dto.booking.BookingResponse;
import com.cinema.booking.dto.common.ApiResponse;
import com.cinema.booking.dto.movie.MovieRequest;
import com.cinema.booking.dto.movie.MovieResponse;
import com.cinema.booking.dto.show.ShowRequest;
import com.cinema.booking.dto.show.ShowResponse;
import com.cinema.booking.dto.theater.*;
import com.cinema.booking.entity.User;
import com.cinema.booking.exception.UnauthorizedException;
import com.cinema.booking.repository.UserRepository;
import com.cinema.booking.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminController {

    private final MovieService movieService;
    private final TheaterService theaterService;
    private final ScreenService screenService;
    private final ShowService showService;
    private final BookingService bookingService;
    private final AdminService adminService;
    private final UserRepository userRepository;

    // ==============================================================
    // Dashboard Stats & Bookings
    // ==============================================================
    @GetMapping("/stats")
    public ResponseEntity<ApiResponse<AdminStatsResponse>> getStats() {
        return ResponseEntity.ok(ApiResponse.ok(adminService.getStats()));
    }

    @GetMapping("/bookings")
    public ResponseEntity<ApiResponse<List<BookingResponse>>> getAllBookings() {
        return ResponseEntity.ok(ApiResponse.ok(bookingService.getAllBookings()));
    }

    // ==============================================================
    // Movies CRUD
    // ==============================================================
    @GetMapping("/movies")
    public ResponseEntity<ApiResponse<List<MovieResponse>>> getMovies() {
        return ResponseEntity.ok(ApiResponse.ok(movieService.getAllMovies(null, null, null)));
    }

    @PostMapping("/movies")
    public ResponseEntity<ApiResponse<MovieResponse>> createMovie(@Valid @RequestBody MovieRequest request) {
        MovieResponse movie = movieService.createMovie(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Movie created successfully", movie));
    }

    @PutMapping("/movies/{id}")
    public ResponseEntity<ApiResponse<MovieResponse>> updateMovie(
            @PathVariable Long id,
            @Valid @RequestBody MovieRequest request) {
        MovieResponse movie = movieService.updateMovie(id, request);
        return ResponseEntity.ok(ApiResponse.ok("Movie updated successfully", movie));
    }

    @DeleteMapping("/movies/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteMovie(@PathVariable Long id) {
        movieService.deleteMovie(id);
        return ResponseEntity.ok(ApiResponse.ok("Movie deleted successfully", null));
    }

    // ==============================================================
    // Theaters CRUD
    // ==============================================================
    @GetMapping("/theaters")
    public ResponseEntity<ApiResponse<List<TheaterResponse>>> getTheaters() {
        return ResponseEntity.ok(ApiResponse.ok(theaterService.getAllTheaters()));
    }

    @GetMapping("/theaters/{id}")
    public ResponseEntity<ApiResponse<TheaterResponse>> getTheaterById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok(theaterService.getTheaterById(id)));
    }

    @PostMapping("/theaters")
    public ResponseEntity<ApiResponse<TheaterResponse>> createTheater(@Valid @RequestBody TheaterRequest request) {
        TheaterResponse theater = theaterService.createTheater(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Theater created successfully", theater));
    }

    @PutMapping("/theaters/{id}")
    public ResponseEntity<ApiResponse<TheaterResponse>> updateTheater(
            @PathVariable Long id,
            @Valid @RequestBody TheaterRequest request) {
        TheaterResponse theater = theaterService.updateTheater(id, request);
        return ResponseEntity.ok(ApiResponse.ok("Theater updated successfully", theater));
    }

    @DeleteMapping("/theaters/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteTheater(@PathVariable Long id) {
        theaterService.deleteTheater(id);
        return ResponseEntity.ok(ApiResponse.ok("Theater deleted successfully", null));
    }

    // ==============================================================
    // Screens CRUD & Seat Generation
    // ==============================================================
    @GetMapping("/screens")
    public ResponseEntity<ApiResponse<List<ScreenResponse>>> getAllScreens(
            @RequestParam(required = false) Long theaterId) {
        List<ScreenResponse> screens = (theaterId != null)
                ? screenService.getScreensByTheater(theaterId)
                : screenService.getAllScreens();
        return ResponseEntity.ok(ApiResponse.ok(screens));
    }

    @GetMapping("/screens/{id}")
    public ResponseEntity<ApiResponse<ScreenResponse>> getScreenById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok(screenService.getScreenById(id)));
    }

    @PostMapping("/screens")
    public ResponseEntity<ApiResponse<ScreenResponse>> createScreen(@Valid @RequestBody ScreenRequest request) {
        ScreenResponse screen = screenService.createScreen(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Screen created successfully with auto-generated seats", screen));
    }

    @PutMapping("/screens/{id}")
    public ResponseEntity<ApiResponse<ScreenResponse>> updateScreen(
            @PathVariable Long id,
            @Valid @RequestBody ScreenRequest request) {
        ScreenResponse screen = screenService.updateScreen(id, request);
        return ResponseEntity.ok(ApiResponse.ok("Screen updated successfully", screen));
    }

    @DeleteMapping("/screens/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteScreen(@PathVariable Long id) {
        screenService.deleteScreen(id);
        return ResponseEntity.ok(ApiResponse.ok("Screen deleted successfully", null));
    }

    @PostMapping("/screens/{id}/generate-seats")
    public ResponseEntity<ApiResponse<String>> generateSeats(
            @PathVariable Long id,
            @Valid @RequestBody SeatGenerateRequest request) {
        int seatsCreated = screenService.generateSeats(id, request);
        return ResponseEntity.ok(ApiResponse.ok("Successfully generated " + seatsCreated + " seats for screen", "Seats count: " + seatsCreated));
    }

    // ==============================================================
    // Shows CRUD
    // ==============================================================
    @GetMapping("/shows")
    public ResponseEntity<ApiResponse<List<ShowResponse>>> getShows() {
        return ResponseEntity.ok(ApiResponse.ok(showService.getAllShows()));
    }

    @PostMapping("/shows")
    public ResponseEntity<ApiResponse<ShowResponse>> createShow(@Valid @RequestBody ShowRequest request) {
        ShowResponse show = showService.createShow(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Show scheduled successfully", show));
    }

    @PutMapping("/shows/{id}")
    public ResponseEntity<ApiResponse<ShowResponse>> updateShow(
            @PathVariable Long id,
            @Valid @RequestBody ShowRequest request) {
        ShowResponse show = showService.updateShow(id, request);
        return ResponseEntity.ok(ApiResponse.ok("Show updated successfully", show));
    }

    @DeleteMapping("/shows/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteShow(@PathVariable Long id) {
        showService.deleteShow(id);
        return ResponseEntity.ok(ApiResponse.ok("Show deleted successfully", null));
    }

    @RequestMapping(value = "/bookings/{id}/cancel", method = {RequestMethod.PUT, RequestMethod.POST})
    public ResponseEntity<ApiResponse<BookingResponse>> cancelBookingAsAdmin(
            @PathVariable Long id,
            @AuthenticationPrincipal User admin,
            Principal principal) {
        User currentAdmin = resolveAdmin(admin, principal);
        BookingResponse booking = bookingService.cancelBooking(id, currentAdmin);
        return ResponseEntity.ok(ApiResponse.ok("Booking cancelled by admin. Seats released.", booking));
    }

    private User resolveAdmin(User admin, Principal principal) {
        if (admin != null) {
            return admin;
        }
        if (principal != null && principal.getName() != null) {
            return userRepository.findByEmail(principal.getName())
                    .orElseThrow(() -> new UnauthorizedException("Admin account not found."));
        }
        throw new UnauthorizedException("Admin authentication required.");
    }
}
