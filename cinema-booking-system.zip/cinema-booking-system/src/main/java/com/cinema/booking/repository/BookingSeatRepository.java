package com.cinema.booking.repository;

import com.cinema.booking.entity.BookingSeat;
import com.cinema.booking.entity.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingSeatRepository extends JpaRepository<BookingSeat, Long> {

    @Query("SELECT bs.seat.id FROM BookingSeat bs " +
           "WHERE bs.booking.show.id = :showId " +
           "AND bs.booking.status = :status")
    List<Long> findBookedSeatIdsByShowIdAndStatus(@Param("showId") Long showId,
                                                  @Param("status") BookingStatus status);

    default List<Long> findBookedSeatIdsByShowId(Long showId) {
        return findBookedSeatIdsByShowIdAndStatus(showId, BookingStatus.CONFIRMED);
    }

    @Query("SELECT bs.seat.id FROM BookingSeat bs " +
           "WHERE bs.booking.show.id = :showId " +
           "AND bs.seat.id IN :seatIds " +
           "AND bs.booking.status = :status")
    List<Long> findAlreadyBookedSeatIdsAndStatus(@Param("showId") Long showId,
                                                 @Param("seatIds") List<Long> seatIds,
                                                 @Param("status") BookingStatus status);

    default List<Long> findAlreadyBookedSeatIds(Long showId, List<Long> seatIds) {
        return findAlreadyBookedSeatIdsAndStatus(showId, seatIds, BookingStatus.CONFIRMED);
    }
}
