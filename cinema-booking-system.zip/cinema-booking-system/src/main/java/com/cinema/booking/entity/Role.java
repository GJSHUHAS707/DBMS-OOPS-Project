package com.cinema.booking.entity;

public enum Role {
    USER,
    ADMIN
}
