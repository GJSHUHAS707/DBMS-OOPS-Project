package com.cinema.booking.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.awt.*;
import java.io.IOException;
import java.net.URI;

@Component
@Slf4j
public class BrowserLauncher {

    @Value("${server.port:8080}")
    private int port;

    @Value("${app.open-browser:true}")
    private boolean openBrowser;

    @EventListener(ApplicationReadyEvent.class)
    public void openBrowserOnStart() {
        if (!openBrowser) {
            return;
        }

        String url = "http://localhost:" + port;
        log.info("🚀 Cinema Booking Application is ready! Launching browser at: {}", url);

        String os = System.getProperty("os.name", "").toLowerCase();

        try {
            if (os.contains("win")) {
                new ProcessBuilder("cmd", "/c", "start", url).start();
            } else if (os.contains("mac")) {
                new ProcessBuilder("open", url).start();
            } else if (os.contains("nix") || os.contains("nux")) {
                new ProcessBuilder("xdg-open", url).start();
            } else if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(URI.create(url));
            }
        } catch (IOException e) {
            log.info("Could not auto-open browser ({}). You can open it manually at: {}", e.getMessage(), url);
        }
    }
}
