package com.cinema.booking.dto.admin;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdminStatsResponse {
    private BigDecimal totalRevenue;
    private long totalBookings;
    private long confirmedBookings;
    private long cancelledBookings;
    private long totalUsers;
    private long totalMovies;
    private long totalTheaters;
    private long totalShows;
}
