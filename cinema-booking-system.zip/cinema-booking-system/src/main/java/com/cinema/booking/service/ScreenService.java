package com.cinema.booking.service;

import com.cinema.booking.dto.theater.ScreenRequest;
import com.cinema.booking.dto.theater.ScreenResponse;
import com.cinema.booking.dto.theater.SeatGenerateRequest;
import com.cinema.booking.entity.Screen;
import com.cinema.booking.entity.Seat;
import com.cinema.booking.entity.SeatType;
import com.cinema.booking.entity.Theater;
import com.cinema.booking.exception.ResourceNotFoundException;
import com.cinema.booking.repository.ScreenRepository;
import com.cinema.booking.repository.SeatRepository;
import com.cinema.booking.repository.TheaterRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ScreenService {

    private final ScreenRepository screenRepository;
    private final TheaterRepository theaterRepository;
    private final SeatRepository seatRepository;

    @Transactional(readOnly = true)
    public List<ScreenResponse> getScreensByTheater(Long theaterId) {
        return screenRepository.findByTheaterId(theaterId)
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ScreenResponse> getAllScreens() {
        return screenRepository.findAll()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ScreenResponse getScreenById(Long id) {
        Screen screen = screenRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Screen not found with id: " + id));
        return toResponse(screen);
    }

    @Transactional
    public ScreenResponse createScreen(ScreenRequest request) {
        Theater theater = theaterRepository.findById(request.getTheaterId())
                .orElseThrow(() -> new ResourceNotFoundException("Theater not found with id: " + request.getTheaterId()));

        Screen screen = Screen.builder()
                .theater(theater)
                .name(request.getName().trim())
                .totalRows(request.getTotalRows())
                .totalCols(request.getTotalCols())
                .build();

        screen = screenRepository.save(screen);

        // Auto-generate default seats for the newly created screen
        SeatGenerateRequest defaultGen = SeatGenerateRequest.builder().build();
        generateSeats(screen.getId(), defaultGen);

        return toResponse(screen);
    }

    @Transactional
    public ScreenResponse updateScreen(Long id, ScreenRequest request) {
        Screen screen = screenRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Screen not found with id: " + id));

        Theater theater = theaterRepository.findById(request.getTheaterId())
                .orElseThrow(() -> new ResourceNotFoundException("Theater not found with id: " + request.getTheaterId()));

        screen.setTheater(theater);
        screen.setName(request.getName().trim());
        screen.setTotalRows(request.getTotalRows());
        screen.setTotalCols(request.getTotalCols());

        return toResponse(screenRepository.save(screen));
    }

    @Transactional
    public void deleteScreen(Long id) {
        if (!screenRepository.existsById(id)) {
            throw new ResourceNotFoundException("Screen not found with id: " + id);
        }
        screenRepository.deleteById(id);
    }

    @Transactional
    public int generateSeats(Long screenId, SeatGenerateRequest request) {
        Screen screen = screenRepository.findById(screenId)
                .orElseThrow(() -> new ResourceNotFoundException("Screen not found with id: " + screenId));

        // Clear existing seats for screen
        seatRepository.deleteByScreenId(screenId);

        int totalRows = screen.getTotalRows();
        int totalCols = screen.getTotalCols();

        int premiumStart = (request.getPremiumStartRow() != null)
                ? request.getPremiumStartRow()
                : (int) Math.ceil(totalRows * 0.4) + 1;

        int vipStart = (request.getVipStartRow() != null)
                ? request.getVipStartRow()
                : (int) Math.ceil(totalRows * 0.8) + 1;

        BigDecimal regPrice = (request.getRegularPrice() != null) ? request.getRegularPrice() : new BigDecimal("10.00");
        BigDecimal premPrice = (request.getPremiumPrice() != null) ? request.getPremiumPrice() : new BigDecimal("15.00");
        BigDecimal vipPrice = (request.getVipPrice() != null) ? request.getVipPrice() : new BigDecimal("20.00");

        List<Seat> seats = new ArrayList<>();

        for (int r = 1; r <= totalRows; r++) {
            SeatType type;
            BigDecimal price;

            if (r >= vipStart) {
                type = SeatType.VIP;
                price = vipPrice;
            } else if (r >= premiumStart) {
                type = SeatType.PREMIUM;
                price = premPrice;
            } else {
                type = SeatType.REGULAR;
                price = regPrice;
            }

            for (int c = 1; c <= totalCols; c++) {
                Seat seat = Seat.builder()
                        .screen(screen)
                        .rowNumber(r)
                        .colNumber(c)
                        .type(type)
                        .price(price)
                        .build();
                seats.add(seat);
            }
        }

        seatRepository.saveAll(seats);
        return seats.size();
    }

    public ScreenResponse toResponse(Screen screen) {
        return ScreenResponse.builder()
                .id(screen.getId())
                .theaterId(screen.getTheater() != null ? screen.getTheater().getId() : null)
                .theaterName(screen.getTheater() != null ? screen.getTheater().getName() : "")
                .name(screen.getName())
                .totalRows(screen.getTotalRows())
                .totalCols(screen.getTotalCols())
                .totalSeats(screen.getTotalRows() * screen.getTotalCols())
                .build();
    }
}
