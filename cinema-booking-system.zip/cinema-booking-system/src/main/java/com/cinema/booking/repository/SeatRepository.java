package com.cinema.booking.repository;

import com.cinema.booking.entity.Seat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SeatRepository extends JpaRepository<Seat, Long> {

    List<Seat> findByScreenIdOrderByRowNumberAscColNumberAsc(Long screenId);

    @Modifying
    @Query("DELETE FROM Seat s WHERE s.screen.id = :screenId")
    void deleteByScreenId(@Param("screenId") Long screenId);

    List<Seat> findByIdIn(List<Long> ids);
}
