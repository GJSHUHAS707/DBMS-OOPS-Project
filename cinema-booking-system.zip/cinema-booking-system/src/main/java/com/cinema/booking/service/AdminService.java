package com.cinema.booking.service;

import com.cinema.booking.dto.admin.AdminStatsResponse;
import com.cinema.booking.entity.BookingStatus;
import com.cinema.booking.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final MovieRepository movieRepository;
    private final TheaterRepository theaterRepository;
    private final ShowRepository showRepository;

    @Transactional(readOnly = true)
    public AdminStatsResponse getStats() {
        BigDecimal revenue = bookingRepository.calculateTotalRevenue();
        long totalBookings = bookingRepository.count();
        long confirmedBookings = bookingRepository.countByStatus(BookingStatus.CONFIRMED);
        long cancelledBookings = bookingRepository.countByStatus(BookingStatus.CANCELLED);
        long totalUsers = userRepository.count();
        long totalMovies = movieRepository.count();
        long totalTheaters = theaterRepository.count();
        long totalShows = showRepository.count();

        return AdminStatsResponse.builder()
                .totalRevenue(revenue != null ? revenue : BigDecimal.ZERO)
                .totalBookings(totalBookings)
                .confirmedBookings(confirmedBookings)
                .cancelledBookings(cancelledBookings)
                .totalUsers(totalUsers)
                .totalMovies(totalMovies)
                .totalTheaters(totalTheaters)
                .totalShows(totalShows)
                .build();
    }
}
