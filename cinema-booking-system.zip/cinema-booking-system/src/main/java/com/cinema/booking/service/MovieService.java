package com.cinema.booking.service;

import com.cinema.booking.dto.movie.CastMemberDto;
import com.cinema.booking.dto.movie.CrewMemberDto;
import com.cinema.booking.dto.movie.MovieRequest;
import com.cinema.booking.dto.movie.MovieResponse;
import com.cinema.booking.entity.Movie;
import com.cinema.booking.exception.ResourceNotFoundException;
import com.cinema.booking.repository.MovieRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MovieService {

    private final MovieRepository movieRepository;

    @Transactional(readOnly = true)
    public List<MovieResponse> getAllMovies(String search, String genre, String language) {
        return getAllMovies(search, genre, language, null);
    }

    @Transactional(readOnly = true)
    public List<MovieResponse> getAllMovies(String search, String genre, String language, String status) {
        String s = (search != null && !search.trim().isEmpty()) ? search.trim() : null;
        String g = (genre != null && !genre.trim().isEmpty()) ? genre.trim() : null;
        String l = (language != null && !language.trim().isEmpty()) ? language.trim() : null;
        String stat = (status != null && !status.trim().isEmpty()) ? status.trim().toLowerCase() : null;

        return movieRepository.searchMoviesWithStatus(s, g, l, stat)
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<MovieResponse> getUpcomingMovies() {
        return movieRepository.findByReleaseDateAfterOrderByReleaseDateAsc(LocalDate.now())
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<MovieResponse> getNowShowingMovies() {
        return movieRepository.findByReleaseDateLessThanEqualOrderByReleaseDateDesc(LocalDate.now())
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public MovieResponse getMovieById(Long id) {
        Movie movie = movieRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Movie not found with id: " + id));
        return toResponse(movie);
    }

    @Transactional
    public MovieResponse createMovie(MovieRequest request) {
        Movie movie = Movie.builder()
                .title(request.getTitle().trim())
                .description(request.getDescription())
                .genre(request.getGenre().trim())
                .language(request.getLanguage().trim())
                .durationMinutes(request.getDurationMinutes())
                .posterUrl(request.getPosterUrl())
                .releaseDate(request.getReleaseDate())
                .build();

        return toResponse(movieRepository.save(movie));
    }

    @Transactional
    public MovieResponse updateMovie(Long id, MovieRequest request) {
        Movie movie = movieRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Movie not found with id: " + id));

        movie.setTitle(request.getTitle().trim());
        movie.setDescription(request.getDescription());
        movie.setGenre(request.getGenre().trim());
        movie.setLanguage(request.getLanguage().trim());
        movie.setDurationMinutes(request.getDurationMinutes());
        movie.setPosterUrl(request.getPosterUrl());
        movie.setReleaseDate(request.getReleaseDate());

        return toResponse(movieRepository.save(movie));
    }

    @Transactional
    public void deleteMovie(Long id) {
        if (!movieRepository.existsById(id)) {
            throw new ResourceNotFoundException("Movie not found with id: " + id);
        }
        movieRepository.deleteById(id);
    }

    @Transactional
    public Integer incrementInterestedCount(Long id) {
        Movie movie = movieRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Movie not found with id: " + id));
        int current = (movie.getInterestedCount() != null) ? movie.getInterestedCount() : 0;
        movie.setInterestedCount(current + 1);
        movieRepository.save(movie);
        return getComputedInterestedCount(movie);
    }

    public MovieResponse toResponse(Movie movie) {
        boolean isUpcoming = movie.getReleaseDate() != null && movie.getReleaseDate().isAfter(LocalDate.now());
        return MovieResponse.builder()
                .id(movie.getId())
                .title(movie.getTitle())
                .description(movie.getDescription())
                .genre(movie.getGenre())
                .language(movie.getLanguage())
                .durationMinutes(movie.getDurationMinutes())
                .posterUrl(movie.getPosterUrl())
                .releaseDate(movie.getReleaseDate())
                .isUpcoming(isUpcoming)
                .interestedCount(getComputedInterestedCount(movie))
                .bookedLastHour(isUpcoming ? 0 : getComputedBookedLastHour(movie))
                .availableFormats(parseFormats(movie))
                .director(getDirectorForMovie(movie))
                .cast(getCastForMovie(movie))
                .crew(getCrewForMovie(movie))
                .build();
    }

    private String getDirectorForMovie(Movie movie) {
        if (movie.getDirector() != null && !movie.getDirector().trim().isEmpty()) {
            return movie.getDirector();
        }
        long id = (movie.getId() != null) ? movie.getId() : 1L;
        if (id == 1L || id == 2L || id == 3L) return "Christopher Nolan";
        if (id == 4L) return "Ridley Scott";
        if (id == 5L) return "Denis Villeneuve";
        if (id == 6L) return "Joaquim Dos Santos & Kemp Powers";
        if (id == 7L) return "Anthony & Joe Russo";
        return "Renowned Director";
    }

    private List<CastMemberDto> getCastForMovie(Movie movie) {
        List<CastMemberDto> cast = new ArrayList<>();
        long id = (movie.getId() != null) ? movie.getId() : 1L;

        if (id == 1L) { // Inception
            cast.add(new CastMemberDto("Leonardo DiCaprio", "Dom Cobb", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Joseph Gordon-Levitt", "Arthur", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Elliot Page", "Ariadne", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Tom Hardy", "Eames", "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Ken Watanabe", "Mr. Saito", "https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Cillian Murphy", "Robert Fischer", "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=300&auto=format&fit=crop&q=80"));
        } else if (id == 2L) { // Interstellar
            cast.add(new CastMemberDto("Matthew McConaughey", "Joseph Cooper", "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Anne Hathaway", "Dr. Amelia Brand", "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Jessica Chastain", "Murphy Cooper", "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Michael Caine", "Professor Brand", "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Matt Damon", "Dr. Hugh Mann", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80"));
        } else if (id == 3L) { // The Dark Knight
            cast.add(new CastMemberDto("Christian Bale", "Bruce Wayne / Batman", "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Heath Ledger", "The Joker", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Aaron Eckhart", "Harvey Dent / Two-Face", "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Gary Oldman", "Lt. James Gordon", "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Morgan Freeman", "Lucius Fox", "https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=300&auto=format&fit=crop&q=80"));
        } else if (id == 4L) { // Gladiator II
            cast.add(new CastMemberDto("Paul Mescal", "Lucius Verus", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Pedro Pascal", "Marcus Acacius", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Denzel Washington", "Macrinus", "https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Connie Nielsen", "Lucilla", "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Joseph Quinn", "Emperor Geta", "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=300&auto=format&fit=crop&q=80"));
        } else if (id == 5L) { // Dune: Part Three
            cast.add(new CastMemberDto("Timothée Chalamet", "Paul Atreides / Muad'Dib", "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Zendaya", "Chani", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Florence Pugh", "Princess Irulan Corrino", "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Anya Taylor-Joy", "Alia Atreides", "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Javier Bardem", "Stilgar", "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&auto=format&fit=crop&q=80"));
        } else if (id == 6L) { // Spider-Man: Beyond the Spider-Verse
            cast.add(new CastMemberDto("Shameik Moore", "Miles Morales / Spider-Man", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Hailee Steinfeld", "Gwen Stacy / Spider-Woman", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Oscar Isaac", "Miguel O'Hara / Spider-Man 2099", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Daniel Kaluuya", "Hobart 'Hobie' Brown", "https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Jason Schwartzman", "Jonathan Ohnn / The Spot", "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=300&auto=format&fit=crop&q=80"));
        } else if (id == 7L) { // Avengers: Secret Wars
            cast.add(new CastMemberDto("Robert Downey Jr.", "Victor von Doom / Doctor Doom", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Pedro Pascal", "Reed Richards / Mr. Fantastic", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Chris Hemsworth", "Thor Odinson", "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Benedict Cumberbatch", "Dr. Stephen Strange", "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Tom Holland", "Peter Parker / Spider-Man", "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=300&auto=format&fit=crop&q=80"));
        } else {
            cast.add(new CastMemberDto("Lead Actor", "Protagonist", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80"));
            cast.add(new CastMemberDto("Supporting Actor", "Antagonist", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80"));
        }
        return cast;
    }

    private List<CrewMemberDto> getCrewForMovie(Movie movie) {
        List<CrewMemberDto> crew = new ArrayList<>();
        long id = (movie.getId() != null) ? movie.getId() : 1L;

        if (id == 1L || id == 2L || id == 3L) {
            crew.add(new CrewMemberDto("Christopher Nolan", "Director & Screenplay", ""));
            crew.add(new CrewMemberDto("Hans Zimmer", "Original Music Composer", ""));
            crew.add(new CrewMemberDto(id == 2L ? "Hoyte van Hoytema" : "Wally Pfister", "Cinematographer", ""));
            crew.add(new CrewMemberDto("Emma Thomas", "Lead Producer", ""));
        } else if (id == 4L) {
            crew.add(new CrewMemberDto("Ridley Scott", "Director & Producer", ""));
            crew.add(new CrewMemberDto("Harry Gregson-Williams", "Original Music", ""));
            crew.add(new CrewMemberDto("John Mathieson", "Director of Photography", ""));
            crew.add(new CrewMemberDto("David Scarpa", "Screenplay", ""));
        } else if (id == 5L) {
            crew.add(new CrewMemberDto("Denis Villeneuve", "Director & Screenplay", ""));
            crew.add(new CrewMemberDto("Hans Zimmer", "Music Score Composer", ""));
            crew.add(new CrewMemberDto("Greig Fraser", "Director of Photography", ""));
            crew.add(new CrewMemberDto("Joe Walker", "Film Editor", ""));
        } else if (id == 6L) {
            crew.add(new CrewMemberDto("Joaquim Dos Santos & Kemp Powers", "Directors", ""));
            crew.add(new CrewMemberDto("Phil Lord & Christopher Miller", "Writers & Producers", ""));
            crew.add(new CrewMemberDto("Daniel Pemberton", "Original Score", ""));
        } else if (id == 7L) {
            crew.add(new CrewMemberDto("Anthony & Joe Russo", "Directors", ""));
            crew.add(new CrewMemberDto("Kevin Feige", "Producer", ""));
            crew.add(new CrewMemberDto("Michael Waldron", "Screenplay", ""));
            crew.add(new CrewMemberDto("Alan Silvestri", "Music Composer", ""));
        } else {
            crew.add(new CrewMemberDto("Principal Director", "Director", ""));
            crew.add(new CrewMemberDto("Executive Producer", "Producer", ""));
        }
        return crew;
    }

    private int getComputedInterestedCount(Movie movie) {
        int base;
        long id = (movie.getId() != null) ? movie.getId() : 1L;
        if (id == 4L) base = 980;
        else if (id == 5L) base = 1420;
        else if (id == 6L) base = 1750;
        else if (id == 7L) base = 2850;
        else base = (int) (650 + (id * 147) % 800);

        int userLikes = (movie.getInterestedCount() != null) ? movie.getInterestedCount() : 0;
        return base + userLikes;
    }

    private int getComputedBookedLastHour(Movie movie) {
        long id = (movie.getId() != null) ? movie.getId() : 1L;
        if (id == 1L) return 38;
        else if (id == 2L) return 54;
        else if (id == 3L) return 42;
        else return (int) (25 + (id * 17) % 40);
    }

    private List<String> parseFormats(Movie movie) {
        String formatsStr = movie.getFormats();
        if (formatsStr == null || formatsStr.trim().isEmpty()) {
            return List.of("2D", "3D", "IMAX");
        }
        return java.util.Arrays.stream(formatsStr.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());
    }
}
