package com.cinema.booking.dto.show;

import com.cinema.booking.entity.SeatType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ShowSeatResponse {
    private Long id;
    private Integer rowNumber;
    private Integer colNumber;
    private SeatType type;
    private BigDecimal price;
    private boolean booked;
}   