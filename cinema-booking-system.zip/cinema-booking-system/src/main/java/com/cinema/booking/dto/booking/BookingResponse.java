package com.cinema.booking.dto.booking;

import com.cinema.booking.entity.BookingStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookingResponse {
    private Long id;
    private Long userId;
    private String userName;
    private String userEmail;

    private Long showId;
    private Long movieId;
    private String movieTitle;
    private String moviePosterUrl;
    private String theaterName;
    private String theaterCity;
    private String theaterAddress;
    private String screenName;

    private LocalDate showDate;
    private LocalTime showTime;

    private List<BookingSeatDto> seats;
    private String snacks;
    private BigDecimal totalAmount;
    private BookingStatus status;
    private LocalDateTime createdAt;
}
