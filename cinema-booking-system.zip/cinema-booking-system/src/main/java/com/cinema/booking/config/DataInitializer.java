package com.cinema.booking.config;

import com.cinema.booking.dto.theater.SeatGenerateRequest;
import com.cinema.booking.entity.*;
import com.cinema.booking.repository.*;
import com.cinema.booking.service.ScreenService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final MovieRepository movieRepository;
    private final TheaterRepository theaterRepository;
    private final ScreenRepository screenRepository;
    private final SeatRepository seatRepository;
    private final ShowRepository showRepository;
    private final ScreenService screenService;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // 1. Ensure Admin and Test users exist
        initUsers();

        // 2. Ensure seats exist for all screens (Self-healing in case seats table was freshly created)
        initSeatsIfMissing();

        // 3. Ensure upcoming movies exist
        initUpcomingMovies();
    }

    private void initUpcomingMovies() {
        seedMovieIfMissing("Gladiator II",
                "Years after witnessing the death of the revered hero Maximus at the hands of his uncle, Lucius must enter the Colosseum to restore the glory of Rome.",
                "Action", "English", 148,
                "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=800&auto=format&fit=crop&q=80",
                java.time.LocalDate.of(2026, 11, 22));

        seedMovieIfMissing("Dune: Part Three",
                "Paul Atreides continues his epic mythic journey as emperor of the known universe, facing complex geopolitical unrest and the ultimate destiny of Arrakis.",
                "Sci-Fi", "English", 165,
                "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&auto=format&fit=crop&q=80",
                java.time.LocalDate.of(2026, 12, 18));

        seedMovieIfMissing("Spider-Man: Beyond the Spider-Verse",
                "Miles Morales catapults across the Multiverse to prevent the canon event catastrophe, confronting friends and foes across every dimension.",
                "Animation", "English", 140,
                "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=800&auto=format&fit=crop&q=80",
                java.time.LocalDate.of(2027, 3, 15));

        seedMovieIfMissing("Avengers: Secret Wars",
                "The multiverse collides in the ultimate battle as heroes from across realities assemble to save existence itself from total collapse.",
                "Action", "English", 180,
                "https://images.unsplash.com/photo-1635805737707-575885ab0820?w=800&auto=format&fit=crop&q=80",
                java.time.LocalDate.of(2027, 5, 7));
    }

    private void seedMovieIfMissing(String title, String desc, String genre, String lang, int duration, String poster, java.time.LocalDate releaseDate) {
        boolean exists = movieRepository.findAll().stream().anyMatch(m -> m.getTitle().equalsIgnoreCase(title));
        if (!exists) {
            Movie movie = Movie.builder()
                    .title(title)
                    .description(desc)
                    .genre(genre)
                    .language(lang)
                    .durationMinutes(duration)
                    .posterUrl(poster)
                    .releaseDate(releaseDate)
                    .build();
            movieRepository.save(movie);
            log.info("Seeded upcoming movie: {}", title);
        }
    }

    private void initUsers() {
        userRepository.findByEmail("admin@cinema.com").ifPresentOrElse(
                admin -> {
                    admin.setPassword(passwordEncoder.encode("admin123"));
                    userRepository.save(admin);
                    log.info("Admin user verified: admin@cinema.com");
                },
                () -> {
                    User admin = User.builder()
                            .name("Cinema Admin")
                            .email("admin@cinema.com")
                            .password(passwordEncoder.encode("admin123"))
                            .role(Role.ADMIN)
                            .build();
                    userRepository.save(admin);
                    log.info("Default Admin user created: admin@cinema.com");
                }
        );

        userRepository.findByEmail("user@cinema.com").ifPresentOrElse(
                user -> {
                    user.setPassword(passwordEncoder.encode("user123"));
                    userRepository.save(user);
                    log.info("Test user verified: user@cinema.com");
                },
                () -> {
                    User user = User.builder()
                            .name("Jane Doe")
                            .email("user@cinema.com")
                            .password(passwordEncoder.encode("user123"))
                            .role(Role.USER)
                            .build();
                    userRepository.save(user);
                    log.info("Default user created: user@cinema.com");
                }
        );
    }

    private void initSeatsIfMissing() {
        try {
            long totalSeats = seatRepository.count();
            if (totalSeats == 0) {
                log.info("No seats detected in database. Initializing seats for screens...");
                List<Screen> screens = screenRepository.findAll();
                for (Screen screen : screens) {
                    SeatGenerateRequest req = SeatGenerateRequest.builder().build();
                    int created = screenService.generateSeats(screen.getId(), req);
                    log.info("Auto-generated {} seats for screen '{}'", created, screen.getName());
                }
            }
        } catch (Exception e) {
            log.warn("Could not auto-verify seats: {}", e.getMessage());
        }
    }
}
