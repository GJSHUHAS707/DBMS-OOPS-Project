package com.cinema.booking.service;

import com.cinema.booking.dto.theater.ScreenResponse;
import com.cinema.booking.dto.theater.TheaterRequest;
import com.cinema.booking.dto.theater.TheaterResponse;
import com.cinema.booking.entity.Theater;
import com.cinema.booking.exception.ResourceNotFoundException;
import com.cinema.booking.repository.TheaterRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TheaterService {

    private final TheaterRepository theaterRepository;

    @Transactional(readOnly = true)
    public List<TheaterResponse> getAllTheaters() {
        return theaterRepository.findAll()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public TheaterResponse getTheaterById(Long id) {
        Theater theater = theaterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Theater not found with id: " + id));
        return toResponse(theater);
    }

    @Transactional
    public TheaterResponse createTheater(TheaterRequest request) {
        Theater theater = Theater.builder()
                .name(request.getName().trim())
                .city(request.getCity().trim())
                .address(request.getAddress().trim())
                .build();
        return toResponse(theaterRepository.save(theater));
    }

    @Transactional
    public TheaterResponse updateTheater(Long id, TheaterRequest request) {
        Theater theater = theaterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Theater not found with id: " + id));

        theater.setName(request.getName().trim());
        theater.setCity(request.getCity().trim());
        theater.setAddress(request.getAddress().trim());

        return toResponse(theaterRepository.save(theater));
    }

    @Transactional
    public void deleteTheater(Long id) {
        if (!theaterRepository.existsById(id)) {
            throw new ResourceNotFoundException("Theater not found with id: " + id);
        }
        theaterRepository.deleteById(id);
    }

    public TheaterResponse toResponse(Theater theater) {
        List<ScreenResponse> screens = (theater.getScreens() != null)
                ? theater.getScreens().stream()
                    .map(screen -> ScreenResponse.builder()
                            .id(screen.getId())
                            .theaterId(theater.getId())
                            .theaterName(theater.getName())
                            .name(screen.getName())
                            .totalRows(screen.getTotalRows())
                            .totalCols(screen.getTotalCols())
                            .totalSeats(screen.getTotalRows() * screen.getTotalCols())
                            .build())
                    .collect(Collectors.toList())
                : List.of();

        return TheaterResponse.builder()
                .id(theater.getId())
                .name(theater.getName())
                .city(theater.getCity())
                .address(theater.getAddress())
                .screens(screens)
                .build();
    }
}
