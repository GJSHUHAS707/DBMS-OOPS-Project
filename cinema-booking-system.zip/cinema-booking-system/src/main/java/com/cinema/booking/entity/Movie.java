package com.cinema.booking.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "movies")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 255)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false, length = 100)
    private String genre;

    @Column(nullable = false, length = 50)
    private String language;

    @Column(name = "duration_minutes", nullable = false)
    private Integer durationMinutes;

    @Column(name = "poster_url", length = 500)
    private String posterUrl;

    @Column(name = "release_date", nullable = false)
    private LocalDate releaseDate;

    @Column(name = "interested_count")
    @Builder.Default
    private Integer interestedCount = 0;

    @Column(name = "formats", length = 100)
    @Builder.Default
    private String formats = "2D, 3D, IMAX";

    @Column(name = "director", length = 150)
    private String director;

    @Column(name = "cast_members", columnDefinition = "TEXT")
    private String castMembers;

    @Column(name = "crew_members", columnDefinition = "TEXT")
    private String crewMembers;
}
