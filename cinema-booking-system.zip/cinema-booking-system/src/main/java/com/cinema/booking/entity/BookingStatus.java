package com.cinema.booking.entity;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED
}
