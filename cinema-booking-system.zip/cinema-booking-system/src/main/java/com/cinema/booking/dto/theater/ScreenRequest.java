package com.cinema.booking.dto.theater;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScreenRequest {

    @NotNull(message = "Theater ID is required")
    private Long theaterId;

    @NotBlank(message = "Screen name is required")
    private String name;

    @NotNull(message = "Total rows is required")
    @Min(value = 1, message = "Total rows must be at least 1")
    private Integer totalRows;

    @NotNull(message = "Total columns is required")
    @Min(value = 1, message = "Total columns must be at least 1")
    private Integer totalCols;
}
