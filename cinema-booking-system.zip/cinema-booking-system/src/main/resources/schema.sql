-- ==============================================================
-- Cinema Ticket Booking System - MySQL 8 DDL Schema
-- ==============================================================

-- Drop child tables first if existing
DROP TABLE IF EXISTS `booking_seats`;
DROP TABLE IF EXISTS `bookings`;
DROP TABLE IF EXISTS `shows`;
DROP TABLE IF EXISTS `seats`;
DROP TABLE IF EXISTS `screens`;
DROP TABLE IF EXISTS `theaters`;
DROP TABLE IF EXISTS `movies`;
DROP TABLE IF EXISTS `users`;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS `users` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `role` VARCHAR(20) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Movies Table
CREATE TABLE IF NOT EXISTS `movies` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT,
    `genre` VARCHAR(100) NOT NULL,
    `language` VARCHAR(50) NOT NULL,
    `duration_minutes` INT NOT NULL,
    `poster_url` VARCHAR(500),
    `release_date` DATE NOT NULL,
    `interested_count` INT DEFAULT 0,
    `formats` VARCHAR(100) DEFAULT '2D, 3D, IMAX',
    `director` VARCHAR(150),
    `cast_members` TEXT,
    `crew_members` TEXT
);

-- 3. Theaters Table
CREATE TABLE IF NOT EXISTS `theaters` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(150) NOT NULL,
    `city` VARCHAR(100) NOT NULL,
    `address` VARCHAR(255) NOT NULL
);

-- 4. Screens Table
CREATE TABLE IF NOT EXISTS `screens` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `theater_id` BIGINT NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `total_rows` INT NOT NULL,
    `total_cols` INT NOT NULL,
    CONSTRAINT `fk_screen_theater` FOREIGN KEY (`theater_id`) REFERENCES `theaters`(`id`) ON DELETE CASCADE
);

-- 5. Seats Table (row_number is a reserved keyword in MySQL 8 and MUST be quoted with backticks)
CREATE TABLE IF NOT EXISTS `seats` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `screen_id` BIGINT NOT NULL,
    `row_number` INT NOT NULL,
    `col_number` INT NOT NULL,
    `type` VARCHAR(20) NOT NULL,
    `price` DECIMAL(10,2) NOT NULL,
    CONSTRAINT `fk_seat_screen` FOREIGN KEY (`screen_id`) REFERENCES `screens`(`id`) ON DELETE CASCADE,
    CONSTRAINT `uq_screen_seat` UNIQUE (`screen_id`, `row_number`, `col_number`)
);

-- 6. Shows Table
CREATE TABLE IF NOT EXISTS `shows` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `movie_id` BIGINT NOT NULL,
    `screen_id` BIGINT NOT NULL,
    `show_date` DATE NOT NULL,
    `show_time` TIME NOT NULL,
    `status` VARCHAR(20) NOT NULL DEFAULT 'UPCOMING',
    CONSTRAINT `fk_show_movie` FOREIGN KEY (`movie_id`) REFERENCES `movies`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_show_screen` FOREIGN KEY (`screen_id`) REFERENCES `screens`(`id`) ON DELETE CASCADE
);

-- 7. Bookings Table
CREATE TABLE IF NOT EXISTS `bookings` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT NOT NULL,
    `show_id` BIGINT NOT NULL,
    `total_amount` DECIMAL(10,2) NOT NULL,
    `snacks` TEXT,
    `status` VARCHAR(20) NOT NULL DEFAULT 'CONFIRMED',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_booking_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_booking_show` FOREIGN KEY (`show_id`) REFERENCES `shows`(`id`) ON DELETE CASCADE
);

-- 8. Booking Seats Junction Table
CREATE TABLE IF NOT EXISTS `booking_seats` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `booking_id` BIGINT NOT NULL,
    `seat_id` BIGINT NOT NULL,
    CONSTRAINT `fk_bs_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_bs_seat` FOREIGN KEY (`seat_id`) REFERENCES `seats`(`id`) ON DELETE CASCADE
);
