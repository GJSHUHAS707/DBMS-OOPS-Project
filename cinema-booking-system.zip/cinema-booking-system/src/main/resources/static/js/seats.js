// ==============================================================
// Cinema Ticket Booking System - Interactive Seat Map & Snacks Checkout
// ==============================================================

let currentShowId = null;
let currentShow = null;
let allSeats = [];
let selectedSeats = new Map(); // seatId -> seatObject
let selectedSnacks = new Map(); // snackId -> quantity

const SNACKS_CATALOG = [
  { id: 'popcorn-caramel', name: 'Caramel Popcorn (L)', desc: 'Warm sweet caramel glazed crunch', price: 7.50, icon: '🍿' },
  { id: 'popcorn-butter', name: 'Butter Popcorn (M)', desc: 'Classic golden salted theater butter', price: 5.50, icon: '🍿' },
  { id: 'burger', name: 'Crispy Gourmet Burger', desc: 'Brioche bun with fresh patty & cheddar', price: 8.00, icon: '🍔' },
  { id: 'sandwich', name: 'Grilled Club Sandwich', desc: 'Toasted triple-decker with crisp veggies', price: 6.50, icon: '🥪' },
  { id: 'coke', name: 'Coca-Cola Large (750ml)', desc: 'Ice-cold bubbly fountain refreshment', price: 4.00, icon: '🥤' },
  { id: 'nachos', name: 'Loaded Cheese Nachos', desc: 'Tortilla crisps with warm queso & jalapeño', price: 6.00, icon: '🧀' },
  { id: 'combo', name: 'Movie Night Duo Combo', desc: '1 Large Popcorn + 2 Large Coca-Colas', price: 13.50, icon: '✨' }
];

document.addEventListener('DOMContentLoaded', () => {
  initSeatSelectionPage();
});

async function initSeatSelectionPage() {
  const params = new URLSearchParams(window.location.search);
  currentShowId = params.get('showId');

  if (!currentShowId) {
    window.location.href = '/index.html';
    return;
  }

  renderSnacksCatalog();
  await loadShowDetails();
  await loadSeatMap();
  setupBookingButton();
}

async function loadShowDetails() {
  const params = new URLSearchParams(window.location.search);
  try {
    const res = await api.get(`/shows/${currentShowId}`);
    currentShow = res.data;

    const format = params.get('format') || currentShow.format || '2D';

    document.getElementById('show-movie-title').textContent = currentShow.movieTitle;
    document.getElementById('show-theater-info').textContent = 
      `${currentShow.theaterName} (${currentShow.theaterCity}) • ${currentShow.screenName}`;
    document.getElementById('show-timing-info').textContent = 
      `📅 ${currentShow.showDate} at ⏰ ${formatTime(currentShow.showTime)}`;

    const badge = document.getElementById('show-format-badge');
    if (badge) {
      badge.textContent = format;
      const fmtCls = format.toLowerCase() === 'imax' ? 'imax' : (format.includes('3D') ? 'three-d' : 'two-d');
      badge.className = `format-chip ${fmtCls}`;
      badge.style.display = 'inline-block';
    }
  } catch (err) {
    showToast('Failed to load show details: ' + err.message, 'error');
  }
}

async function loadSeatMap() {
  const gridContainer = document.getElementById('seat-grid');
  if (!gridContainer) return;

  gridContainer.innerHTML = '<p style="color: var(--text-muted); padding: 40px 0;">Loading seats...</p>';

  try {
    const res = await api.get(`/shows/${currentShowId}/seats`);
    allSeats = res.data;

    // Group seats by rowNumber
    const seatsByRow = new Map();
    allSeats.forEach(seat => {
      if (!seatsByRow.has(seat.rowNumber)) {
        seatsByRow.set(seat.rowNumber, []);
      }
      seatsByRow.get(seat.rowNumber).push(seat);
    });

    gridContainer.innerHTML = '';

    // Sort rows ascending
    const sortedRowNums = Array.from(seatsByRow.keys()).sort((a, b) => a - b);

    sortedRowNums.forEach(rowNum => {
      const rowSeats = seatsByRow.get(rowNum).sort((a, b) => a.colNumber - b.colNumber);
      const rowEl = document.createElement('div');
      rowEl.className = 'seat-row';

      // Row Alphabet Label: 1 -> A, 2 -> B, etc.
      const rowChar = String.fromCharCode(64 + rowNum);
      const labelLeft = document.createElement('span');
      labelLeft.className = 'row-label';
      labelLeft.textContent = rowChar;
      rowEl.appendChild(labelLeft);

      rowSeats.forEach(seat => {
        const seatNode = document.createElement('div');
        const typeClass = (seat.type || 'REGULAR').toLowerCase();
        const isBooked = (seat.booked === true || seat.isBooked === true);
        const bookedClass = isBooked ? 'booked' : '';
        const isSelected = selectedSeats.has(seat.id);
        const selectedClass = isSelected ? 'selected' : '';

        seatNode.className = `seat-node ${typeClass} ${bookedClass} ${selectedClass}`;
        seatNode.dataset.id = seat.id;
        seatNode.textContent = seat.colNumber;
        seatNode.title = isBooked 
          ? `Seat ${rowChar}${seat.colNumber} (Booked)` 
          : `Seat ${rowChar}${seat.colNumber} (${seat.type} - $${Number(seat.price).toFixed(2)})`;

        if (!isBooked) {
          seatNode.addEventListener('click', () => toggleSeatSelection(seat, seatNode, rowChar));
        }

        rowEl.appendChild(seatNode);
      });

      const labelRight = document.createElement('span');
      labelRight.className = 'row-label';
      labelRight.textContent = rowChar;
      rowEl.appendChild(labelRight);

      gridContainer.appendChild(rowEl);
    });

    updateSummary();
  } catch (err) {
    gridContainer.innerHTML = `<p style="color: #ef4444; padding: 40px 0;">Failed to load seat map: ${escapeHtml(err.message)}</p>`;
  }
}

function toggleSeatSelection(seat, seatNode, rowChar) {
  if (selectedSeats.has(seat.id)) {
    selectedSeats.delete(seat.id);
    seatNode.classList.remove('selected');
  } else {
    // Add to selection
    selectedSeats.set(seat.id, {
      ...seat,
      label: `${rowChar}${seat.colNumber}`
    });
    seatNode.classList.add('selected');
  }

  updateSummary();
}

// ==============================================================
// Snacks & Refreshments Concessions Logic
// ==============================================================
function renderSnacksCatalog() {
  const container = document.getElementById('snacks-grid');
  if (!container) return;

  container.innerHTML = SNACKS_CATALOG.map(snack => {
    const qty = selectedSnacks.get(snack.id) || 0;
    const isSelected = qty > 0;

    return `
      <div class="snack-card ${isSelected ? 'selected' : ''}" id="snack-card-${snack.id}">
        <div class="snack-icon">${snack.icon}</div>
        <div class="snack-title">${escapeHtml(snack.name)}</div>
        <div class="snack-desc">${escapeHtml(snack.desc)}</div>
        <div class="snack-bottom">
          <div class="snack-price">$${snack.price.toFixed(2)}</div>
          <div class="snack-stepper">
            <button class="snack-btn-step" onclick="changeSnackQty('${snack.id}', -1)" title="Remove one">−</button>
            <span class="snack-qty" id="snack-qty-${snack.id}">${qty}</span>
            <button class="snack-btn-step" onclick="changeSnackQty('${snack.id}', 1)" title="Add one">+</button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function changeSnackQty(snackId, delta) {
  const current = selectedSnacks.get(snackId) || 0;
  const newQty = Math.max(0, current + delta);

  if (newQty === 0) {
    selectedSnacks.delete(snackId);
  } else {
    selectedSnacks.set(snackId, newQty);
  }

  // Update UI
  const qtyEl = document.getElementById(`snack-qty-${snackId}`);
  const cardEl = document.getElementById(`snack-card-${snackId}`);
  if (qtyEl) qtyEl.textContent = newQty;
  if (cardEl) {
    if (newQty > 0) {
      cardEl.classList.add('selected');
    } else {
      cardEl.classList.remove('selected');
    }
  }

  updateSummary();
}

function updateSummary() {
  const listEl = document.getElementById('selected-seats-list');
  const countEl = document.getElementById('summary-seat-count');
  const subtotalEl = document.getElementById('summary-subtotal');
  const totalEl = document.getElementById('summary-total');
  const checkoutBtn = document.getElementById('btn-checkout');

  const snacksContainer = document.getElementById('summary-snacks-container');
  const snacksListEl = document.getElementById('selected-snacks-list');
  const snacksSubtotalEl = document.getElementById('summary-snacks-subtotal');

  if (!listEl) return;

  const seatCount = selectedSeats.size;
  countEl.textContent = seatCount;

  // Calculate Seats Subtotal
  let seatsTotal = 0;
  let seatPillsHtml = '';

  selectedSeats.forEach((seat) => {
    seatsTotal += Number(seat.price);
    seatPillsHtml += `
      <span class="selected-pill">
        ${escapeHtml(seat.label)} ($${Number(seat.price).toFixed(2)})
      </span>
    `;
  });

  if (seatCount === 0) {
    listEl.innerHTML = '<span style="color: var(--text-dim); font-size: 0.85rem;">No seats selected yet. Click on the seats above.</span>';
    subtotalEl.textContent = '$0.00';
  } else {
    listEl.innerHTML = seatPillsHtml;
    subtotalEl.textContent = `$${seatsTotal.toFixed(2)}`;
  }

  // Calculate Snacks Subtotal
  let snacksTotal = 0;
  let snacksCount = 0;
  let snacksListHtml = '';

  selectedSnacks.forEach((qty, snackId) => {
    const item = SNACKS_CATALOG.find(s => s.id === snackId);
    if (item && qty > 0) {
      const lineCost = item.price * qty;
      snacksTotal += lineCost;
      snacksCount += qty;
      snacksListHtml += `
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
          <span>${item.icon} ${qty}x ${escapeHtml(item.name)}</span>
          <span style="color: #f5c518; font-weight: 600;">$${lineCost.toFixed(2)}</span>
        </div>
      `;
    }
  });

  if (snacksCount > 0 && snacksContainer && snacksListEl && snacksSubtotalEl) {
    snacksContainer.style.display = 'block';
    snacksListEl.innerHTML = snacksListHtml;
    snacksSubtotalEl.textContent = `+$${snacksTotal.toFixed(2)}`;
  } else if (snacksContainer) {
    snacksContainer.style.display = 'none';
  }

  // Grand Total
  const grandTotal = seatsTotal + snacksTotal;
  totalEl.textContent = `$${grandTotal.toFixed(2)}`;

  if (checkoutBtn) {
    if (seatCount > 0) {
      checkoutBtn.disabled = false;
      checkoutBtn.textContent = `Confirm & Pay ($${grandTotal.toFixed(2)})`;
    } else {
      checkoutBtn.disabled = true;
      checkoutBtn.textContent = 'Confirm & Pay ($0.00)';
    }
  }
}

function buildSnacksSummary() {
  const parts = [];
  selectedSnacks.forEach((qty, snackId) => {
    const item = SNACKS_CATALOG.find(s => s.id === snackId);
    if (item && qty > 0) {
      parts.push(`${qty}x ${item.name}`);
    }
  });
  return parts.join(', ');
}

function calculateSnacksTotal() {
  let total = 0;
  selectedSnacks.forEach((qty, snackId) => {
    const item = SNACKS_CATALOG.find(s => s.id === snackId);
    if (item) total += item.price * qty;
  });
  return total;
}

function setupBookingButton() {
  const checkoutBtn = document.getElementById('btn-checkout');
  if (!checkoutBtn) return;

  checkoutBtn.addEventListener('click', async () => {
    if (selectedSeats.size === 0) {
      showToast('Please select at least one seat to proceed', 'error');
      return;
    }

    // Check if user is authenticated
    if (!api.isAuthenticated()) {
      showToast('Please sign in or create an account to complete your booking', 'info');
      setTimeout(() => {
        const currentUrl = window.location.pathname + window.location.search;
        window.location.href = `/login.html?redirect=${encodeURIComponent(currentUrl)}`;
      }, 1000);
      return;
    }

    try {
      checkoutBtn.disabled = true;
      checkoutBtn.textContent = 'Securing seats & payment...';

      const seatIds = Array.from(selectedSeats.keys());
      const snacksSummary = buildSnacksSummary();
      const snacksAmount = calculateSnacksTotal();

      const res = await api.post('/bookings', {
        showId: currentShowId,
        seatIds: seatIds,
        snacks: snacksSummary ? snacksSummary : null,
        snacksAmount: snacksAmount > 0 ? snacksAmount : null
      });

      showToast('🎉 Booking Confirmed with Tickets & Concessions!', 'success');
      setTimeout(() => {
        window.location.href = `/booking-confirmation.html?bookingId=${res.data.id}`;
      }, 700);
    } catch (err) {
      showToast(err.message, 'error');
      checkoutBtn.disabled = false;
      updateSummary();
      // Refresh seat map in case seats were taken concurrently
      await loadSeatMap();
    }
  });
}

function formatTime(timeStr) {
  if (!timeStr) return '';
  const parts = timeStr.split(':');
  let hour = parseInt(parts[0], 10);
  const min = parts[1];
  const ampm = hour >= 12 ? 'PM' : 'AM';
  hour = hour % 12;
  hour = hour ? hour : 12;
  return `${hour}:${min} ${ampm}`;
}

function escapeHtml(str) {
  if (typeof str !== 'string') return str || '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
