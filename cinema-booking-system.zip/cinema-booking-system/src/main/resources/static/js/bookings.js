// ==============================================================
// Cinema Ticket Booking System - Booking Confirmation & History
// ==============================================================

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('ticket-container')) {
    initBookingConfirmationPage();
  }
  if (document.getElementById('my-bookings-list')) {
    initMyBookingsPage();
  }
});

// ==============================================================
// Booking Confirmation Ticket Renderer
// ==============================================================
async function initBookingConfirmationPage() {
  const params = new URLSearchParams(window.location.search);
  const bookingId = params.get('bookingId');
  const container = document.getElementById('ticket-container');

  if (!bookingId) {
    window.location.href = '/my-bookings.html';
    return;
  }

  try {
    const res = await api.get(`/bookings/${bookingId}`);
    const booking = res.data;

    const seatLabels = booking.seats.map(s => `Row ${String.fromCharCode(64 + s.rowNumber)}-Seat ${s.colNumber} (${s.type})`).join(', ');
    const isConfirmed = booking.status === 'CONFIRMED';

    container.innerHTML = `
      <div class="cinema-ticket">
        <div class="ticket-header">
          <div>
            <h2 style="font-size: 1.5rem; margin-bottom: 4px;">🎬 Cinema Admission Pass</h2>
            <p style="font-size: 0.85rem; opacity: 0.9;">Booking Ref: #${booking.id}</p>
          </div>
          <span class="ticket-status-badge ${isConfirmed ? 'confirmed' : 'cancelled'}" style="background: ${isConfirmed ? '#10b981' : '#ef4444'}; color: #fff;">
            ${escapeHtml(booking.status)}
          </span>
        </div>

        <div class="ticket-body">
          <div class="ticket-grid">
            <div>
              <div class="ticket-field-label">Movie</div>
              <div class="ticket-field-val">${escapeHtml(booking.movieTitle)}</div>
            </div>
            <div>
              <div class="ticket-field-label">Cinema & City</div>
              <div class="ticket-field-val">${escapeHtml(booking.theaterName)} (${escapeHtml(booking.theaterCity)})</div>
            </div>
            <div>
              <div class="ticket-field-label">Auditorium / Screen</div>
              <div class="ticket-field-val">${escapeHtml(booking.screenName)}</div>
            </div>
            <div>
              <div class="ticket-field-label">Date & Showtime</div>
              <div class="ticket-field-val">📅 ${booking.showDate} at ⏰ ${formatTime(booking.showTime)}</div>
            </div>
            <div style="grid-column: 1 / -1;">
              <div class="ticket-field-label">Seats Reserved (${booking.seats.length})</div>
              <div class="ticket-field-val" style="color: var(--accent-gold); font-size: 1.1rem;">
                ${escapeHtml(seatLabels)}
              </div>
            </div>
            <div>
              <div class="ticket-field-label">Guest Name</div>
              <div class="ticket-field-val">${escapeHtml(booking.userName)}</div>
            </div>
            <div>
              <div class="ticket-field-label">Total Amount Paid</div>
              <div class="ticket-field-val" style="color: var(--accent-green);">$${Number(booking.totalAmount).toFixed(2)}</div>
            </div>
            ${booking.snacks ? `
              <div style="grid-column: 1 / -1; background: rgba(245, 197, 24, 0.08); border: 1px solid rgba(245, 197, 24, 0.25); border-radius: var(--radius-sm); padding: 10px 14px; margin-top: 6px;">
                <div class="ticket-field-label" style="color: #f5c518; margin-bottom: 2px;">🍿 Concessions & Refreshments Voucher</div>
                <div class="ticket-field-val" style="color: #fef08a; font-size: 0.95rem;">${escapeHtml(booking.snacks)}</div>
                <div style="font-size: 0.72rem; color: var(--text-dim); margin-top: 3px;">Present this pass at the concessions express lane for quick pickup</div>
              </div>
            ` : ''}
          </div>

          <div class="ticket-qr-zone">
            <div class="qr-code-box">
              <svg viewBox="0 0 100 100">
                <rect x="0" y="0" width="100" height="100" fill="#ffffff" />
                <rect x="10" y="10" width="25" height="25" fill="#000000" />
                <rect x="15" y="15" width="15" height="15" fill="#ffffff" />
                <rect x="65" y="10" width="25" height="25" fill="#000000" />
                <rect x="70" y="15" width="15" height="15" fill="#ffffff" />
                <rect x="10" y="65" width="25" height="25" fill="#000000" />
                <rect x="15" y="70" width="15" height="15" fill="#ffffff" />
                <rect x="45" y="20" width="10" height="20" fill="#000000" />
                <rect x="40" y="45" width="20" height="10" fill="#000000" />
                <rect x="45" y="65" width="15" height="20" fill="#000000" />
                <rect x="65" y="45" width="20" height="35" fill="#000000" />
              </svg>
            </div>
            <span style="font-size: 0.72rem; color: var(--text-dim); margin-top: 8px;">Scan at gate</span>
          </div>
        </div>

        <div class="ticket-footer">
          <div style="display: flex; gap: 10px;">
            <button onclick="window.print()" class="btn btn-secondary btn-sm">🖨 Print Ticket</button>
            ${isConfirmed ? `
              <button onclick="confirmCancelBooking(${booking.id}, true)" class="btn btn-danger btn-sm">
                Cancel Ticket
              </button>
            ` : ''}
          </div>
          <a href="/my-bookings.html" class="btn btn-primary btn-sm">View All Bookings</a>
        </div>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `
      <div style="text-align: center; padding: 40px; color: #ef4444;">
        <p>Failed to load booking: ${escapeHtml(err.message)}</p>
        <a href="/my-bookings.html" class="btn btn-secondary" style="margin-top: 16px;">Go to My Bookings</a>
      </div>
    `;
  }
}

// ==============================================================
// My Bookings List Page
// ==============================================================
async function initMyBookingsPage() {
  if (!api.isAuthenticated()) {
    window.location.href = '/login.html?redirect=/my-bookings.html';
    return;
  }

  await loadUserBookings();
}

async function loadUserBookings() {
  const listEl = document.getElementById('my-bookings-list');
  if (!listEl) return;

  listEl.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 40px 0;">Loading your bookings...</p>';

  try {
    const res = await api.get('/bookings/my');
    const bookings = res.data;

    if (!bookings || bookings.length === 0) {
      listEl.innerHTML = `
        <div style="text-align: center; padding: 60px 0; background: var(--bg-card); border-radius: var(--radius-md);">
          <p style="font-size: 1.1rem; color: var(--text-muted); margin-bottom: 16px;">You haven't made any bookings yet.</p>
          <a href="/index.html" class="btn btn-primary">Explore Movies</a>
        </div>
      `;
      return;
    }

    listEl.innerHTML = bookings.map(b => {
      const isConfirmed = b.status === 'CONFIRMED';
      const statusBadge = isConfirmed
        ? `<span class="badge badge-success">CONFIRMED</span>`
        : `<span class="badge badge-danger">CANCELLED</span>`;

      const seatNames = b.seats.map(s => `Row ${String.fromCharCode(64 + s.rowNumber)}-${s.colNumber} (${s.type})`).join(', ');

      return `
        <div class="theater-group" style="margin-bottom: 20px;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 14px; border-bottom: 1px solid var(--border-color); padding-bottom: 14px; margin-bottom: 14px;">
            <div>
              <h3 style="font-size: 1.25rem;">🎬 ${escapeHtml(b.movieTitle)}</h3>
              <p style="color: var(--text-muted); font-size: 0.88rem; margin-top: 2px;">
                ${escapeHtml(b.theaterName)} • ${escapeHtml(b.screenName)} (${escapeHtml(b.theaterCity)})
              </p>
            </div>
            <div style="text-align: right;">
              <div>${statusBadge}</div>
              <div style="font-size: 0.8rem; color: var(--text-dim); margin-top: 4px;">Ref: #${b.id}</div>
            </div>
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; margin-bottom: 16px; font-size: 0.9rem;">
            <div>
              <span style="color: var(--text-dim);">Schedule:</span><br>
              <strong>📅 ${b.showDate} at ⏰ ${formatTime(b.showTime)}</strong>
            </div>
            <div>
              <span style="color: var(--text-dim);">Seats (${b.seats.length}):</span><br>
              <strong style="color: var(--accent-gold);">${escapeHtml(seatNames)}</strong>
            </div>
            <div>
              <span style="color: var(--text-dim);">Total Amount:</span><br>
              <strong style="color: var(--accent-green); font-size: 1.1rem;">$${Number(b.totalAmount).toFixed(2)}</strong>
            </div>
            <div>
              <span style="color: var(--text-dim);">Booked On:</span><br>
              <span>${new Date(b.createdAt).toLocaleString()}</span>
            </div>
            ${b.snacks ? `
              <div style="grid-column: 1 / -1; background: rgba(245, 197, 24, 0.08); border: 1px solid rgba(245, 197, 24, 0.2); border-radius: var(--radius-sm); padding: 8px 12px; margin-top: 4px;">
                <span style="color: #f5c518; font-weight: 600; font-size: 0.82rem;">🍿 Snacks Included:</span>
                <span style="color: #fef08a; font-size: 0.88rem; margin-left: 6px;">${escapeHtml(b.snacks)}</span>
              </div>
            ` : ''}
          </div>

          <div style="display: flex; justify-content: flex-end; gap: 12px; border-top: 1px solid var(--border-color); padding-top: 12px;">
            <a href="/booking-confirmation.html?bookingId=${b.id}" class="btn btn-secondary btn-sm">View Ticket</a>
            ${isConfirmed ? `
              <button onclick="confirmCancelBooking(${b.id})" class="btn btn-danger btn-sm">
                Cancel Booking
              </button>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    listEl.innerHTML = `<p style="color: #ef4444; padding: 40px 0; text-align: center;">Failed to load bookings: ${escapeHtml(err.message)}</p>`;
  }
}

async function confirmCancelBooking(bookingId, reloadTicket = false) {
  if (!confirm(`Are you sure you want to cancel Booking #${bookingId}? The seats will be released immediately.`)) {
    return;
  }

  try {
    const res = await api.put(`/bookings/${bookingId}/cancel`);
    showToast(res.message || 'Booking cancelled successfully. Seats released.', 'success');
    if (reloadTicket) {
      setTimeout(() => window.location.reload(), 600);
    } else {
      await loadUserBookings();
    }
  } catch (err) {
    console.error('Cancel booking error:', err);
    showToast('Failed to cancel booking: ' + err.message, 'error');
  }
}

// Expose on window object
window.confirmCancelBooking = confirmCancelBooking;

function formatTime(timeStr) {
  if (!timeStr) return '';
  const parts = timeStr.split(':');
  let hour = parseInt(parts[0], 10);
  const min = parts[1];
  const ampm = hour >= 12 ? 'PM' : 'AM';
  hour = hour % 12;
  hour = hour ? hour : 12;
  return `${hour}:${min} ${ampm}`;
}
