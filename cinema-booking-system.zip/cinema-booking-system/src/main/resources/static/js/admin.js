// ==============================================================
// Cinema Ticket Booking System - Admin Management Dashboard
// ==============================================================

let adminMovies = [];
let adminTheaters = [];
let adminScreens = [];
let adminShows = [];
let adminBookings = [];

document.addEventListener('DOMContentLoaded', () => {
  initAdminDashboard();
});

async function initAdminDashboard() {
  if (!api.isAuthenticated() || !api.isAdmin()) {
    showToast('Admin access required. Please sign in as an administrator.', 'error');
    window.location.href = '/login.html?redirect=/admin.html';
    return;
  }

  setupAdminTabs();
  await loadStats();
  await loadMoviesTab();
  await loadTheatersTab();
  await loadShowsTab();
  await loadBookingsTab();
}

function setupAdminTabs() {
  const tabs = document.querySelectorAll('.admin-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const target = tab.dataset.target;
      document.querySelectorAll('.admin-tab-content').forEach(c => c.style.display = 'none');
      const contentEl = document.getElementById(target);
      if (contentEl) contentEl.style.display = 'block';
    });
  });
}

// ==============================================================
// 1. Dashboard Stats
// ==============================================================
async function loadStats() {
  try {
    const res = await api.get('/admin/stats');
    const s = res.data;

    document.getElementById('stat-revenue').textContent = `$${Number(s.totalRevenue || 0).toFixed(2)}`;
    document.getElementById('stat-bookings').textContent = s.totalBookings;
    document.getElementById('stat-movies').textContent = s.totalMovies;
    document.getElementById('stat-shows').textContent = s.totalShows;
  } catch (err) {
    console.error('Failed to load stats:', err);
  }
}

// ==============================================================
// 2. Movies Management
// ==============================================================
async function loadMoviesTab() {
  const tableBody = document.getElementById('admin-movies-tbody');
  if (!tableBody) return;

  try {
    const res = await api.get('/admin/movies');
    adminMovies = res.data;

    tableBody.innerHTML = adminMovies.map(m => `
      <tr>
        <td><strong>#${m.id}</strong></td>
        <td>
          <div style="display: flex; align-items: center; gap: 10px;">
            <img src="${escapeHtml(m.posterUrl || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800')}" 
                 style="width: 36px; height: 50px; object-fit: cover; border-radius: 4px;"
                 onerror="this.src='https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800'">
            <div>
              <div style="font-weight: 700;">${escapeHtml(m.title)}</div>
              <div style="font-size: 0.8rem; color: var(--text-dim);">${escapeHtml(m.releaseDate)}</div>
            </div>
          </div>
        </td>
        <td>${escapeHtml(m.genre)}</td>
        <td>${escapeHtml(m.language)}</td>
        <td>${m.durationMinutes} min</td>
        <td>
          <button onclick="openEditMovieModal(${m.id})" class="btn btn-secondary btn-sm">Edit</button>
          <button onclick="deleteMovie(${m.id})" class="btn btn-danger btn-sm">Delete</button>
        </td>
      </tr>
    `).join('');

    populateMovieDropdowns();
  } catch (err) {
    showToast('Failed to load movies: ' + err.message, 'error');
  }
}

function openAddMovieModal() {
  document.getElementById('movie-modal-title').textContent = 'Add New Movie';
  document.getElementById('movie-form-id').value = '';
  document.getElementById('movie-form-title').value = '';
  document.getElementById('movie-form-desc').value = '';
  document.getElementById('movie-form-genre').value = '';
  document.getElementById('movie-form-lang').value = 'English';
  document.getElementById('movie-form-duration').value = '120';
  document.getElementById('movie-form-poster').value = '';
  document.getElementById('movie-form-date').value = new Date().toISOString().split('T')[0];

  openModal('movie-modal');
}

function openEditMovieModal(id) {
  const movie = adminMovies.find(m => m.id === id);
  if (!movie) return;

  document.getElementById('movie-modal-title').textContent = 'Edit Movie';
  document.getElementById('movie-form-id').value = movie.id;
  document.getElementById('movie-form-title').value = movie.title;
  document.getElementById('movie-form-desc').value = movie.description || '';
  document.getElementById('movie-form-genre').value = movie.genre;
  document.getElementById('movie-form-lang').value = movie.language;
  document.getElementById('movie-form-duration').value = movie.durationMinutes;
  document.getElementById('movie-form-poster').value = movie.posterUrl || '';
  document.getElementById('movie-form-date').value = movie.releaseDate;

  openModal('movie-modal');
}

async function handleSaveMovie(event) {
  event.preventDefault();
  const id = document.getElementById('movie-form-id').value;
  const payload = {
    title: document.getElementById('movie-form-title').value.trim(),
    description: document.getElementById('movie-form-desc').value.trim(),
    genre: document.getElementById('movie-form-genre').value.trim(),
    language: document.getElementById('movie-form-lang').value.trim(),
    durationMinutes: parseInt(document.getElementById('movie-form-duration').value, 10),
    posterUrl: document.getElementById('movie-form-poster').value.trim(),
    releaseDate: document.getElementById('movie-form-date').value
  };

  try {
    if (id) {
      await api.put(`/admin/movies/${id}`, payload);
      showToast('Movie updated successfully', 'success');
    } else {
      await api.post('/admin/movies', payload);
      showToast('Movie added successfully', 'success');
    }
    closeModal('movie-modal');
    await loadMoviesTab();
    await loadStats();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function deleteMovie(id) {
  if (!confirm('Are you sure you want to delete this movie? All associated shows will also be deleted.')) return;
  try {
    await api.delete(`/admin/movies/${id}`);
    showToast('Movie deleted', 'success');
    await loadMoviesTab();
    await loadStats();
  } catch (err) {
    showToast('Failed to delete movie: ' + err.message, 'error');
  }
}

// ==============================================================
// 3. Theaters & Screens Management
// ==============================================================
async function loadTheatersTab() {
  const container = document.getElementById('theaters-list-container');
  if (!container) return;

  try {
    const res = await api.get('/admin/theaters');
    adminTheaters = res.data;

    if (adminTheaters.length === 0) {
      container.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 20px;">No theaters created yet.</p>';
      return;
    }

    container.innerHTML = adminTheaters.map(t => `
      <div class="theater-group" style="margin-bottom: 24px;">
        <div class="theater-header">
          <div>
            <div class="theater-name">🏢 ${escapeHtml(t.name)}</div>
            <div class="theater-location">📍 ${escapeHtml(t.city)} • ${escapeHtml(t.address)}</div>
          </div>
          <div style="display: flex; gap: 8px;">
            <button onclick="openAddScreenModal(${t.id}, '${escapeHtml(t.name)}')" class="btn btn-primary btn-sm">+ Add Screen</button>
            <button onclick="deleteTheater(${t.id})" class="btn btn-danger btn-sm">Delete Theater</button>
          </div>
        </div>

        <div>
          <h4 style="font-size: 0.95rem; color: var(--text-dim); text-transform: uppercase; margin-bottom: 12px;">Auditoriums / Screens</h4>
          <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 14px;">
            ${t.screens && t.screens.length > 0 ? t.screens.map(s => `
              <div style="background: rgba(11, 14, 20, 0.6); border: 1px solid var(--border-color); border-radius: var(--radius-sm); padding: 14px;">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
                  <strong style="font-size: 1rem;">🎬 ${escapeHtml(s.name)}</strong>
                  <span class="badge" style="background: rgba(245, 197, 24, 0.15); color: var(--accent-gold);">
                    ${s.totalRows}x${s.totalCols} (${s.totalSeats} seats)
                  </span>
                </div>
                <div style="display: flex; gap: 8px; margin-top: 10px;">
                  <button onclick="openSeatGenModal(${s.id}, '${escapeHtml(s.name)}', ${s.totalRows}, ${s.totalCols})" class="btn btn-secondary btn-sm" style="flex: 1;">
                    ⚡ Auto-Fill Seats
                  </button>
                  <button onclick="deleteScreen(${s.id})" class="btn btn-danger btn-sm">✕</button>
                </div>
              </div>
            `).join('') : '<p style="color: var(--text-dim); font-size: 0.85rem;">No screens added yet. Click "+ Add Screen".</p>'}
          </div>
        </div>
      </div>
    `).join('');

    populateScreenDropdowns();
  } catch (err) {
    showToast('Failed to load theaters: ' + err.message, 'error');
  }
}

function openAddTheaterModal() {
  document.getElementById('theater-form-name').value = '';
  document.getElementById('theater-form-city').value = '';
  document.getElementById('theater-form-address').value = '';
  openModal('theater-modal');
}

async function handleSaveTheater(event) {
  event.preventDefault();
  const payload = {
    name: document.getElementById('theater-form-name').value.trim(),
    city: document.getElementById('theater-form-city').value.trim(),
    address: document.getElementById('theater-form-address').value.trim()
  };

  try {
    await api.post('/admin/theaters', payload);
    showToast('Theater created successfully', 'success');
    closeModal('theater-modal');
    await loadTheatersTab();
    await loadStats();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function deleteTheater(id) {
  if (!confirm('Are you sure you want to delete this theater and all its screens/shows?')) return;
  try {
    await api.delete(`/admin/theaters/${id}`);
    showToast('Theater deleted', 'success');
    await loadTheatersTab();
    await loadStats();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function openAddScreenModal(theaterId, theaterName) {
  document.getElementById('screen-form-theater-id').value = theaterId;
  document.getElementById('screen-form-theater-name').textContent = theaterName;
  document.getElementById('screen-form-name').value = 'Screen ' + ((adminTheaters.find(t=>t.id===theaterId)?.screens?.length || 0) + 1);
  document.getElementById('screen-form-rows').value = '5';
  document.getElementById('screen-form-cols').value = '8';
  openModal('screen-modal');
}

async function handleSaveScreen(event) {
  event.preventDefault();
  const payload = {
    theaterId: parseInt(document.getElementById('screen-form-theater-id').value, 10),
    name: document.getElementById('screen-form-name').value.trim(),
    totalRows: parseInt(document.getElementById('screen-form-rows').value, 10),
    totalCols: parseInt(document.getElementById('screen-form-cols').value, 10)
  };

  try {
    await api.post('/admin/screens', payload);
    showToast('Screen created with auto-filled seat grid!', 'success');
    closeModal('screen-modal');
    await loadTheatersTab();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function deleteScreen(id) {
  if (!confirm('Are you sure you want to delete this screen?')) return;
  try {
    await api.delete(`/admin/screens/${id}`);
    showToast('Screen deleted', 'success');
    await loadTheatersTab();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function openSeatGenModal(screenId, screenName, rows, cols) {
  document.getElementById('gen-screen-id').value = screenId;
  document.getElementById('gen-screen-name').textContent = `${screenName} (${rows} Rows x ${cols} Cols = ${rows*cols} Seats)`;
  openModal('seat-gen-modal');
}

async function handleGenerateSeats(event) {
  event.preventDefault();
  const screenId = document.getElementById('gen-screen-id').value;
  const payload = {
    regularPrice: parseFloat(document.getElementById('gen-price-regular').value),
    premiumPrice: parseFloat(document.getElementById('gen-price-premium').value),
    vipPrice: parseFloat(document.getElementById('gen-price-vip').value)
  };

  try {
    const res = await api.post(`/admin/screens/${screenId}/generate-seats`, payload);
    showToast(res.message, 'success');
    closeModal('seat-gen-modal');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// ==============================================================
// 4. Shows Scheduling Management
// ==============================================================
async function loadShowsTab() {
  const tableBody = document.getElementById('admin-shows-tbody');
  if (!tableBody) return;

  try {
    const res = await api.get('/admin/shows');
    adminShows = res.data;

    tableBody.innerHTML = adminShows.map(s => `
      <tr>
        <td><strong>#${s.id}</strong></td>
        <td><strong>${escapeHtml(s.movieTitle)}</strong></td>
        <td>${escapeHtml(s.theaterName)} (${escapeHtml(s.screenName)})</td>
        <td>📅 ${s.showDate}</td>
        <td>⏰ ${formatTime(s.showTime)}</td>
        <td>
          <span class="badge ${s.status === 'UPCOMING' ? 'badge-success' : 'badge-danger'}">
            ${escapeHtml(s.status)}
          </span>
        </td>
        <td>
          <span style="color: var(--accent-gold); font-weight: 700;">$${Number(s.startingPrice).toFixed(2)}</span>
          <div style="font-size: 0.75rem; color: var(--text-dim);">${s.availableSeatsCount} / ${s.totalSeatsCount} available</div>
        </td>
        <td>
          <button onclick="deleteShow(${s.id})" class="btn btn-danger btn-sm">Delete</button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    showToast('Failed to load shows: ' + err.message, 'error');
  }
}

function openAddShowModal() {
  document.getElementById('show-form-date').value = new Date().toISOString().split('T')[0];
  document.getElementById('show-form-time').value = '18:00';
  openModal('show-modal');
}

async function handleSaveShow(event) {
  event.preventDefault();
  const payload = {
    movieId: parseInt(document.getElementById('show-form-movie').value, 10),
    screenId: parseInt(document.getElementById('show-form-screen').value, 10),
    showDate: document.getElementById('show-form-date').value,
    showTime: document.getElementById('show-form-time').value + ':00',
    status: document.getElementById('show-form-status').value
  };

  try {
    await api.post('/admin/shows', payload);
    showToast('Show scheduled successfully', 'success');
    closeModal('show-modal');
    await loadShowsTab();
    await loadStats();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function deleteShow(id) {
  if (!confirm('Are you sure you want to delete this show?')) return;
  try {
    await api.delete(`/admin/shows/${id}`);
    showToast('Show deleted', 'success');
    await loadShowsTab();
    await loadStats();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// ==============================================================
// 5. Bookings & Revenue Management
// ==============================================================
async function loadBookingsTab() {
  const tableBody = document.getElementById('admin-bookings-tbody');
  if (!tableBody) return;

  try {
    const res = await api.get('/admin/bookings');
    adminBookings = res.data;

    tableBody.innerHTML = adminBookings.map(b => {
      const isConfirmed = b.status === 'CONFIRMED';
      const statusBadge = isConfirmed
        ? `<span class="badge badge-success">CONFIRMED</span>`
        : `<span class="badge badge-danger">CANCELLED</span>`;

      const seatList = b.seats.map(s => `${String.fromCharCode(64 + s.rowNumber)}${s.colNumber}`).join(', ');

      return `
        <tr>
          <td><strong>#${b.id}</strong></td>
          <td>
            <div><strong>${escapeHtml(b.userName)}</strong></div>
            <div style="font-size: 0.78rem; color: var(--text-dim);">${escapeHtml(b.userEmail)}</div>
          </td>
          <td>
            <div>${escapeHtml(b.movieTitle)}</div>
            <div style="font-size: 0.78rem; color: var(--text-dim);">${escapeHtml(b.theaterName)} (${escapeHtml(b.screenName)})</div>
          </td>
          <td>📅 ${b.showDate} ${formatTime(b.showTime)}</td>
          <td><span style="color: var(--accent-gold);">${escapeHtml(seatList)}</span> (${b.seats.length})</td>
          <td><strong style="color: var(--accent-green);">$${Number(b.totalAmount).toFixed(2)}</strong></td>
          <td>${statusBadge}</td>
          <td>
            ${isConfirmed ? `
              <button onclick="adminCancelBooking(${b.id})" class="btn btn-danger btn-sm">Cancel</button>
            ` : '-'}
          </td>
        </tr>
      `;
    }).join('');
  } catch (err) {
    showToast('Failed to load bookings: ' + err.message, 'error');
  }
}

async function adminCancelBooking(id) {
  if (!confirm(`Cancel Booking #${id}? Seats will be released immediately for other customers.`)) return;
  try {
    await api.put(`/admin/bookings/${id}/cancel`);
    showToast('Booking cancelled by admin. Seats released.', 'success');
    await loadBookingsTab();
    await loadStats();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

window.adminCancelBooking = adminCancelBooking;

// ==============================================================
// Dropdown Populators & Modal Helpers
// ==============================================================
function populateMovieDropdowns() {
  const select = document.getElementById('show-form-movie');
  if (!select) return;
  select.innerHTML = adminMovies.map(m => `
    <option value="${m.id}">${escapeHtml(m.title)} (${m.durationMinutes}m)</option>
  `).join('');
}

function populateScreenDropdowns() {
  const select = document.getElementById('show-form-screen');
  if (!select) return;
  let options = '';
  adminTheaters.forEach(t => {
    if (t.screens) {
      t.screens.forEach(s => {
        options += `<option value="${s.id}">${escapeHtml(t.name)} - ${escapeHtml(s.name)} (${s.totalSeats} seats)</option>`;
      });
    }
  });
  select.innerHTML = options || '<option disabled>No screens found. Add a screen first.</option>';
}

function openModal(modalId) {
  const m = document.getElementById(modalId);
  if (m) m.classList.add('open');
}

function closeModal(modalId) {
  const m = document.getElementById(modalId);
  if (m) m.classList.remove('open');
}

function formatTime(timeStr) {
  if (!timeStr) return '';
  const parts = timeStr.split(':');
  let hour = parseInt(parts[0], 10);
  const min = parts[1];
  const ampm = hour >= 12 ? 'PM' : 'AM';
  hour = hour % 12;
  hour = hour ? hour : 12;
  return `${hour}:${min} ${ampm}`;
}
