// ==============================================================
// Cinema Ticket Booking System - Movie Detail, Formats & Shows
// ==============================================================

let currentMovie = null;
let allShows = [];
let selectedFormat = 'ALL';

document.addEventListener('DOMContentLoaded', () => {
  initMovieDetailPage();
});

async function initMovieDetailPage() {
  const params = new URLSearchParams(window.location.search);
  const movieId = params.get('id');

  if (!movieId) {
    window.location.href = '/index.html';
    return;
  }

  await loadMovieDetails(movieId);
  await loadMovieShows(movieId);
}

async function loadMovieDetails(movieId) {
  const container = document.getElementById('movie-header-container');
  if (!container) return;

  try {
    const res = await api.get(`/movies/${movieId}`);
    const movie = res.data;
    currentMovie = movie;

    document.title = `${movie.title} - Book Tickets | Cinema`;

    const isUpcoming = movie.isUpcoming || (movie.releaseDate && new Date(movie.releaseDate + 'T00:00:00') > new Date());
    const formats = movie.availableFormats || ['2D', '3D', 'IMAX'];
    const formatsHtml = formats.map(f => {
      const cls = f.toLowerCase() === 'imax' ? 'imax' : (f.includes('3D') ? 'three-d' : 'two-d');
      return `<span class="format-chip ${cls}">${escapeHtml(f)}</span>`;
    }).join('');

    container.innerHTML = `
      <div class="movie-detail-header">
        <div class="movie-detail-poster">
          <img src="${escapeHtml(movie.posterUrl || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800')}" 
               alt="${escapeHtml(movie.title)}"
               onerror="this.src='https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800'">
        </div>
        <div class="movie-detail-content">
          <h1 class="movie-detail-title">${escapeHtml(movie.title)}</h1>
          <div class="movie-tags">
            ${isUpcoming ? '<span class="movie-tag" style="background: rgba(245, 158, 11, 0.15); color: #f59e0b; border: 1px solid rgba(245, 158, 11, 0.3);">🔥 Coming Soon</span>' : ''}
            <span class="movie-tag">🎭 ${escapeHtml(movie.genre)}</span>
            <span class="movie-tag">🌐 ${escapeHtml(movie.language)}</span>
            <span class="movie-tag">⏱ ${movie.durationMinutes} Minutes</span>
            <span class="movie-tag">📅 Released ${escapeHtml(movie.releaseDate)}</span>
          </div>

          <div style="margin: 12px 0 16px;">
            <span style="font-size: 0.85rem; color: var(--text-muted); margin-right: 8px;">Available Experiences:</span>
            <div class="format-chips" style="display: inline-flex; vertical-align: middle; margin-bottom: 0;">
              ${formatsHtml}
            </div>
          </div>

          <p style="color: var(--text-muted); line-height: 1.7; font-size: 1rem; margin-top: 4px;">
            ${escapeHtml(movie.description || 'No description provided.')}
          </p>
        </div>
      </div>
    `;

    // Render Cast & Crew
    renderCastAndCrew(movie);
  } catch (err) {
    container.innerHTML = `
      <div style="text-align: center; padding: 40px; color: #ef4444;">
        <h2>Movie not found</h2>
        <p>${escapeHtml(err.message)}</p>
        <a href="/index.html" class="btn btn-secondary" style="margin-top: 16px;">Back to Movies</a>
      </div>
    `;
  }
}

async function loadMovieShows(movieId) {
  const container = document.getElementById('shows-container');
  const formatSection = document.getElementById('format-selector-section');
  if (!container) return;

  try {
    const res = await api.get(`/shows?movieId=${movieId}`);
    const shows = res.data || [];
    allShows = shows;

    if (!shows || shows.length === 0) {
      if (formatSection) formatSection.style.display = 'none';

      const isUpcoming = currentMovie && (currentMovie.isUpcoming || (currentMovie.releaseDate && new Date(currentMovie.releaseDate + 'T00:00:00') > new Date()));

      if (isUpcoming) {
        container.innerHTML = `
          <div style="text-align: center; padding: 50px 30px; background: var(--bg-card); border: 1px solid rgba(245, 158, 11, 0.25); border-radius: var(--radius-md);">
            <div style="font-size: 2.2rem; margin-bottom: 12px;">🚀</div>
            <h3 style="font-size: 1.3rem; margin-bottom: 8px;">Upcoming Theatrical Premiere</h3>
            <p style="color: var(--text-muted); max-width: 500px; margin: 0 auto 20px auto; line-height: 1.6;">
              Online ticket reservations and auditorium showtimes for <strong>${escapeHtml(currentMovie ? currentMovie.title : 'this title')}</strong> will be published 5 days prior to theatrical release date.
            </p>
            <a href="/index.html" class="btn btn-primary btn-sm">Browse Other Movies</a>
          </div>
        `;
      } else {
        container.innerHTML = `
          <div style="text-align: center; padding: 40px; background: var(--bg-card); border-radius: var(--radius-md);">
            <p style="color: var(--text-muted); font-size: 1.1rem;">No upcoming shows scheduled for this movie.</p>
          </div>
        `;
      }
      return;
    }

    // Initialize Format Selection Bar
    setupFormatBar(shows);

    // Render shows
    renderFilteredShows();
  } catch (err) {
    container.innerHTML = `<p style="color: #ef4444; text-align: center; padding: 40px;">Failed to load shows: ${escapeHtml(err.message)}</p>`;
  }
}

function setupFormatBar(shows) {
  const formatSection = document.getElementById('format-selector-section');
  const formatPills = document.getElementById('format-pills');
  if (!formatSection || !formatPills) return;

  formatSection.style.display = 'block';

  // Count shows by format
  const counts = {
    '2D': 0,
    '3D': 0,
    'IMAX': 0
  };

  shows.forEach(s => {
    let f = s.format || '2D';
    if (!counts[f]) counts[f] = 0;
    counts[f]++;
  });

  const formatsConfig = [
    { key: 'ALL', label: '🎞️ All Formats', count: shows.length, available: true },
    { key: '2D', label: '📽️ 2D Digital', count: counts['2D'] || 0, available: (counts['2D'] > 0) },
    { key: '3D', label: '🕶️ 3D Dolby', count: counts['3D'] || 0, available: (counts['3D'] > 0) },
    { key: 'IMAX', label: '🌟 IMAX Laser', count: counts['IMAX'] || 0, available: (counts['IMAX'] > 0) }
  ];

  formatPills.innerHTML = formatsConfig.map(cfg => {
    const isActive = (selectedFormat === cfg.key);
    const countBadge = cfg.available 
      ? `<span class="badge" style="background: rgba(255,255,255,0.15); margin-left: 6px; font-size: 0.75rem;">${cfg.count}</span>`
      : `<span style="font-size: 0.72rem; opacity: 0.6; margin-left: 6px;">(Not Available)</span>`;

    return `
      <button class="format-btn ${isActive ? 'active' : ''} ${!cfg.available ? 'disabled' : ''}" 
              onclick="selectFormat('${cfg.key}')" 
              ${!cfg.available ? 'disabled' : ''}>
        <span>${cfg.label}</span>
        ${countBadge}
      </button>
    `;
  }).join('');
}

function selectFormat(fmt) {
  selectedFormat = fmt;

  // Update button states
  const buttons = document.querySelectorAll('.format-btn');
  buttons.forEach(btn => {
    if (btn.getAttribute('onclick') && btn.getAttribute('onclick').includes(`'${fmt}'`)) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  const activeBadge = document.getElementById('format-active-badge');
  if (activeBadge) {
    if (fmt === 'ALL') {
      activeBadge.textContent = 'Showing All Formats';
      activeBadge.style.display = 'none';
    } else {
      activeBadge.textContent = `Filtered by: ${fmt}`;
      activeBadge.style.display = 'inline-block';
    }
  }

  renderFilteredShows();
}

function renderFilteredShows() {
  const container = document.getElementById('shows-container');
  if (!container) return;

  const filteredShows = (selectedFormat === 'ALL') 
    ? allShows 
    : allShows.filter(s => (s.format || '2D') === selectedFormat);

  if (filteredShows.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 40px; background: var(--bg-card); border-radius: var(--radius-md);">
        <p style="color: var(--text-muted); font-size: 1rem;">
          No shows available in <strong>${escapeHtml(selectedFormat)}</strong> for this movie. 
          <a href="javascript:void(0)" onclick="selectFormat('ALL')" style="color: var(--accent-primary); text-decoration: underline; margin-left: 6px;">View All Formats</a>
        </p>
      </div>
    `;
    return;
  }

  // Group shows by Theater
  const theaterMap = new Map();
  filteredShows.forEach(show => {
    const theaterKey = show.theaterId || 'unknown';
    if (!theaterMap.has(theaterKey)) {
      theaterMap.set(theaterKey, {
        theaterName: show.theaterName,
        theaterCity: show.theaterCity,
        showsByScreen: new Map()
      });
    }
    const theater = theaterMap.get(theaterKey);
    const screenKey = show.screenId;
    if (!theater.showsByScreen.has(screenKey)) {
      theater.showsByScreen.set(screenKey, {
        screenName: show.screenName,
        format: show.format || '2D',
        shows: []
      });
    }
    theater.showsByScreen.get(screenKey).shows.push(show);
  });

  let html = '';
  theaterMap.forEach((theater) => {
    html += `
      <div class="theater-group">
        <div class="theater-header">
          <div>
            <div class="theater-name">${escapeHtml(theater.theaterName)}</div>
            <div class="theater-location">📍 ${escapeHtml(theater.theaterCity)}</div>
          </div>
        </div>
        <div class="screens-list">
    `;

    theater.showsByScreen.forEach((screenGroup) => {
      const fmtCls = screenGroup.format.toLowerCase() === 'imax' ? 'imax' : (screenGroup.format.includes('3D') ? 'three-d' : 'two-d');

      html += `
        <div class="screen-item">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
            <div class="screen-badge">🎬 ${escapeHtml(screenGroup.screenName)}</div>
            <span class="format-chip ${fmtCls}">${escapeHtml(screenGroup.format)}</span>
          </div>
          <div class="showtimes-grid">
            ${screenGroup.shows.map(show => {
              const formattedTime = formatTime(show.showTime);
              const isSoldOut = show.availableSeatsCount === 0;
              const formatParam = encodeURIComponent(show.format || '2D');
              return `
                <a href="${isSoldOut ? '#' : `/seat-selection.html?showId=${show.id}&format=${formatParam}`}" 
                   class="showtime-pill ${isSoldOut ? 'disabled' : ''}" 
                   title="${isSoldOut ? 'Sold Out' : `${show.availableSeatsCount} seats available`}"
                   style="${isSoldOut ? 'opacity: 0.4; cursor: not-allowed;' : ''}">
                  <span class="showtime-hour">${formattedTime}</span>
                  <span class="showtime-price">From $${Number(show.startingPrice).toFixed(2)}</span>
                  <span style="font-size: 0.7rem; color: ${isSoldOut ? '#ef4444' : 'var(--text-muted)'}; margin-top: 2px;">
                    ${isSoldOut ? 'Sold Out' : `${show.availableSeatsCount} left`}
                  </span>
                </a>
              `;
            }).join('')}
          </div>
        </div>
      `;
    });

    html += `
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

function formatTime(timeStr) {
  if (!timeStr) return '';
  const parts = timeStr.split(':');
  let hour = parseInt(parts[0], 10);
  const min = parts[1];
  const ampm = hour >= 12 ? 'PM' : 'AM';
  hour = hour % 12;
  hour = hour ? hour : 12;
  return `${hour}:${min} ${ampm}`;
}

function renderCastAndCrew(movie) {
  const section = document.getElementById('cast-crew-section');
  const directorBadge = document.getElementById('director-badge');
  const castGrid = document.getElementById('cast-grid');
  const crewGrid = document.getElementById('crew-grid');

  if (!section) return;

  const hasCast = movie.cast && movie.cast.length > 0;
  const hasCrew = movie.crew && movie.crew.length > 0;
  const hasDirector = !!movie.director;

  if (!hasCast && !hasCrew && !hasDirector) {
    section.style.display = 'none';
    return;
  }

  section.style.display = 'block';

  if (directorBadge) {
    if (movie.director) {
      directorBadge.textContent = `🎬 Directed by ${movie.director}`;
      directorBadge.style.display = 'inline-block';
    } else {
      directorBadge.style.display = 'none';
    }
  }

  if (castGrid) {
    if (hasCast) {
      castGrid.innerHTML = movie.cast.map(c => `
        <div class="cast-card">
          <div class="cast-photo-wrapper">
            <img src="${escapeHtml(c.imageUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200')}" 
                 alt="${escapeHtml(c.name)}" 
                 loading="lazy"
                 onerror="this.src='https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200'">
          </div>
          <div class="cast-name">${escapeHtml(c.name)}</div>
          <div class="cast-role">${escapeHtml(c.role || 'Cast')}</div>
        </div>
      `).join('');
    } else {
      castGrid.innerHTML = `<p style="color: var(--text-muted); font-size: 0.9rem;">Cast information coming soon.</p>`;
    }
  }

  if (crewGrid) {
    if (hasCrew) {
      crewGrid.innerHTML = movie.crew.map(cr => `
        <div class="crew-card">
          <div class="crew-role">${escapeHtml(cr.role)}</div>
          <div class="crew-name">${escapeHtml(cr.name)}</div>
        </div>
      `).join('');
    } else {
      crewGrid.innerHTML = `<p style="color: var(--text-muted); font-size: 0.9rem;">Crew information coming soon.</p>`;
    }
  }
}
