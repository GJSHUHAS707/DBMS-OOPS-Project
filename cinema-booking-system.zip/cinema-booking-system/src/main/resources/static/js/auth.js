// ==============================================================
// Cinema Ticket Booking System - Auth UI & State Manager
// ==============================================================

document.addEventListener('DOMContentLoaded', () => {
  renderNavbar();
  initAuthPages();
});

function renderNavbar() {
  const navUserMenu = document.getElementById('nav-user-menu');
  if (!navUserMenu) return;

  const user = api.getUser();
  const isAuth = api.isAuthenticated();

  if (isAuth && user) {
    let adminLink = '';
    if (user.role === 'ADMIN') {
      adminLink = `<a href="/admin.html" class="btn btn-secondary btn-sm">Admin Dashboard</a>`;
    }

    navUserMenu.innerHTML = `
      ${adminLink}
      <a href="/my-bookings.html" class="btn btn-secondary btn-sm">My Bookings</a>
      <div class="user-badge">
        <span>${escapeHtml(user.name)}</span>
        <span class="role-pill">${escapeHtml(user.role)}</span>
      </div>
      <button onclick="handleLogout()" class="btn btn-secondary btn-sm" title="Sign Out">Sign Out</button>
    `;
  } else {
    navUserMenu.innerHTML = `
      <a href="/login.html" class="btn btn-primary btn-sm">Sign In / Register</a>
    `;
  }
}

function handleLogout() {
  api.clearAuth();
  showToast('You have signed out', 'info');
  setTimeout(() => {
    window.location.href = '/index.html';
  }, 500);
}

function initAuthPages() {
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');

  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('login-email').value;
      const password = document.getElementById('login-password').value;
      const submitBtn = loginForm.querySelector('button[type="submit"]');

      try {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Signing in...';

        const res = await api.post('/auth/login', { email, password });
        api.setAuth(res.data.token, res.data.user);
        showToast('Welcome back, ' + res.data.user.name + '!', 'success');

        const params = new URLSearchParams(window.location.search);
        const redirectUrl = params.get('redirect') || '/index.html';

        setTimeout(() => {
          window.location.href = redirectUrl;
        }, 800);
      } catch (err) {
        showToast(err.message, 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Sign In';
      }
    });
  }

  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('reg-name').value;
      const email = document.getElementById('reg-email').value;
      const password = document.getElementById('reg-password').value;
      const submitBtn = registerForm.querySelector('button[type="submit"]');

      try {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Creating account...';

        const res = await api.post('/auth/register', { name, email, password });
        api.setAuth(res.data.token, res.data.user);
        showToast('Registration successful! Welcome, ' + res.data.user.name, 'success');

        const params = new URLSearchParams(window.location.search);
        const redirectUrl = params.get('redirect') || '/index.html';

        setTimeout(() => {
          window.location.href = redirectUrl;
        }, 800);
      } catch (err) {
        showToast(err.message, 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Create Account';
      }
    });
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
