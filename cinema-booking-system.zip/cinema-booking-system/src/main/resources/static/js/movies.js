// ==============================================================
// Cinema Ticket Booking System - Movie Listing & Upcoming Movies
// ==============================================================

let currentTab = 'all'; // 'all' | 'now-showing' | 'upcoming'
let currentSearch = '';
let currentGenre = '';
let currentLanguage = '';
let searchDebounceTimeout = null;
let allLoadedMovies = [];

document.addEventListener('DOMContentLoaded', () => {
  initMoviesPage();
});

async function initMoviesPage() {
  setupTabListeners();
  setupFilterListeners();
  await loadMovies();
}

function setupTabListeners() {
  const tabs = document.querySelectorAll('.category-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentTab = tab.dataset.tab || 'all';
      applyTabVisibility();
    });
  });
}

function applyTabVisibility() {
  const nowShowingSec = document.getElementById('now-showing-section');
  const upcomingSec = document.getElementById('upcoming-movies-section');

  if (!nowShowingSec || !upcomingSec) return;

  if (currentTab === 'all') {
    nowShowingSec.style.display = 'block';
    upcomingSec.style.display = 'block';
  } else if (currentTab === 'now-showing') {
    nowShowingSec.style.display = 'block';
    upcomingSec.style.display = 'none';
  } else if (currentTab === 'upcoming') {
    nowShowingSec.style.display = 'none';
    upcomingSec.style.display = 'block';
  }
}

function setupFilterListeners() {
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      clearTimeout(searchDebounceTimeout);
      searchDebounceTimeout = setTimeout(() => {
        currentSearch = e.target.value.trim();
        loadMovies();
      }, 300);
    });
  }

  const langSelect = document.getElementById('language-filter');
  if (langSelect) {
    langSelect.addEventListener('change', (e) => {
      currentLanguage = e.target.value;
      loadMovies();
    });
  }

  const genrePills = document.querySelectorAll('.genre-pill');
  genrePills.forEach(pill => {
    pill.addEventListener('click', () => {
      genrePills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentGenre = pill.dataset.genre || '';
      loadMovies();
    });
  });
}

async function loadMovies() {
  const moviesGrid = document.getElementById('movies-grid');
  const upcomingGrid = document.getElementById('upcoming-movies-grid');

  if (moviesGrid) {
    moviesGrid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 40px 0;">
        <p style="color: var(--text-muted); font-size: 1.05rem;">Loading blockbusters...</p>
      </div>
    `;
  }
  if (upcomingGrid) {
    upcomingGrid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 40px 0;">
        <p style="color: var(--text-muted); font-size: 1.05rem;">Loading upcoming sensations...</p>
      </div>
    `;
  }

  try {
    const params = new URLSearchParams();
    if (currentSearch) params.append('search', currentSearch);
    if (currentGenre) params.append('genre', currentGenre);
    if (currentLanguage) params.append('language', currentLanguage);

    const query = params.toString() ? `?${params.toString()}` : '';
    const res = await api.get(`/movies${query}`);
    const movies = res.data || [];
    allLoadedMovies = movies;

    // Distinguish now showing vs upcoming
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const nowShowing = [];
    const upcoming = [];

    movies.forEach(m => {
      let isUp = m.isUpcoming;
      if (isUp === undefined && m.releaseDate) {
        const rDate = new Date(m.releaseDate + 'T00:00:00');
        isUp = rDate > today;
      }
      if (isUp) {
        upcoming.push(m);
      } else {
        nowShowing.push(m);
      }
    });

    // Update counts
    updateBadgeCounts(movies.length, nowShowing.length, upcoming.length);

    // Render Now Showing
    renderNowShowing(nowShowing);

    // Render Upcoming
    renderUpcoming(upcoming);

    applyTabVisibility();
  } catch (err) {
    if (moviesGrid) {
      moviesGrid.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 40px 0; color: #ef4444;">
          <p>Failed to load movies: ${escapeHtml(err.message)}</p>
        </div>
      `;
    }
  }
}

function updateBadgeCounts(total, showingCount, upcomingCount) {
  const elAll = document.getElementById('count-all');
  const elShowing = document.getElementById('count-showing');
  const elUpcoming = document.getElementById('count-upcoming');
  const badgeShowing = document.getElementById('badge-now-showing-count');
  const badgeUpcoming = document.getElementById('badge-upcoming-count');

  if (elAll) elAll.textContent = total;
  if (elShowing) elShowing.textContent = showingCount;
  if (elUpcoming) elUpcoming.textContent = upcomingCount;

  if (badgeShowing) badgeShowing.textContent = `${showingCount} In Theaters`;
  if (badgeUpcoming) badgeUpcoming.textContent = `${upcomingCount} Coming Soon`;
}

function renderNowShowing(movies) {
  const moviesGrid = document.getElementById('movies-grid');
  if (!moviesGrid) return;

  if (movies.length === 0) {
    moviesGrid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 40px 0; background: var(--bg-card); border-radius: var(--radius-md);">
        <p style="color: var(--text-muted); font-size: 1rem;">No currently showing movies found matching your criteria.</p>
      </div>
    `;
    return;
  }

  moviesGrid.innerHTML = movies.map(movie => {
    const formats = movie.availableFormats || ['2D', '3D', 'IMAX'];
    const formatsHtml = formats.map(f => {
      const cls = f.toLowerCase() === 'imax' ? 'imax' : (f.includes('3D') ? 'three-d' : 'two-d');
      return `<span class="format-chip ${cls}">${escapeHtml(f)}</span>`;
    }).join('');

    const bookedCount = movie.bookedLastHour || (30 + (movie.id * 11) % 35);

    return `
      <div class="movie-card">
        <div class="movie-poster-wrapper">
          <img src="${escapeHtml(movie.posterUrl || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800')}" 
               alt="${escapeHtml(movie.title)}" 
               loading="lazy"
               onerror="this.src='https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800'">
          <div class="movie-overlay-badge">${escapeHtml(movie.genre)}</div>
        </div>
        <div class="movie-info">
          <div class="velocity-badge">
            <span class="flame-icon">🔥</span>
            <span><strong>${bookedCount}</strong> tickets booked in last hour</span>
          </div>
          <h3 class="movie-title">${escapeHtml(movie.title)}</h3>
          <div class="movie-meta">
            <span>⏱ ${movie.durationMinutes} min</span>
            <span>•</span>
            <span>🌐 ${escapeHtml(movie.language)}</span>
            ${movie.director ? `<span>•</span> <span>🎬 ${escapeHtml(movie.director)}</span>` : ''}
          </div>
          <div class="format-chips">
            ${formatsHtml}
          </div>
          <p class="movie-desc">${escapeHtml(movie.description || 'No description available.')}</p>
          <a href="/movie-detail.html?id=${movie.id}" class="btn btn-primary" style="margin-top: auto; width: 100%;">
            Book Tickets
          </a>
        </div>
      </div>
    `;
  }).join('');
}

function renderUpcoming(movies) {
  const upcomingGrid = document.getElementById('upcoming-movies-grid');
  if (!upcomingGrid) return;

  if (movies.length === 0) {
    upcomingGrid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 40px 0; background: var(--bg-card); border-radius: var(--radius-md);">
        <p style="color: var(--text-muted); font-size: 1rem;">No upcoming movies matching your criteria right now.</p>
      </div>
    `;
    return;
  }

  const reminders = getSavedReminders();
  const likes = getSavedLikes();

  upcomingGrid.innerHTML = movies.map(movie => {
    const isReminded = reminders.includes(movie.id);
    const isLiked = likes.includes(movie.id);
    const dateFormatted = formatReleaseCountdown(movie.releaseDate);
    const formats = movie.availableFormats || ['2D', '3D', 'IMAX'];
    const formatsHtml = formats.map(f => {
      const cls = f.toLowerCase() === 'imax' ? 'imax' : (f.includes('3D') ? 'three-d' : 'two-d');
      return `<span class="format-chip ${cls}">${escapeHtml(f)}</span>`;
    }).join('');

    const initialCount = movie.interestedCount || 1000;
    const displayCount = isLiked ? initialCount + 1 : initialCount;

    return `
      <div class="movie-card upcoming-card">
        <div class="movie-poster-wrapper">
          <div class="badge-upcoming-ribbon">🔥 Coming Soon</div>
          <img src="${escapeHtml(movie.posterUrl || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800')}" 
               alt="${escapeHtml(movie.title)}" 
               loading="lazy"
               onerror="this.src='https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800'">
          <div class="movie-overlay-badge">${escapeHtml(movie.genre)}</div>
        </div>
        <div class="movie-info">
          <div class="release-date-pill">
            <span>📅</span>
            <span>${escapeHtml(dateFormatted)}</span>
          </div>
          <h3 class="movie-title">${escapeHtml(movie.title)}</h3>
          <div class="movie-meta">
            <span>⏱ ${movie.durationMinutes} min</span>
            <span>•</span>
            <span>🌐 ${escapeHtml(movie.language)}</span>
            ${movie.director ? `<span>•</span> <span>🎬 ${escapeHtml(movie.director)}</span>` : ''}
          </div>

          <div class="format-chips">
            ${formatsHtml}
          </div>

          <!-- Real-Time People Interested Bar & Like Button -->
          <div class="interest-bar">
            <span class="interest-count-pill" id="interest-count-${movie.id}">
              ❤️ <strong>${displayCount.toLocaleString()}</strong> people interested
            </span>
            <button class="btn-like-interest ${isLiked ? 'liked' : ''}" 
                    id="like-btn-${movie.id}" 
                    onclick="toggleLike(${movie.id}, '${escapeHtml(movie.title.replace(/'/g, "\\'"))}', ${initialCount})">
              <span class="like-icon">${isLiked ? '❤️' : '🤍'}</span>
              <span>${isLiked ? 'Interested' : "I'm Interested"}</span>
            </button>
          </div>

          <p class="movie-desc">${escapeHtml(movie.description || 'No description available.')}</p>

          <div class="upcoming-actions">
            <button class="btn btn-secondary btn-sm" onclick="openUpcomingModal(${movie.id})">
              ℹ️ Details
            </button>
            <button class="btn-remind ${isReminded ? 'reminded' : ''}" 
                    id="remind-btn-${movie.id}" 
                    onclick="toggleReminder(${movie.id}, '${escapeHtml(movie.title.replace(/'/g, "\\'"))}')">
              <span>${isReminded ? '✓ Reminded' : '🔔 Remind Me'}</span>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function formatReleaseCountdown(dateStr) {
  if (!dateStr) return 'Coming Soon';
  try {
    const release = new Date(dateStr + 'T00:00:00');
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const diffMs = release - today;
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

    const options = { month: 'short', day: 'numeric', year: 'numeric' };
    const dateFormatted = release.toLocaleDateString(undefined, options);

    if (diffDays > 0 && diffDays <= 30) {
      return `Releases in ${diffDays} days (${dateFormatted})`;
    } else if (diffDays > 30) {
      return `Releasing ${dateFormatted}`;
    } else {
      return `Releasing Soon (${dateFormatted})`;
    }
  } catch (e) {
    return `Releases: ${dateStr}`;
  }
}

// ==============================================================
// Likes & Interest System (Interactive & Persisted)
// ==============================================================
function getSavedLikes() {
  try {
    const raw = localStorage.getItem('cinebook_movie_likes');
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

function saveLikes(arr) {
  try {
    localStorage.setItem('cinebook_movie_likes', JSON.stringify(arr));
  } catch (e) {}
}

async function toggleLike(movieId, movieTitle, baseCount) {
  let likes = getSavedLikes();
  const exists = likes.includes(movieId);
  const btn = document.getElementById(`like-btn-${movieId}`);
  const countEl = document.getElementById(`interest-count-${movieId}`);
  const movie = allLoadedMovies.find(m => m.id === movieId);
  const currentBase = baseCount || (movie ? movie.interestedCount : 1000) || 1000;

  if (exists) {
    // Un-like
    likes = likes.filter(id => id !== movieId);
    saveLikes(likes);
    if (btn) {
      btn.classList.remove('liked');
      btn.innerHTML = '<span class="like-icon">🤍</span> <span>I\'m Interested</span>';
    }
    if (countEl) {
      countEl.innerHTML = `❤️ <strong>${currentBase.toLocaleString()}</strong> people interested`;
    }
    showToast(`Removed interest for "${movieTitle}"`, 'info');
  } else {
    // Like
    likes.push(movieId);
    saveLikes(likes);
    if (btn) {
      btn.classList.add('liked');
      btn.innerHTML = '<span class="like-icon">❤️</span> <span>Interested</span>';
    }
    const newTotal = currentBase + 1;
    if (countEl) {
      countEl.innerHTML = `❤️ <strong>${newTotal.toLocaleString()}</strong> people interested`;
    }

    // Call backend API to persist
    try {
      await api.post(`/movies/${movieId}/interest`);
    } catch (e) {
      console.log('Interest recorded locally');
    }

    showToast(`🎉 You showed interest in "${movieTitle}"! We'll alert you when tickets release.`, 'success');
  }
}

// ==============================================================
// Reminder System (LocalStorage)
// ==============================================================
function getSavedReminders() {
  try {
    const raw = localStorage.getItem('cinebook_movie_reminders');
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

function saveReminders(arr) {
  try {
    localStorage.setItem('cinebook_movie_reminders', JSON.stringify(arr));
  } catch (e) {}
}

function toggleReminder(movieId, movieTitle) {
  let reminders = getSavedReminders();
  const exists = reminders.includes(movieId);
  const btn = document.getElementById(`remind-btn-${movieId}`);
  const modalBtn = document.getElementById('upcoming-modal-remind-btn');

  if (exists) {
    reminders = reminders.filter(id => id !== movieId);
    saveReminders(reminders);
    if (btn) {
      btn.classList.remove('reminded');
      btn.innerHTML = '<span>🔔 Remind Me</span>';
    }
    if (modalBtn) {
      modalBtn.classList.remove('btn-success');
      modalBtn.classList.add('btn-primary');
      modalBtn.textContent = '🔔 Remind Me';
    }
    showToast(`Reminder removed for "${movieTitle}"`, 'info');
  } else {
    reminders.push(movieId);
    saveReminders(reminders);
    if (btn) {
      btn.classList.add('reminded');
      btn.innerHTML = '<span>✓ Reminded</span>';
    }
    if (modalBtn) {
      modalBtn.classList.remove('btn-primary');
      modalBtn.classList.add('btn-success');
      modalBtn.textContent = '✓ Reminder Set';
    }
    showToast(`🎉 Reminder set! We will notify you when ticket bookings open for "${movieTitle}"!`, 'success');
  }
}

// ==============================================================
// Upcoming Movie Modal Details
// ==============================================================
function openUpcomingModal(movieId) {
  const movie = allLoadedMovies.find(m => m.id === movieId);
  if (!movie) return;

  const modal = document.getElementById('upcoming-modal');
  const titleEl = document.getElementById('upcoming-modal-title');
  const bodyEl = document.getElementById('upcoming-modal-body');
  const dateEl = document.getElementById('upcoming-modal-date');
  const remindBtn = document.getElementById('upcoming-modal-remind-btn');

  if (!modal || !bodyEl) return;

  const reminders = getSavedReminders();
  const isReminded = reminders.includes(movie.id);

  if (titleEl) titleEl.textContent = movie.title;
  if (dateEl) {
    dateEl.innerHTML = `🗓️ Official Premiere: <strong>${escapeHtml(formatReleaseCountdown(movie.releaseDate))}</strong>`;
  }

  const formats = movie.availableFormats || ['2D', '3D', 'IMAX'];
  const formatsHtml = formats.map(f => {
    const cls = f.toLowerCase() === 'imax' ? 'imax' : (f.includes('3D') ? 'three-d' : 'two-d');
    return `<span class="format-chip ${cls}">${escapeHtml(f)}</span>`;
  }).join('');

  bodyEl.innerHTML = `
    <div style="display: flex; gap: 20px; flex-wrap: wrap;">
      <div style="width: 160px; flex-shrink: 0; border-radius: var(--radius-sm); overflow: hidden; box-shadow: var(--shadow-md);">
        <img src="${escapeHtml(movie.posterUrl || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800')}" 
             alt="${escapeHtml(movie.title)}" 
             style="width: 100%; height: 230px; object-fit: cover;"
             onerror="this.src='https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800'">
      </div>
      <div style="flex: 1; min-width: 220px; display: flex; flex-direction: column;">
        <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 10px;">
          <span class="movie-tag" style="background: rgba(245, 158, 11, 0.15); color: #f59e0b; border: 1px solid rgba(245, 158, 11, 0.3);">
            🔥 Upcoming Release
          </span>
          <span class="movie-tag">🎭 ${escapeHtml(movie.genre)}</span>
          <span class="movie-tag">🌐 ${escapeHtml(movie.language)}</span>
          <span class="movie-tag">⏱ ${movie.durationMinutes} min</span>
        </div>
        <div class="format-chips" style="margin-bottom: 12px;">
          ${formatsHtml}
        </div>
        ${movie.director ? `
          <div style="margin-bottom: 8px; font-size: 0.88rem;">
            <strong style="color: var(--text-main);">🎬 Director:</strong> 
            <span style="color: #f5c518; font-weight: 600;">${escapeHtml(movie.director)}</span>
          </div>
        ` : ''}
        ${(movie.cast && movie.cast.length > 0) ? `
          <div style="margin-bottom: 12px; font-size: 0.85rem;">
            <strong style="color: var(--text-main);">🌟 Starring:</strong> 
            <span style="color: var(--text-muted);">${escapeHtml(movie.cast.map(c => c.name).join(', '))}</span>
          </div>
        ` : ''}
        <h4 style="font-size: 1rem; margin-bottom: 6px; color: var(--text-main);">Storyline & Teaser:</h4>
        <p style="color: var(--text-muted); font-size: 0.92rem; line-height: 1.6; margin-bottom: 16px;">
          ${escapeHtml(movie.description || 'Full storyline and trailer announcement coming soon.')}
        </p>
        <div style="margin-top: auto; padding: 12px; background: rgba(255, 255, 255, 0.03); border: 1px solid var(--border-color); border-radius: var(--radius-sm); font-size: 0.85rem; color: var(--text-muted);">
          🎟️ <em>Show schedules and IMAX / Dolby seat selections will be published 5 days prior to theatrical release.</em>
        </div>
      </div>
    </div>
  `;

  if (remindBtn) {
    if (isReminded) {
      remindBtn.className = 'btn btn-success btn-sm';
      remindBtn.textContent = '✓ Reminder Set';
    } else {
      remindBtn.className = 'btn btn-primary btn-sm';
      remindBtn.textContent = '🔔 Remind Me';
    }
    remindBtn.onclick = () => toggleReminder(movie.id, movie.title);
  }

  modal.classList.add('open');
}

function closeUpcomingModal() {
  const modal = document.getElementById('upcoming-modal');
  if (modal) modal.classList.remove('open');
}

// Fallback HTML escaper if not loaded
function escapeHtml(str) {
  if (typeof str !== 'string') return str || '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
