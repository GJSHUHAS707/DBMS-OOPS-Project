-- ==============================================================
-- Cinema Ticket Booking System - Seed Data
-- ==============================================================

-- 1. Seed Users (passwords are BCrypt hash of 'admin123' and 'user123')
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`) VALUES 
(1, 'Cinema Admin', 'admin@cinema.com', '$2a$10$7s/L4w094Qh54G8O7b/VpeQpX0U2N.csk1rU0WdF20G6uQoYf3V7e', 'ADMIN', CURRENT_TIMESTAMP),
(2, 'Jane Doe', 'user@cinema.com', '$2a$10$7s/L4w094Qh54G8O7b/VpeQpX0U2N.csk1rU0WdF20G6uQoYf3V7e', 'USER', CURRENT_TIMESTAMP);

-- 2. Seed Movies (Now Showing & Upcoming)
INSERT INTO `movies` (`id`, `title`, `description`, `genre`, `language`, `duration_minutes`, `poster_url`, `release_date`) VALUES 
(1, 'Inception', 'A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O., but his tragic past may doom the project and his team to disaster.', 'Sci-Fi', 'English', 148, 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&auto=format&fit=crop&q=80', '2024-07-16'),
(2, 'Interstellar', 'When Earth becomes uninhabitable in the future, a farmer and ex-NASA pilot, Joseph Cooper, is tasked to pilot a spacecraft, along with a team of researchers, to find a new planet for humans.', 'Adventure', 'English', 169, 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80', '2024-11-07'),
(3, 'The Dark Knight', 'When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.', 'Action', 'English', 152, 'https://images.unsplash.com/photo-1509281373149-e957c6296406?w=800&auto=format&fit=crop&q=80', '2024-07-18'),
(4, 'Gladiator II', 'Years after witnessing the death of the revered hero Maximus at the hands of his uncle, Lucius must enter the Colosseum to restore the glory of Rome.', 'Action', 'English', 148, 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=800&auto=format&fit=crop&q=80', '2026-11-22'),
(5, 'Dune: Part Three', 'Paul Atreides continues his epic mythic journey as emperor of the known universe, facing complex geopolitical unrest and the ultimate destiny of Arrakis.', 'Sci-Fi', 'English', 165, 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&auto=format&fit=crop&q=80', '2026-12-18'),
(6, 'Spider-Man: Beyond the Spider-Verse', 'Miles Morales catapults across the Multiverse to prevent the canon event catastrophe, confronting friends and foes across every dimension.', 'Animation', 'English', 140, 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=800&auto=format&fit=crop&q=80', '2027-03-15'),
(7, 'Avengers: Secret Wars', 'The multiverse collides in the ultimate battle as heroes from across realities assemble to save existence itself from total collapse.', 'Action', 'English', 180, 'https://images.unsplash.com/photo-1635805737707-575885ab0820?w=800&auto=format&fit=crop&q=80', '2027-05-07');

-- 3. Seed Theaters (2 theaters)
INSERT INTO `theaters` (`id`, `name`, `city`, `address`) VALUES 
(1, 'Grand Cineplex Downtown', 'New York', '123 Broadway Blvd, Suite 400'),
(2, 'Starlight IMAX Cinema', 'San Francisco', '789 Market Street, Financial District');

-- 4. Seed Screens
INSERT INTO `screens` (`id`, `theater_id`, `name`, `total_rows`, `total_cols`) VALUES 
(1, 1, 'Screen 1 (IMAX Laser)', 5, 8),
(2, 1, 'Screen 2 (Dolby Atmos)', 4, 6),
(3, 2, 'Main Auditorium', 5, 8);

-- 5. Seed Seats for Screen 1 (5 rows x 8 cols = 40 seats)
-- Row 1 & 2: REGULAR ($12.00)
INSERT INTO `seats` (`screen_id`, `row_number`, `col_number`, `type`, `price`) VALUES
(1, 1, 1, 'REGULAR', 12.00), (1, 1, 2, 'REGULAR', 12.00), (1, 1, 3, 'REGULAR', 12.00), (1, 1, 4, 'REGULAR', 12.00),
(1, 1, 5, 'REGULAR', 12.00), (1, 1, 6, 'REGULAR', 12.00), (1, 1, 7, 'REGULAR', 12.00), (1, 1, 8, 'REGULAR', 12.00),
(1, 2, 1, 'REGULAR', 12.00), (1, 2, 2, 'REGULAR', 12.00), (1, 2, 3, 'REGULAR', 12.00), (1, 2, 4, 'REGULAR', 12.00),
(1, 2, 5, 'REGULAR', 12.00), (1, 2, 6, 'REGULAR', 12.00), (1, 2, 7, 'REGULAR', 12.00), (1, 2, 8, 'REGULAR', 12.00),
-- Row 3 & 4: PREMIUM ($16.00)
(1, 3, 1, 'PREMIUM', 16.00), (1, 3, 2, 'PREMIUM', 16.00), (1, 3, 3, 'PREMIUM', 16.00), (1, 3, 4, 'PREMIUM', 16.00),
(1, 3, 5, 'PREMIUM', 16.00), (1, 3, 6, 'PREMIUM', 16.00), (1, 3, 7, 'PREMIUM', 16.00), (1, 3, 8, 'PREMIUM', 16.00),
(1, 4, 1, 'PREMIUM', 16.00), (1, 4, 2, 'PREMIUM', 16.00), (1, 4, 3, 'PREMIUM', 16.00), (1, 4, 4, 'PREMIUM', 16.00),
(1, 4, 5, 'PREMIUM', 16.00), (1, 4, 6, 'PREMIUM', 16.00), (1, 4, 7, 'PREMIUM', 16.00), (1, 4, 8, 'PREMIUM', 16.00),
-- Row 5: VIP ($22.00)
(1, 5, 1, 'VIP', 22.00), (1, 5, 2, 'VIP', 22.00), (1, 5, 3, 'VIP', 22.00), (1, 5, 4, 'VIP', 22.00),
(1, 5, 5, 'VIP', 22.00), (1, 5, 6, 'VIP', 22.00), (1, 5, 7, 'VIP', 22.00), (1, 5, 8, 'VIP', 22.00);

-- Seed Seats for Screen 2 (4 rows x 6 cols = 24 seats)
INSERT INTO `seats` (`screen_id`, `row_number`, `col_number`, `type`, `price`) VALUES
(2, 1, 1, 'REGULAR', 10.00), (2, 1, 2, 'REGULAR', 10.00), (2, 1, 3, 'REGULAR', 10.00), (2, 1, 4, 'REGULAR', 10.00), (2, 1, 5, 'REGULAR', 10.00), (2, 1, 6, 'REGULAR', 10.00),
(2, 2, 1, 'REGULAR', 10.00), (2, 2, 2, 'REGULAR', 10.00), (2, 2, 3, 'REGULAR', 10.00), (2, 2, 4, 'REGULAR', 10.00), (2, 2, 5, 'REGULAR', 10.00), (2, 2, 6, 'REGULAR', 10.00),
(2, 3, 1, 'PREMIUM', 15.00), (2, 3, 2, 'PREMIUM', 15.00), (2, 3, 3, 'PREMIUM', 15.00), (2, 3, 4, 'PREMIUM', 15.00), (2, 3, 5, 'PREMIUM', 15.00), (2, 3, 6, 'PREMIUM', 15.00),
(2, 4, 1, 'VIP', 20.00), (2, 4, 2, 'VIP', 20.00), (2, 4, 3, 'VIP', 20.00), (2, 4, 4, 'VIP', 20.00), (2, 4, 5, 'VIP', 20.00), (2, 4, 6, 'VIP', 20.00);

-- Seed Seats for Screen 3 (5 rows x 8 cols = 40 seats)
INSERT INTO `seats` (`screen_id`, `row_number`, `col_number`, `type`, `price`) VALUES
(3, 1, 1, 'REGULAR', 12.00), (3, 1, 2, 'REGULAR', 12.00), (3, 1, 3, 'REGULAR', 12.00), (3, 1, 4, 'REGULAR', 12.00), (3, 1, 5, 'REGULAR', 12.00), (3, 1, 6, 'REGULAR', 12.00), (3, 1, 7, 'REGULAR', 12.00), (3, 1, 8, 'REGULAR', 12.00),
(3, 2, 1, 'REGULAR', 12.00), (3, 2, 2, 'REGULAR', 12.00), (3, 2, 3, 'REGULAR', 12.00), (3, 2, 4, 'REGULAR', 12.00), (3, 2, 5, 'REGULAR', 12.00), (3, 2, 6, 'REGULAR', 12.00), (3, 2, 7, 'REGULAR', 12.00), (3, 2, 8, 'REGULAR', 12.00),
(3, 3, 1, 'PREMIUM', 16.00), (3, 3, 2, 'PREMIUM', 16.00), (3, 3, 3, 'PREMIUM', 16.00), (3, 3, 4, 'PREMIUM', 16.00), (3, 3, 5, 'PREMIUM', 16.00), (3, 3, 6, 'PREMIUM', 16.00), (3, 3, 7, 'PREMIUM', 16.00), (3, 3, 8, 'PREMIUM', 16.00),
(3, 4, 1, 'PREMIUM', 16.00), (3, 4, 2, 'PREMIUM', 16.00), (3, 4, 3, 'PREMIUM', 16.00), (3, 4, 4, 'PREMIUM', 16.00), (3, 4, 5, 'PREMIUM', 16.00), (3, 4, 6, 'PREMIUM', 16.00), (3, 4, 7, 'PREMIUM', 16.00), (3, 4, 8, 'PREMIUM', 16.00),
(3, 5, 1, 'VIP', 22.00), (3, 5, 2, 'VIP', 22.00), (3, 5, 3, 'VIP', 22.00), (3, 5, 4, 'VIP', 22.00), (3, 5, 5, 'VIP', 22.00), (3, 5, 6, 'VIP', 22.00), (3, 5, 7, 'VIP', 22.00), (3, 5, 8, 'VIP', 22.00);

-- 6. Seed Shows (for Inception, Interstellar, The Dark Knight)
INSERT INTO `shows` (`id`, `movie_id`, `screen_id`, `show_date`, `show_time`, `status`) VALUES 
(1, 1, 1, CURRENT_DATE, '14:30:00', 'UPCOMING'),
(2, 1, 1, CURRENT_DATE, '18:00:00', 'UPCOMING'),
(3, 1, 2, CURRENT_DATE, '20:30:00', 'UPCOMING'),
(4, 2, 2, CURRENT_DATE, '16:00:00', 'UPCOMING'),
(5, 2, 3, CURRENT_DATE, '19:30:00', 'UPCOMING'),
(6, 3, 3, CURRENT_DATE, '15:00:00', 'UPCOMING'),
(7, 3, 1, CURRENT_DATE, '21:15:00', 'UPCOMING');

-- 7. Seed Sample Bookings (Show 1, Jane Doe booked 2 seats: Seat 1 and Seat 2)
INSERT INTO `bookings` (`id`, `user_id`, `show_id`, `total_amount`, `status`, `created_at`) VALUES 
(1, 2, 1, 24.00, 'CONFIRMED', CURRENT_TIMESTAMP);

INSERT INTO `booking_seats` (`id`, `booking_id`, `seat_id`) VALUES 
(1, 1, 1),
(2, 1, 2);
