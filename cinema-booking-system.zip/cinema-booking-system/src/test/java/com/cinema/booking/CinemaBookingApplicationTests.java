package com.cinema.booking;

import com.cinema.booking.dto.booking.BookingRequest;
import com.cinema.booking.dto.booking.BookingResponse;
import com.cinema.booking.dto.show.ShowSeatResponse;
import com.cinema.booking.entity.*;
import com.cinema.booking.repository.*;
import com.cinema.booking.service.BookingService;
import com.cinema.booking.service.ShowService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

@SpringBootTest
@ActiveProfiles("h2")
class CinemaBookingApplicationTests {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private ShowService showService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ShowRepository showRepository;

    @Autowired
    private SeatRepository seatRepository;

    @Autowired
    private BookingSeatRepository bookingSeatRepository;

    @Test
    void testBookingAndCancellationReleasesSeats() {
        // 1. Get or create a test user
        User user = userRepository.findByEmail("user@cinema.com")
                .orElseGet(() -> userRepository.save(User.builder()
                        .name("Jane Doe")
                        .email("user@cinema.com")
                        .password("pass123")
                        .role(Role.USER)
                        .build()));

        // 2. Find an active show
        List<Show> shows = showRepository.findAll();
        Assertions.assertFalse(shows.isEmpty(), "Shows must exist");
        Show show = shows.get(0);

        // 3. Find an available seat for this screen
        List<Seat> screenSeats = seatRepository.findByScreenIdOrderByRowNumberAscColNumberAsc(show.getScreen().getId());
        Assertions.assertFalse(screenSeats.isEmpty(), "Seats must exist for screen");
        Seat seatToBook = screenSeats.get(screenSeats.size() - 1); // pick the last seat

        // 4. Book the seat
        BookingRequest bookingReq = BookingRequest.builder()
                .showId(show.getId())
                .seatIds(List.of(seatToBook.getId()))
                .build();

        BookingResponse booked = bookingService.createBooking(bookingReq, user);
        Assertions.assertNotNull(booked.getId());
        Assertions.assertEquals(BookingStatus.CONFIRMED, booked.getStatus());

        // Verify the seat is marked as booked
        List<Long> bookedSeatIds = bookingSeatRepository.findBookedSeatIdsByShowId(show.getId());
        Assertions.assertTrue(bookedSeatIds.contains(seatToBook.getId()), "Seat must be in booked seat IDs");

        List<ShowSeatResponse> seatMap = showService.getShowSeatMap(show.getId());
        boolean isMarkedBookedOnMap = seatMap.stream()
                .filter(s -> s.getId().equals(seatToBook.getId()))
                .findFirst()
                .map(ShowSeatResponse::isBooked)
                .orElse(false);
        Assertions.assertTrue(isMarkedBookedOnMap, "Seat map must show seat as booked");

        // 5. Cancel the booking
        BookingResponse cancelled = bookingService.cancelBooking(booked.getId(), user);
        Assertions.assertEquals(BookingStatus.CANCELLED, cancelled.getStatus());

        // 6. Verify that the seat is immediately released
        List<Long> bookedSeatIdsAfterCancel = bookingSeatRepository.findBookedSeatIdsByShowId(show.getId());
        Assertions.assertFalse(bookedSeatIdsAfterCancel.contains(seatToBook.getId()),
                "Cancelled booking must release the seat immediately");

        List<ShowSeatResponse> seatMapAfterCancel = showService.getShowSeatMap(show.getId());
        boolean isMarkedBookedAfterCancel = seatMapAfterCancel.stream()
                .filter(s -> s.getId().equals(seatToBook.getId()))
                .findFirst()
                .map(ShowSeatResponse::isBooked)
                .orElse(true);
        Assertions.assertFalse(isMarkedBookedAfterCancel, "Seat map must now show seat as available");

        // 7. Verify the seat can be re-booked without conflict
        BookingResponse rebooked = bookingService.createBooking(bookingReq, user);
        Assertions.assertNotNull(rebooked.getId());
        Assertions.assertEquals(BookingStatus.CONFIRMED, rebooked.getStatus());
    }
}
