# Cinema Ticket Booking System

A full-stack Cinema Ticket Booking web application built with **Java 17**, **Spring Boot 3**, **Spring Data JPA**, **Spring Security 6**, **MySQL 8**, and a **Modern Vanilla JavaScript** frontend.

---

## 🚀 Key Features

### 👤 User Features
- **JWT Authentication**: User registration and secure login with stateless JWT tokens.
- **Movie Catalog & Live Search**: Search movies by title with real-time debounce, filter by genre pills (Sci-Fi, Action, Adventure, etc.) and language.
- **Show Scheduling & Cinema View**: Browse available shows grouped by theater and screen with starting ticket prices.
- **Interactive Seat Map**:
  - Realistic cinema perspective screen visual (*"All eyes this way"*).
  - Multi-tier seat layout: **Regular**, **Premium**, and **VIP** with distinctive color coding.
  - Live seat status: Available, Selected, and Booked (disabled).
  - Dynamic checkout panel displaying selected seat labels, subtotal, and total amount.
- **Multi-Seat Transactional Booking**: Select and book multiple seats in a single atomic database transaction with concurrency conflict prevention.
- **Booking Confirmation & Digital Ticket**: Formatted cinema ticket pass with barcode/QR graphic, booking reference, and print action.
- **Booking History & Cancellation**: View all bookings with status badges (`CONFIRMED` / `CANCELLED`). Cancelling a booking **instantly releases seats** back to the show.

### 🛡️ Admin Features
- **Admin Authentication**: Pre-seeded administrator account (`admin@cinema.com`).
- **Revenue & Bookings Analytics**: Overview cards displaying total revenue, confirmed bookings, catalog count, and scheduled shows.
- **Movie Management**: Complete CRUD (Create, Read, Update, Delete) for movies with poster URLs and metadata.
- **Theaters & Auditoriums Management**: Add theaters, create screens with customized row/column grids.
- **⚡ Seat Auto-Generator**: Re-generate seating grids with one click, specifying custom prices for Regular, Premium, and VIP tiers.
- **Show Scheduling**: Schedule upcoming shows by selecting movie, theater auditorium, date, and time.
- **Comprehensive Bookings Audit**: View all customer reservations across all theaters and cancel bookings if necessary.

---

## 🛠️ Technology Stack

| Component | Technology |
|---|---|
| **Language** | Java 17 |
| **Backend Framework** | Spring Boot 3.2.5 |
| **Persistence** | Spring Data JPA, Hibernate 6 |
| **Security** | Spring Security 6, JJWT 0.12.5 (HS256) |
| **Database** | MySQL 8 (Default) / H2 In-Memory (Dev Profile) |
| **Frontend** | HTML5, CSS3 (Modern Glassmorphic Dark Mode), Vanilla JavaScript (Fetch API) |
| **Build Tool** | Apache Maven |
| **Boilerplate Reduction** | Project Lombok |

---

## 🗄️ Database Schema (MySQL 8)

The application follows the normalized schema required:

```
users (id, name, email, password, role, created_at)
  │
  ├──< bookings (id, user_id, show_id, total_amount, status, created_at)
  │       │
  │       └──< booking_seats (id, booking_id, seat_id)
  │                 │
theaters (id, name, city, address)
  │
  └──< screens (id, theater_id, name, total_rows, total_cols)
         │       │
         │       └──< seats (id, screen_id, row_number, col_number, type, price)
         │
movies (id, title, description, genre, language, duration_minutes, poster_url, release_date)
  │
  └──< shows (id, movie_id, screen_id, show_date, show_time, status)
```

### Business Rules & Constraints
1. **Seat Uniqueness**: `UNIQUE(screen_id, row_number, col_number)`.
2. **Double-Booking Prevention**: A seat can only be booked once per show. Booking requests run inside an atomic `SERIALIZABLE` database transaction verifying against existing `CONFIRMED` bookings.
3. **Immediate Seat Release**: When a booking is marked `CANCELLED`, queries checking seat availability only consider `status = 'CONFIRMED'`, making released seats instantly available to other customers.
4. **Seed-Only Admin Creation**: New user registrations are strictly forced to `role = 'USER'`. The `ADMIN` account is exclusively seeded via `data.sql` / `DataInitializer`.

---

## 📋 Pre-Seeded Accounts & Demo Data

### Pre-Seeded Credentials
| Role | Email | Password |
|---|---|---|
| **Administrator** | `admin@cinema.com` | `admin123` |
| **Standard User** | `user@cinema.com` | `user123` |

### Pre-Seeded Movies
1. **Inception** (Sci-Fi, 148 min, English)
2. **Interstellar** (Adventure, 169 min, English)
3. **The Dark Knight** (Action, 152 min, English)

### Pre-Seeded Theaters & Screens
- **Grand Cineplex Downtown** (New York)
  - Screen 1: IMAX Laser (5 rows x 8 cols = 40 seats)
  - Screen 2: Dolby Atmos (4 rows x 6 cols = 24 seats)
- **Starlight IMAX Cinema** (San Francisco)
  - Main Auditorium (5 rows x 8 cols = 40 seats)

---

## 🌐 REST API Endpoints

All endpoints are prefixed under `/api`:

### 🔐 Authentication (`/api/auth`)
- `POST /api/auth/register` - Create a new user account (`name`, `email`, `password`)
- `POST /api/auth/login` - Authenticate and receive JWT token (`email`, `password`)
- `GET /api/auth/me` - Get current authenticated user profile

### 🎬 Movies (`/api/movies`)
- `GET /api/movies` - List all movies (optional query params: `search`, `genre`, `language`)
- `GET /api/movies/{id}` - Get movie details by ID

### 📅 Shows (`/api/shows`)
- `GET /api/shows?movieId={id}` - List shows for a given movie (optional query param: `date`)
- `GET /api/shows/{id}` - Get show details by ID
- `GET /api/shows/{id}/seats` - Get seat map for the show with real-time `isBooked` availability

### 🎟️ Bookings (`/api/bookings`)
- `POST /api/bookings` - Book seats (Body: `{"showId": 1, "seatIds": [3, 4]}`)
- `GET /api/bookings/my` - List current user's bookings
- `GET /api/bookings/{id}` - View booking details
- `PUT /api/bookings/{id}/cancel` - Cancel a booking and immediately release seats

### ⚙️ Admin Operations (`/api/admin/**`) *(Requires `ROLE_ADMIN`)*
- `GET /api/admin/stats` - Total revenue, bookings count, and system metrics
- `GET /api/admin/bookings` - List all bookings across the entire system
- `PUT /api/admin/bookings/{id}/cancel` - Cancel any customer booking
- `POST /api/admin/movies` / `PUT /api/admin/movies/{id}` / `DELETE /api/admin/movies/{id}` - Movie CRUD
- `POST /api/admin/theaters` / `PUT /api/admin/theaters/{id}` / `DELETE /api/admin/theaters/{id}` - Theater CRUD
- `POST /api/admin/screens` / `PUT /api/admin/screens/{id}` / `DELETE /api/admin/screens/{id}` - Screen CRUD
- `POST /api/admin/screens/{id}/generate-seats` - Auto-generate seat grid with tiered pricing
- `POST /api/admin/shows` / `PUT /api/admin/shows/{id}` / `DELETE /api/admin/shows/{id}` - Show scheduling CRUD

---

## ⚙️ Setup and Installation

### Prerequisites
- **Java Development Kit (JDK) 17** or higher
- **Apache Maven 3.8+**
- **MySQL 8.0+** (or use the included in-memory H2 profile for zero-install demo)

---

### Option A: Running with MySQL 8 (Default)

1. **Create the Database in MySQL**:
   ```sql
   CREATE DATABASE cinema_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

2. **Configure Credentials in `src/main/resources/application.properties`** (or pass via environment variables):
   ```properties
   spring.datasource.url=jdbc:mysql://localhost:3306/cinema_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
   spring.datasource.username=root
   spring.datasource.password=root
   ```

3. **Build and Run**:
   ```bash
   mvn clean package -DskipTests
   mvn spring-boot:run
   ```

   *Note: On startup, `schema.sql` and `data.sql` are executed automatically to initialize the tables and seed data.*

---

### Option B: Quick Run with In-Memory H2 (Zero MySQL Setup)

If you don't have MySQL 8 installed locally, you can instantly run the application using the preconfigured H2 in-memory profile:

```bash
mvn spring-boot:run -Dspring-boot.run.profiles=h2
```

H2 Web Console is available at: `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:mem:cinema_db`
- Username: `sa`
- Password: *(leave blank)*

---

## 🖥️ Using the Application

Open your browser and navigate to:
```
http://localhost:8080
```

1. **Browse Movies**: Search or filter movies on the home page (`/index.html`).
2. **View Shows**: Click **"Book Tickets"** on any movie to see theater showtimes (`/movie-detail.html`).
3. **Select Seats**: Click a showtime to view the interactive seat map (`/seat-selection.html`). Choose Regular, Premium, or VIP seats and click **"Confirm & Pay"**.
4. **Log In**: If not logged in, you will be prompted to sign in with demo credentials or create an account.
5. **Get Your Ticket**: View and print your confirmed admission pass (`/booking-confirmation.html`).
6. **Manage Bookings**: View past bookings and cancel them at `/my-bookings.html`.
7. **Admin Dashboard**: Sign in as `admin@cinema.com` / `admin123` and access `/admin.html` to manage movies, theaters, screens, auto-generate seats, schedule shows, and track revenue.
