@echo off
title Cinema Ticket Booking System
setlocal enabledelayedexpansion

:: 1. Always ensure we run from the project root directory
cd /d "%~dp0"

echo ==============================================================
echo  CINEMA TICKET BOOKING SYSTEM - LAUNCHER
echo ==============================================================
echo Working Directory: %CD%

:: 2. Auto-detect & set JAVA_HOME if missing (prefers JDK 17+)
if not defined JAVA_HOME (
    if exist "C:\Program Files\Eclipse Adoptium\jdk-17.0.20.101-hotspot" (
        set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-17.0.20.101-hotspot"
    ) else if exist "C:\Program Files\Java\jdk-26.0.1" (
        set "JAVA_HOME=C:\Program Files\Java\jdk-26.0.1"
    )
)

if defined JAVA_HOME (
    set "PATH=%JAVA_HOME%\bin;%PATH%"
    echo Using JAVA_HOME: %JAVA_HOME%
) else (
    echo WARNING: JAVA_HOME is not explicitly defined.
)

:: Ensure Maven is in PATH
if exist "%USERPROFILE%\apache-maven-3.9.9\bin" (
    set "PATH=%USERPROFILE%\apache-maven-3.9.9\bin;%PATH%"
) else if exist "C:\Program Files\apache-maven-3.10.0\bin" (
    set "PATH=C:\Program Files\apache-maven-3.10.0\bin;%PATH%"
)

:: 3. Verify Java runtime
echo.
echo Checking Java version...
java -version
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Java execution failed. Please verify that JDK 17+ is installed.
    echo.
    pause
    exit /b 1
)

:: 4. Verify pom.xml exists
if not exist "pom.xml" (
    echo.
    echo [ERROR] pom.xml not found in %CD%!
    echo.
    pause
    exit /b 1
)

:: 5. Open browser
echo.
echo Opening web browser at http://localhost:8080 ...
start http://localhost:8080

:: 6. Launch Spring Boot application
echo.
echo Starting Spring Boot backend server...
echo (Press Ctrl+C to stop the server at any time)
echo ==============================================================
echo.

cmd /c "mvn spring-boot:run"

echo.
echo Application process exited.
pause
