CREATE DATABASE IF NOT EXISTS cinebook;
USE cinebook;

CREATE TABLE IF NOT EXISTS movies (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  genre VARCHAR(80) NOT NULL,
  duration_minutes INT NOT NULL,
  rating VARCHAR(10) DEFAULT 'U/A',
  description VARCHAR(500),
  poster_url VARCHAR(500),
  featured BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS showtimes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  movie_id INT NOT NULL,
  cinema_name VARCHAR(120) NOT NULL,
  show_date DATE NOT NULL,
  show_time TIME NOT NULL,
  ticket_price DECIMAL(8,2) NOT NULL,
  FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS bookings (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  booking_reference VARCHAR(24) NOT NULL UNIQUE,
  customer_name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL,
  movie_id INT NOT NULL,
  showtime_id INT NOT NULL,
  seat_list VARCHAR(500) NOT NULL,
  ticket_count INT NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  booking_status VARCHAR(20) NOT NULL DEFAULT 'CONFIRMED',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (movie_id) REFERENCES movies(id),
  FOREIGN KEY (showtime_id) REFERENCES showtimes(id)
);

INSERT INTO movies (title, genre, duration_minutes, rating, description, poster_url, featured) VALUES
('Interstellar', 'Sci-Fi • Adventure', 169, 'U/A', 'A team travels beyond this galaxy in a mission that could decide humanity’s future.', 'https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg', TRUE),
('The Dark Knight', 'Action • Crime', 152, 'U/A', 'A city faces its greatest test as a masked hero confronts a chaotic criminal.', 'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg', TRUE),
('Your Name', 'Animation • Romance', 106, 'U/A', 'Two teenagers discover an extraordinary connection across time and distance.', 'https://image.tmdb.org/t/p/w500/q719jXXEzOoYaps6babg.knONONX.jpg', TRUE);

-- Sample showtimes are relative to the seed date. Update them to dates in the future before a live demo.
INSERT INTO showtimes (movie_id, cinema_name, show_date, show_time, ticket_price) VALUES
(1, 'CineBook Central', CURRENT_DATE, '14:00:00', 220.00),
(1, 'CineBook Central', CURRENT_DATE, '18:30:00', 250.00),
(2, 'CineBook Central', CURRENT_DATE, '16:00:00', 200.00),
(2, 'CineBook Central', CURRENT_DATE, '20:00:00', 230.00),
(3, 'CineBook Central', CURRENT_DATE, '13:00:00', 180.00),
(3, 'CineBook Central', CURRENT_DATE, '19:00:00', 200.00);
