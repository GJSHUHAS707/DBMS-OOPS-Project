# CineBook — Movie Ticket Booking Website

A college-project starter using Java OOP, Java Servlets, JDBC, MySQL, HTML, CSS and JavaScript.

## Requirements
- JDK 17+
- Maven
- MySQL 8+
- Apache Tomcat 10.1+
- Eclipse or IntelliJ IDEA

## Setup
1. Create a MySQL database by running `database/schema.sql` in MySQL Workbench.
2. Update the MySQL username/password in `src/main/java/com/cinebook/util/DBConnection.java`.
3. From this folder, run `mvn clean package`.
4. Deploy `target/cinebook.war` to Tomcat 10.1+ (or run through an IDE configured with Tomcat).
5. Open `http://localhost:8080/cinebook/`.

The frontend is a starter landing page. The Java servlet endpoints provide movie listing and booking creation. Payment processing is intentionally not connected; use a payment provider's test mode before any real deployment.

## OOP concepts used
- Encapsulation: private fields and getters/setters in model classes.
- Abstraction: `PaymentMethod` interface.
- Polymorphism: payment implementations can implement `PaymentMethod` differently.
- Inheritance: `Person` base class and `Customer` subclass.
- Composition: `Booking` contains selected seat information.

## Demo API
- `GET /api/movies` — list movies from MySQL
- `POST /api/bookings` — create a booking from JSON:
  `{"customerName":"Demo User","email":"demo@example.com","movieId":1,"showtimeId":1,"seats":["A1","A2"]}`

This starter is for learning. Before production, add authentication, CSRF protection, stronger validation, transaction-safe seat locking, real payment integration, and privacy/security review.
