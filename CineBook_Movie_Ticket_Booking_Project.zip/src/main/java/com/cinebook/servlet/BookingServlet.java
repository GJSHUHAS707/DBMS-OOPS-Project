package com.cinebook.servlet;

import com.cinebook.model.*;
import com.cinebook.payment.*;
import com.cinebook.util.DBConnection;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;
import java.util.regex.Pattern;

@WebServlet("/api/bookings")
public class BookingServlet extends HttpServlet {
    private final Gson gson = new Gson();
    private static final Pattern SEAT = Pattern.compile("^[A-J](?:[1-9]|1[0-2])$");

    private static class BookingRequest {
        String customerName, email;
        int movieId, showtimeId;
        List<String> seats;
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        res.setContentType("application/json;charset=UTF-8");
        BookingRequest data;
        try { data = gson.fromJson(req.getReader(), BookingRequest.class); }
        catch (Exception e) { res.setStatus(400); res.getWriter().write("{\"error\":\"Invalid JSON.\"}"); return; }

        if (data == null || data.customerName == null || data.customerName.isBlank()
                || data.email == null || !data.email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")
                || data.movieId < 1 || data.showtimeId < 1 || data.seats == null || data.seats.isEmpty()
                || data.seats.size() > 10 || data.seats.stream().anyMatch(s -> s == null || !SEAT.matcher(s).matches())
                || new HashSet<>(data.seats).size() != data.seats.size()) {
            res.setStatus(400); res.getWriter().write("{\"error\":\"Enter valid details and choose 1–10 unique seats.\"}"); return;
        }

        String reference = "CB" + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
        String seatList = String.join(",", data.seats);
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                BigDecimal price;
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT ticket_price FROM showtimes WHERE id=? AND movie_id=? AND show_date >= CURRENT_DATE FOR UPDATE")) {
                    ps.setInt(1, data.showtimeId); ps.setInt(2, data.movieId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) { con.rollback(); res.setStatus(400); res.getWriter().write("{\"error\":\"Showtime not found or has passed.\"}"); return; }
                        price = rs.getBigDecimal(1);
                    }
                }
                // Basic duplicate-seat check. For a production app, normalize seats into a table with a UNIQUE(showtime_id, seat_code) constraint.
                Set<String> occupied = new HashSet<>();
                try (PreparedStatement ps = con.prepareStatement("SELECT seat_list FROM bookings WHERE showtime_id=? AND booking_status='CONFIRMED'")) {
                    ps.setInt(1, data.showtimeId);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) occupied.addAll(Arrays.asList(rs.getString(1).split(",")));
                    }
                }
                if (data.seats.stream().anyMatch(occupied::contains)) {
                    con.rollback(); res.setStatus(409); res.getWriter().write("{\"error\":\"One or more seats were just booked. Please choose again.\"}"); return;
                }
                BigDecimal total = price.multiply(BigDecimal.valueOf(data.seats.size()));
                Booking booking = new Booking(new Customer(data.customerName.trim(), data.email.trim()), data.movieId, data.showtimeId, data.seats, total);
                PaymentMethod payment = new DemoPayment();
                if (!payment.pay(booking.getTotalAmount())) {
                    con.rollback(); res.setStatus(402); res.getWriter().write("{\"error\":\"Payment could not be completed.\"}"); return;
                }
                String sql = "INSERT INTO bookings (booking_reference,customer_name,email,movie_id,showtime_id,seat_list,ticket_count,total_amount) VALUES (?,?,?,?,?,?,?,?)";
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, reference); ps.setString(2, booking.getCustomer().getName()); ps.setString(3, booking.getCustomer().getEmail());
                    ps.setInt(4, booking.getMovieId()); ps.setInt(5, booking.getShowtimeId()); ps.setString(6, seatList);
                    ps.setInt(7, booking.getSeats().size()); ps.setBigDecimal(8, booking.getTotalAmount()); ps.executeUpdate();
                }
                con.commit();
                JsonObject out = new JsonObject(); out.addProperty("message", "Booking saved"); out.addProperty("reference", reference);
                out.addProperty("totalAmount", total); out.addProperty("seats", seatList);
                res.setStatus(201); res.getWriter().write(gson.toJson(out));
            } catch (Exception e) {
                con.rollback(); throw e;
            } finally { con.setAutoCommit(true); }
        } catch (Exception e) {
            res.setStatus(500); res.getWriter().write("{\"error\":\"Booking failed. Please check the database and try again.\"}");
            getServletContext().log("Booking creation failed", e);
        }
    }
}
