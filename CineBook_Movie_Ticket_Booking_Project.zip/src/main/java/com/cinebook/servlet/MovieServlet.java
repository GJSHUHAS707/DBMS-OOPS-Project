package com.cinebook.servlet;

import com.cinebook.model.Movie;
import com.cinebook.util.DBConnection;
import com.google.gson.Gson;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/api/movies")
public class MovieServlet extends HttpServlet {
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json;charset=UTF-8");
        List<Movie> movies = new ArrayList<>();
        String sql = "SELECT id,title,genre,duration_minutes,rating,description,poster_url FROM movies ORDER BY featured DESC,id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                movies.add(new Movie(rs.getInt("id"), rs.getString("title"), rs.getString("genre"),
                    rs.getInt("duration_minutes"), rs.getString("rating"), rs.getString("description"), rs.getString("poster_url")));
            }
            response.getWriter().write(gson.toJson(movies));
        } catch (SQLException e) {
            response.setStatus(500);
            response.getWriter().write("{\"error\":\"Could not load movies. Check database setup.\"}");
            getServletContext().log("Movie listing failed", e);
        }
    }
}
