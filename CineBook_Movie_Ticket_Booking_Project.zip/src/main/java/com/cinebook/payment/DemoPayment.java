package com.cinebook.payment;

import java.math.BigDecimal;

/** Educational placeholder only; it does not charge money. */
public class DemoPayment implements PaymentMethod {
    @Override
    public boolean pay(BigDecimal amount) {
        return amount != null && amount.signum() > 0;
    }
}
