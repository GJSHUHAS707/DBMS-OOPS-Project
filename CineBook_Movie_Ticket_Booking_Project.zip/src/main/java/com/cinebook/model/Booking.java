package com.cinebook.model;

import java.math.BigDecimal;
import java.util.List;

public class Booking {
    private final Customer customer;
    private final int movieId;
    private final int showtimeId;
    private final List<String> seats;
    private final BigDecimal totalAmount;

    public Booking(Customer customer, int movieId, int showtimeId, List<String> seats, BigDecimal totalAmount) {
        this.customer = customer; this.movieId = movieId; this.showtimeId = showtimeId;
        this.seats = List.copyOf(seats); this.totalAmount = totalAmount;
    }
    public Customer getCustomer() { return customer; }
    public int getMovieId() { return movieId; }
    public int getShowtimeId() { return showtimeId; }
    public List<String> getSeats() { return seats; }
    public BigDecimal getTotalAmount() { return totalAmount; }
}
