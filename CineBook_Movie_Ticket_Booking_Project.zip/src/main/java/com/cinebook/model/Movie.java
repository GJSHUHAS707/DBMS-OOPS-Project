package com.cinebook.model;

public class Movie {
    private int id;
    private String title, genre, rating, description, posterUrl;
    private int durationMinutes;

    public Movie(int id, String title, String genre, int durationMinutes, String rating, String description, String posterUrl) {
        this.id = id; this.title = title; this.genre = genre; this.durationMinutes = durationMinutes;
        this.rating = rating; this.description = description; this.posterUrl = posterUrl;
    }
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getGenre() { return genre; }
    public int getDurationMinutes() { return durationMinutes; }
    public String getRating() { return rating; }
    public String getDescription() { return description; }
    public String getPosterUrl() { return posterUrl; }
}
