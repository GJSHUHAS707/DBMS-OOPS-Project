const context = window.location.pathname.replace(/\/index\.html$/, '').replace(/\/$/, '');
const api = `${context}/api`;
const demoMovies = [
 {id:1,title:'Interstellar',genre:'Sci-Fi • Adventure',durationMinutes:169,rating:'U/A',description:'A team travels beyond this galaxy in a mission that could decide humanity’s future.',posterUrl:'https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg'},
 {id:2,title:'The Dark Knight',genre:'Action • Crime',durationMinutes:152,rating:'U/A',description:'A city faces its greatest test as a masked hero confronts a chaotic criminal.',posterUrl:'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg'},
 {id:3,title:'Your Name',genre:'Animation • Fantasy',durationMinutes:106,rating:'U/A',description:'Two teenagers discover an extraordinary connection across time and distance.',posterUrl:'https://image.tmdb.org/t/p/w500/q719jXXEzOoYaps6babg.knONONX.jpg'}
];
let movies = [], activeMovie = null, selectedSeats = new Set(), ticketPrice = 200;
const grid = document.getElementById('movieGrid');
function escapeHtml(value='') { return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function renderMovies() {
  grid.innerHTML = movies.map(m => `<article class="movie-card">
    <div class="poster"><img src="${escapeHtml(m.posterUrl || '')}" alt="${escapeHtml(m.title)} poster" loading="lazy" onerror="this.style.opacity='.15'"><span class="rating">✦ ${escapeHtml(m.rating || 'U/A')}</span></div>
    <div class="movie-info"><h3>${escapeHtml(m.title)}</h3><p>${escapeHtml(m.description || m.genre)}</p>
    <div class="movie-meta"><span>${escapeHtml(m.genre)}</span><span>${Number(m.durationMinutes)} min</span></div>
    <button class="book-btn" data-id="${Number(m.id)}">Choose showtime ↗</button></div></article>`).join('');
  grid.querySelectorAll('.book-btn').forEach(b => b.addEventListener('click', () => openBooking(Number(b.dataset.id))));
}
async function loadMovies() {
  try {
    const res = await fetch(`${api}/movies`);
    if (!res.ok) throw new Error('API unavailable');
    const data = await res.json();
    movies = Array.isArray(data) && data.length ? data : demoMovies;
  } catch (e) { movies = demoMovies; }
  renderMovies();
}
function openBooking(id) {
  activeMovie = movies.find(m => Number(m.id) === id) || demoMovies[0];
  selectedSeats.clear();
  document.getElementById('movieId').value = activeMovie.id;
  document.getElementById('movieSummary').textContent = `${activeMovie.title} · Select a showtime and seats`;
  const select = document.getElementById('showtimeId');
  // Demo IDs correspond to seed data; for a real multi-date app, load showtimes from a dedicated endpoint.
  const options = activeMovie.id === 1 ? [[1,'Today · 2:00 PM',220],[2,'Today · 6:30 PM',250]] :
                  activeMovie.id === 2 ? [[3,'Today · 4:00 PM',200],[4,'Today · 8:00 PM',230]] :
                  [[5,'Today · 1:00 PM',180],[6,'Today · 7:00 PM',200]];
  select.innerHTML = options.map(o=>`<option value="${o[0]}" data-price="${o[2]}">${o[1]} · ₹${o[2]}</option>`).join('');
  ticketPrice = options[0][2];
  select.onchange = () => { ticketPrice = Number(select.selectedOptions[0].dataset.price); updateTotal(); };
  buildSeats(); updateTotal();
  document.getElementById('formMessage').textContent = '';
  document.getElementById('formMessage').className = 'form-message';
  document.getElementById('modal').classList.remove('hidden');
}
function buildSeats() {
  const wrap = document.getElementById('seatGrid'); wrap.innerHTML = '';
  for (let row=0; row<4; row++) for (let col=1; col<=6; col++) {
    const seat = `${String.fromCharCode(65+row)}${col}`;
    const btn = document.createElement('button'); btn.type='button'; btn.className='seat'; btn.textContent=seat;
    btn.setAttribute('aria-pressed','false');
    btn.addEventListener('click', () => {
      if (selectedSeats.has(seat)) selectedSeats.delete(seat);
      else if (selectedSeats.size < 4) selectedSeats.add(seat);
      else { showMessage('For this demo, choose up to four seats.', true); return; }
      btn.classList.toggle('selected', selectedSeats.has(seat)); btn.setAttribute('aria-pressed', String(selectedSeats.has(seat))); updateTotal();
    });
    wrap.appendChild(btn);
  }
}
function updateTotal(){ document.getElementById('total').textContent = `₹${ticketPrice * selectedSeats.size}`; }
function showMessage(text, error=false){ const el=document.getElementById('formMessage');el.textContent=text;el.className=error?'form-message error':'form-message';}
document.getElementById('closeModal').addEventListener('click',()=>document.getElementById('modal').classList.add('hidden'));
document.getElementById('modal').addEventListener('click',e=>{if(e.target.id==='modal')e.currentTarget.classList.add('hidden')});
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.getElementById('modal').classList.add('hidden')});
document.getElementById('bookingForm').addEventListener('submit', async e => {
  e.preventDefault();
  if (!selectedSeats.size) { showMessage('Please choose at least one seat.', true); return; }
  const payload = { customerName: document.getElementById('customerName').value.trim(), email: document.getElementById('email').value.trim(),
    movieId:Number(document.getElementById('movieId').value), showtimeId:Number(document.getElementById('showtimeId').value), seats:[...selectedSeats] };
  const button=e.currentTarget.querySelector('button[type=submit]'); button.disabled=true; button.textContent='Saving booking…';
  try {
    const res=await fetch(`${api}/bookings`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const data=await res.json();
    if(!res.ok) throw new Error(data.error || 'Booking could not be saved.');
    showMessage(`Booking saved! Reference: ${data.reference}. Total: ₹${data.totalAmount}. (Demo payment only)`);
  } catch(err) {
    // A visual demo still works without Tomcat/MySQL; it does not persist bookings.
    if (err instanceof TypeError) showMessage(`Demo preview only: ${payload.seats.length} seat(s) selected for ${activeMovie.title}. Start Tomcat and configure MySQL to save bookings.`, false);
    else showMessage(err.message, true);
  } finally { button.disabled=false; button.innerHTML='Confirm booking <span>↗</span>'; }
});
loadMovies();
