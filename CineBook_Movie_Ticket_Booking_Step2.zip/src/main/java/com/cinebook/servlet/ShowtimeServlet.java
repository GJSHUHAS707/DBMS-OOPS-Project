package com.cinebook.servlet;
import com.cinebook.util.DBConnection;
import com.google.gson.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/api/showtimes")
public class ShowtimeServlet extends HttpServlet {
  private final Gson gson = new Gson();
  protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
    res.setContentType("application/json;charset=UTF-8");
    int movieId;
    try { movieId = Integer.parseInt(req.getParameter("movieId")); }
    catch (Exception e) { res.setStatus(400); res.getWriter().write("{\"error\":\"Valid movieId required\"}"); return; }
    String sql = "SELECT id,movie_id,cinema_name,show_date,show_time,ticket_price FROM showtimes WHERE movie_id=? AND show_date>=CURRENT_DATE ORDER BY show_date,show_time";
    JsonArray out = new JsonArray();
    try (Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
      p.setInt(1,movieId);
      try(ResultSet r=p.executeQuery()) {
        while(r.next()) {
          JsonObject o=new JsonObject(); o.addProperty("id",r.getInt("id")); o.addProperty("movieId",r.getInt("movie_id"));
          o.addProperty("cinemaName",r.getString("cinema_name")); o.addProperty("showDate",r.getDate("show_date").toString());
          o.addProperty("showTime",r.getTime("show_time").toString()); o.addProperty("ticketPrice",r.getBigDecimal("ticket_price")); out.add(o);
        }
      }
      res.getWriter().write(gson.toJson(out));
    } catch(SQLException e) { res.setStatus(500); res.getWriter().write("{\"error\":\"Database error loading showtimes\"}"); getServletContext().log("Showtimes failed",e); }
  }
}
