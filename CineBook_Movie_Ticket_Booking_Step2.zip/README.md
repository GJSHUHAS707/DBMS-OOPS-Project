# CineBook — Movie Ticket Booking Website
Java OOP + Servlets + JDBC + MySQL + HTML/CSS/JavaScript.

## Setup
1. Run `database/schema.sql` in MySQL Workbench.
2. Update credentials in `src/main/java/com/cinebook/util/DBConnection.java`.
3. Run `mvn clean package`.
4. Deploy `target/cinebook.war` to Tomcat 10.1+.
5. Open `http://localhost:8080/cinebook/`.

## Endpoints
- `GET /api/movies`
- `GET /api/showtimes?movieId=1`
- `GET /api/seats?showtimeId=1`
- `POST /api/bookings`

The payment implementation is a demo only. For production, use normalized seat records with a unique constraint on `(showtime_id, seat_code)`, transactions/locking, authentication, CSRF protection and a real payment provider's test mode.
